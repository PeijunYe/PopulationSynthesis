﻿using System;
using System.Collections.Generic;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;

namespace PopSynForChina
{
	public class MCMCGenerator
	{
		private int transferNum;//Gibbs sampler transfer number
		private int sampleInterval;//Gibbs sampling interval
		private int sampleSize;//sample pool size
		private string jointDisDBName;//name of db for sample pool
		private bool readJointDisFromDB;//control flag for ditribution fitting or population realization
		private Random rand;
		//conditional distributions:
		private Dictionary<IndJointDis, float> genderCon;
		private Dictionary<IndJointDis, float> ageCon;
		private Dictionary<IndJointDis, float> resideProvCon;
		private Dictionary<IndJointDis, float> raceCon;
		private Dictionary<IndJointDis, float> registProvCon;
		private Dictionary<IndJointDis, float> eduLevelCon;
		private Dictionary<IndJointDis, float> resideTypeCon;
		private Dictionary<IndJointDis, float> registTypeCon;

		public MCMCGenerator( int transferNum, int sampleInterval, int sampleSize, string jointDisDBName, bool readJointDisFromDB )
		{
			genderCon = new Dictionary<IndJointDis, float>( );
			ageCon = new Dictionary<IndJointDis, float>( );
			resideProvCon = new Dictionary<IndJointDis, float>( );
			raceCon = new Dictionary<IndJointDis, float>( );
			registProvCon = new Dictionary<IndJointDis, float>( );
			eduLevelCon = new Dictionary<IndJointDis, float>( );
			resideTypeCon = new Dictionary<IndJointDis, float>( );
			registTypeCon = new Dictionary<IndJointDis, float>( );
			rand = new Random( );
			this.transferNum = transferNum;
			this.sampleInterval = sampleInterval;
			this.sampleSize = sampleSize;
			this.jointDisDBName = jointDisDBName;
			this.readJointDisFromDB = readJointDisFromDB;
		}

		public void PopGeneration( )
		{
			if ( !readJointDisFromDB )
			{
				InitConditionals( );
				GibbsSampling( );
			} else
			{
				PopRealization( );
			}
		}

		/// <summary>
		/// compute conditional distribution
		/// </summary>
		private void InitConditionals( )
		{
			GetRegistTypeAndProvinceCon( );
			Console.WriteLine( "Register type and province updated!" );
			GetResiProvAndRaceAndResiTypeAndGender( );
			Console.WriteLine( "Reside province, race, residence type and gender updated!" );
			GetAgeIntervalCon( );
			Console.WriteLine( "Age interval updated!" );
			GetEduLevelCon( );
			Console.WriteLine( "Education level updated!" );
		}

		/// <summary>
		/// Gibbs sampling
		/// </summary>
		private void GibbsSampling( )
		{
			IndJointDis seed = new IndJointDis( EGender.Male, EAgeInterval.ThirtyToThirtyFour,
				EProvince.Henan, ERaceType.Han, EProvince.Other, EEducateLevel.primaSchool, EResidenceType.rural, ERegistType.rural );
			for ( int i = 0; i < transferNum; i++ )
			{
				UpdateSeed( ref seed );
			}
			Console.WriteLine( "Initial trasfer complete!" );
			string disDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, jointDisDBName );
			MyDatabase jointDisDB = new MyDatabase( disDBName );
			if ( Directory.Exists( disDBName ) )
				Directory.Delete( disDBName, true );
			jointDisDB.DBOpen( );
			int sampleIndex = 0;
			uint agentID = 0;
			while ( true )
			{
				sampleIndex++;
				UpdateSeed( ref seed );
				if ( sampleIndex % sampleInterval == 0 )
				{
					ushort basicAge = (ushort)((int)seed.Age * 5);
					int ageDev = rand.Next( 5 );
					ushort age = (ushort)(basicAge + ageDev);
					ushort birthYear = (ushort)(2000 - age);
					ushort birthMonth = (ushort)(rand.Next( 12 ) + 1);
					Individual newInd = new Individual( agentID, seed.Gender, birthYear, birthMonth, age,
						seed.Race, seed.RegistProvin, seed.RegistType, seed.EduLevel, seed.ResideProvin, seed.ResidenceType );
					//write db:
					string keyStr = agentID.ToString( );
					string valueStr = ((int)newInd.Gender).ToString( );
					valueStr += "-" + newInd.BirthYear.ToString( );
					valueStr += "-" + newInd.BirthMonth.ToString( );
					valueStr += "-" + newInd.Age.ToString( );
					valueStr += "-" + ((int)newInd.RaceType).ToString( );
					valueStr += "-" + ((int)newInd.RegistProvin).ToString( );
					valueStr += "-" + ((int)newInd.RegistType).ToString( );
					valueStr += "-" + ((int)newInd.EducateLevel).ToString( );
					valueStr += "-" + ((int)newInd.Provin).ToString( );
					valueStr += "-" + ((int)newInd.ResidenceType).ToString( );
					jointDisDB.WriteAsyn( keyStr, valueStr );
					agentID++;
					sampleIndex = 0;
					if ( agentID % 1000000 == 0 )
						Console.WriteLine( agentID / 1000000 + " million individuals generated!" );
					if ( agentID >= sampleSize )
						break;
				}
			}
			jointDisDB.DBDispose( );
		}

		/// <summary>
		/// direct population draw
		/// </summary>
		private void PopRealization( )
		{
			uint tarPopSize = (uint)(InputPara.totalPopulation * InputPara.popSizeRatio);
			string popDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, InputPara.popDBName );
			MyDatabase popDB = new MyDatabase( popDBName );
			if ( Directory.Exists( popDBName ) )
				Directory.Delete( popDBName, true );
			popDB.DBOpen( );
			string disDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, jointDisDBName );
			MyDatabase jointDisDB = new MyDatabase( disDBName );
			if ( !Directory.Exists( disDBName ) )
				throw new ApplicationException( "Joint Distribution DB does not exist!" );
			jointDisDB.DBOpen( );
			for ( uint agentID = 0; agentID < tarPopSize; agentID++ )
			{
				uint seedID = (uint)rand.Next( sampleSize );
				string valStr = jointDisDB.Read( seedID.ToString( ) );
				string newKeyStr = agentID.ToString( );
				popDB.WriteAsyn( newKeyStr, valStr );
				if ( agentID % 10000000 == 0 )
					Console.WriteLine( string.Format( "{0:0,0}", agentID ) + " individuals drawn..." );
			}
			jointDisDB.DBDispose( );
			popDB.DBDispose( );
		}

		/// <summary>
		/// compute Registration Type and Registration Province transfer probability
		/// </summary>
		private void GetRegistTypeAndProvinceCon( )
		{
			Dictionary<IndJointDis, uint> regTypeNum = new Dictionary<IndJointDis, uint>( );
			Dictionary<EProvince, uint> ruralMale = new Dictionary<EProvince, uint>( );
			Dictionary<EProvince, uint> ruralFemale = new Dictionary<EProvince, uint>( );
			Dictionary<EProvince, uint> urbanMale = new Dictionary<EProvince, uint>( );
			Dictionary<EProvince, uint> urbanFemale = new Dictionary<EProvince, uint>( );
			Dictionary<EProvince, uint> noRegMale = new Dictionary<EProvince, uint>( );
			Dictionary<EProvince, uint> noRegFemale = new Dictionary<EProvince, uint>( );
			Excel.Application excelApp = new Excel.Application( );
			object objOpt = System.Reflection.Missing.Value;
			Excel.Workbook workBook = null;
			Excel.Sheets sheets;
			Excel.Worksheet worksheet;
			Excel.Range range;
			try
			{
				int iRowCount = 0;
				int iColCount = 0;
				string cellContent = null;
				#region Registration Type conditional probability
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0105.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					range = worksheet.Cells[ i, 6 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint ruralMaleNum = uint.Parse( cellContent );
					IndJointDis newMaleRuralDis = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour,
						resideProv, ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.rural );
					regTypeNum.Add( newMaleRuralDis, ruralMaleNum );
					ruralMale.Add( resideProv, ruralMaleNum );
					range = worksheet.Cells[ i, 7 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint ruralFemaleNum = uint.Parse( cellContent );
					IndJointDis newFemaleRuralDis = new IndJointDis( EGender.Female, EAgeInterval.ZeroToFour,
						resideProv, ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.rural );
					regTypeNum.Add( newFemaleRuralDis, ruralFemaleNum );
					ruralFemale.Add( resideProv, ruralFemaleNum );
					range = worksheet.Cells[ i, 9 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint urbanMaleNum = uint.Parse( cellContent );
					IndJointDis newMaleUrbanDis = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour,
						resideProv, ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.urban );
					regTypeNum.Add( newMaleUrbanDis, urbanMaleNum );
					urbanMale.Add( resideProv, urbanMaleNum );
					range = worksheet.Cells[ i, 10 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint urbanFemaleNum = uint.Parse( cellContent );
					IndJointDis newFemaleUrbanDis = new IndJointDis( EGender.Female, EAgeInterval.ZeroToFour,
						resideProv, ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.urban );
					regTypeNum.Add( newFemaleUrbanDis, urbanFemaleNum );
					urbanFemale.Add( resideProv, urbanFemaleNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0102.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					range = worksheet.Cells[ i, 3 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint cenRegMale = uint.Parse( cellContent );
					if ( cenRegMale >= ruralMale[ resideProv ] + urbanMale[ resideProv ] )
					{
						uint noRegMaleNum = cenRegMale - ruralMale[ resideProv ] - urbanMale[ resideProv ];
						IndJointDis newMaleNoRegDis = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour,
							resideProv, ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.other );
						regTypeNum.Add( newMaleNoRegDis, noRegMaleNum );
						noRegMale.Add( resideProv, noRegMaleNum );
					} else
						throw new ApplicationException( "cenRegMale - abroadMale < ruralMale[ resideProv ] + ruralFemale[ resideProv ]" );
					range = worksheet.Cells[ i, 4 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint cenRegFemale = uint.Parse( cellContent );
					if ( cenRegFemale >= ruralFemale[ resideProv ] + urbanFemale[ resideProv ] )
					{
						uint noRegFemaleNum = cenRegFemale - ruralFemale[ resideProv ] - urbanFemale[ resideProv ];
						IndJointDis newFemaleNoRegDis = new IndJointDis( EGender.Female, EAgeInterval.ZeroToFour,
							resideProv, ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.other );
						regTypeNum.Add( newFemaleNoRegDis, noRegFemaleNum );
						noRegFemale.Add( resideProv, noRegFemaleNum );
					} else
						throw new ApplicationException( "cenRegFemale - abroadFemale < ruralFemale[ resideProv ] + urbanFemale[ resideProv ]" );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				HashSet<EGender> genderSet = new HashSet<EGender>( );
				HashSet<EProvince> resideProvSet = new HashSet<EProvince>( );
				HashSet<ERegistType> regTypeSet = new HashSet<ERegistType>( );
				foreach ( IndJointDis parDis in regTypeNum.Keys )
				{
					genderSet.Add( parDis.Gender );
					resideProvSet.Add( parDis.ResideProvin );
					regTypeSet.Add( parDis.RegistType );
				}
				foreach ( EGender gender in genderSet )
				{
					foreach ( EProvince residePro in resideProvSet )
					{
						uint sumNum = 0;
						foreach ( IndJointDis parDis in regTypeNum.Keys )
						{
							if ( parDis.Gender == gender && parDis.ResideProvin == residePro )
								sumNum += regTypeNum[ parDis ];
						}
						foreach ( ERegistType regType in regTypeSet )
						{
							foreach ( IndJointDis parDis in regTypeNum.Keys )
							{
								if ( parDis.RegistType == regType && parDis.Gender == gender && parDis.ResideProvin == residePro )
								{
									IndJointDis newRegistTypeCon = new IndJointDis( gender, EAgeInterval.ZeroToFour,
										residePro, ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, regType );
									registTypeCon.Add( newRegistTypeCon, (float)regTypeNum[ parDis ] / sumNum );
									break;
								}
							}
						}
					}
				}
				#endregion
				#region Registration Province conditional probability
				Dictionary<EProvince, uint> regProvMaleNum = new Dictionary<EProvince, uint>( );
				Dictionary<EProvince, uint> regProvFemaleNum = new Dictionary<EProvince, uint>( );
				Dictionary<EProvince, uint> regProvNativeMale = new Dictionary<EProvince, uint>( );
				Dictionary<EProvince, uint> regProvNativeFemale = new Dictionary<EProvince, uint>( );
				iRowCount = 0;
				iColCount = 0;
				cellContent = null;
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0103.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 2; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince registProv = AttributeCheck.CheckProvince( cellContent );
					range = worksheet.Cells[ i, 3 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint maleNum = uint.Parse( cellContent );
					regProvMaleNum.Add( registProv, maleNum );
					range = worksheet.Cells[ i, 4 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint femaleNum = uint.Parse( cellContent );
					regProvFemaleNum.Add( registProv, femaleNum );
					range = worksheet.Cells[ i, 6 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint nativeMaleNum = uint.Parse( cellContent );
					regProvNativeMale.Add( registProv, nativeMaleNum );
					range = worksheet.Cells[ i, 7 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint nativeFemaleNum = uint.Parse( cellContent );
					regProvNativeFemale.Add( registProv, nativeFemaleNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				Dictionary<IndJointDis, uint> regProvNum = new Dictionary<IndJointDis, uint>( );
				uint registMaleTotal = 0;
				uint registFemaleTotal = 0;
				foreach ( EProvince prov in regProvMaleNum.Keys )
				{
					registMaleTotal += regProvMaleNum[ prov ] - regProvNativeMale[ prov ];
				}
				foreach ( EProvince prov in regProvFemaleNum.Keys )
				{
					registFemaleTotal += regProvFemaleNum[ prov ] - regProvNativeFemale[ prov ];
				}
				List<IndJointDis> keys = new List<IndJointDis>( );
				keys.AddRange( regTypeNum.Keys );
				foreach ( IndJointDis jointDis in keys )
				{
					uint indNum = regTypeNum[ jointDis ];
					if ( jointDis.RegistType == ERegistType.other )//without Registration
					{
						IndJointDis newJointDis = new IndJointDis( jointDis.Gender, jointDis.Age, jointDis.ResideProvin,
								jointDis.Race, jointDis.RegistProvin, jointDis.EduLevel, jointDis.ResidenceType, jointDis.RegistType );
						regProvNum.Add( newJointDis, indNum );
						continue;
					}
					EProvince resideProv = jointDis.ResideProvin;
					if ( jointDis.Gender == EGender.Male )
					{
						float nativeRatio = (float)regProvNativeMale[ resideProv ] / regProvMaleNum[ resideProv ];
						IndJointDis nativeJointDis = new IndJointDis( jointDis.Gender, jointDis.Age, jointDis.ResideProvin,
								jointDis.Race, jointDis.RegistProvin, jointDis.EduLevel, jointDis.ResidenceType, jointDis.RegistType );
						nativeJointDis.RegistProvin = resideProv;
						uint nativeIndNum = (uint)(indNum * nativeRatio);
						regProvNum.Add( nativeJointDis, nativeIndNum );
						foreach ( EProvince registProv in regProvMaleNum.Keys )
						{
							IndJointDis newJointDis = new IndJointDis( jointDis.Gender, jointDis.Age, jointDis.ResideProvin,
								jointDis.Race, jointDis.RegistProvin, jointDis.EduLevel, jointDis.ResidenceType, jointDis.RegistType );
							newJointDis.RegistProvin = registProv;
							uint newIndNum = (uint)((indNum - nativeIndNum)
								* ((float)(regProvMaleNum[ registProv ] - regProvNativeMale[ registProv ]) / registMaleTotal));
							if ( registProv == resideProv )
								regProvNum[ newJointDis ] += newIndNum;
							else
								regProvNum.Add( newJointDis, newIndNum );
						}
					} else
					{
						float nativeRatio = (float)regProvNativeFemale[ resideProv ] / regProvFemaleNum[ resideProv ];
						IndJointDis nativeJointDis = new IndJointDis( jointDis.Gender, jointDis.Age, jointDis.ResideProvin,
								jointDis.Race, jointDis.RegistProvin, jointDis.EduLevel, jointDis.ResidenceType, jointDis.RegistType );
						nativeJointDis.RegistProvin = resideProv;
						uint nativeIndNum = (uint)(indNum * nativeRatio);
						regProvNum.Add( nativeJointDis, nativeIndNum );
						foreach ( EProvince registProv in regProvFemaleNum.Keys )
						{
							IndJointDis newJointDis = new IndJointDis( jointDis.Gender, jointDis.Age, jointDis.ResideProvin,
								jointDis.Race, jointDis.RegistProvin, jointDis.EduLevel, jointDis.ResidenceType, jointDis.RegistType );
							newJointDis.RegistProvin = registProv;
							uint newIndNum = (uint)((indNum - nativeIndNum)
								* ((float)(regProvFemaleNum[ registProv ] - regProvNativeFemale[ registProv ]) / registFemaleTotal));
							if ( registProv == resideProv )
								regProvNum[ newJointDis ] += newIndNum;
							else
								regProvNum.Add( newJointDis, newIndNum );
						}
					}
				}
				//transfer probability:
				genderSet.Clear( );
				resideProvSet.Clear( );
				regTypeSet.Clear( );
				HashSet<EProvince> registProvSet = new HashSet<EProvince>( );
				foreach ( IndJointDis parDis in regProvNum.Keys )
				{
					genderSet.Add( parDis.Gender );
					resideProvSet.Add( parDis.ResideProvin );
					regTypeSet.Add( parDis.RegistType );
					registProvSet.Add( parDis.RegistProvin );
				}
				foreach ( EGender gender in genderSet )
				{
					foreach ( EProvince residePro in resideProvSet )
					{
						foreach ( ERegistType regType in regTypeSet )
						{
							uint sumNum = 0;
							foreach ( IndJointDis parDis in regProvNum.Keys )
							{
								if ( parDis.Gender == gender && parDis.ResideProvin == residePro && parDis.RegistType == regType )
									sumNum += regProvNum[ parDis ];
							}
							foreach ( EProvince regProv in registProvSet )
							{
								foreach ( IndJointDis parDis in regProvNum.Keys )
								{
									if ( parDis.Gender == gender && parDis.ResideProvin == residePro
										&& parDis.RegistType == regType && parDis.RegistProvin == regProv )
									{
										IndJointDis newRegistProvCon = new IndJointDis( gender, EAgeInterval.ZeroToFour,
											residePro, ERaceType.Other, regProv, EEducateLevel.infant, EResidenceType.rural, regType );
										uint count = regProvNum[ parDis ];
										registProvCon.Add( newRegistProvCon, (float)regProvNum[ parDis ] / sumNum );
										break;
									}
								}
							}
						}
					}
				}
				#endregion
			} catch ( Exception e )
			{
				throw new ApplicationException( e.Message );
			} finally
			{
				if ( workBook != null )
				{
					workBook.Close( false, objOpt, objOpt );
					System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
					workBook = null;
				}
				excelApp.Workbooks.Close( );
				excelApp.Quit( );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( excelApp );
				excelApp = null;
				GC.Collect( );
				GC.WaitForPendingFinalizers( );
			}
		}

		/// <summary>
		/// compute Residential Province, Ethnic Group, Residence Type and Gender transfer probability
		/// </summary>
		private void GetResiProvAndRaceAndResiTypeAndGender( )
		{
			Dictionary<IndJointDis, uint> jointDis = new Dictionary<IndJointDis, uint>( );
			Excel.Application excelApp = new Excel.Application( );
			object objOpt = System.Reflection.Missing.Value;
			Excel.Workbook workBook = null;
			Excel.Sheets sheets;
			Excel.Worksheet worksheet;
			Excel.Range range;
			try
			{
				int iRowCount = 0;
				int iColCount = 0;
				string cellContent = null;
				#region city
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0106a.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					ERaceType race = (ERaceType)(j - 1);
					for ( int i = 3; i <= iRowCount; i++ )
					{
						range = worksheet.Cells[ i, 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "Other";
						EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
						range = worksheet.Cells[ i, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						if ( maleNum != 0 )
						{
							IndJointDis maleJointDis = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour,
								resideProv, race, EProvince.Other, EEducateLevel.infant, EResidenceType.city, ERegistType.other );
							jointDis.Add( maleJointDis, maleNum );
						}
						range = worksheet.Cells[ i, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						if ( femaleNum != 0 )
						{
							IndJointDis femaleJointDis = new IndJointDis( EGender.Female, EAgeInterval.ZeroToFour,
								resideProv, race, EProvince.Other, EEducateLevel.infant, EResidenceType.city, ERegistType.other );
							jointDis.Add( femaleJointDis, femaleNum );
						}
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region town
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0106b.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					ERaceType race = (ERaceType)(j - 1);
					for ( int i = 3; i <= iRowCount; i++ )
					{
						range = worksheet.Cells[ i, 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "Other";
						EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
						range = worksheet.Cells[ i, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						if ( maleNum != 0 )
						{
							IndJointDis maleJointDis = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour,
								resideProv, race, EProvince.Other, EEducateLevel.infant, EResidenceType.town, ERegistType.other );
							jointDis.Add( maleJointDis, maleNum );
						}
						range = worksheet.Cells[ i, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						if ( femaleNum != 0 )
						{
							IndJointDis femaleJointDis = new IndJointDis( EGender.Female, EAgeInterval.ZeroToFour,
								resideProv, race, EProvince.Other, EEducateLevel.infant, EResidenceType.town, ERegistType.other );
							jointDis.Add( femaleJointDis, femaleNum );
						}
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region rural
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0106c.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					ERaceType race = (ERaceType)(j - 1);
					for ( int i = 3; i <= iRowCount; i++ )
					{
						range = worksheet.Cells[ i, 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "Other";
						EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
						range = worksheet.Cells[ i, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						if ( maleNum != 0 )
						{
							IndJointDis maleJointDis = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour,
								resideProv, race, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.other );
							jointDis.Add( maleJointDis, maleNum );
						}
						range = worksheet.Cells[ i, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						if ( femaleNum != 0 )
						{
							IndJointDis femaleJointDis = new IndJointDis( EGender.Female, EAgeInterval.ZeroToFour,
								resideProv, race, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.other );
							jointDis.Add( femaleJointDis, femaleNum );
						}
					}
				}
				#endregion
			} catch ( Exception e )
			{
				throw new ApplicationException( e.Message );
			} finally
			{
				if ( workBook != null )
				{
					workBook.Close( false, objOpt, objOpt );
					System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
					workBook = null;
				}
				excelApp.Workbooks.Close( );
				excelApp.Quit( );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( excelApp );
				excelApp = null;
				GC.Collect( );
				GC.WaitForPendingFinalizers( );
			}
			HashSet<EProvince> resideProvSet = new HashSet<EProvince>( );
			HashSet<ERaceType> raceTypeSet = new HashSet<ERaceType>( );
			HashSet<EResidenceType> residenceTypeSet = new HashSet<EResidenceType>( );
			HashSet<EGender> genderSet = new HashSet<EGender>( );
			foreach ( IndJointDis parDis in jointDis.Keys )
			{
				resideProvSet.Add( parDis.ResideProvin );
				raceTypeSet.Add( parDis.Race );
				residenceTypeSet.Add( parDis.ResidenceType );
				genderSet.Add( parDis.Gender );
			}
			//Residential Province conditional probability
			foreach ( ERaceType race in raceTypeSet )
			{
				foreach ( EResidenceType resiType in residenceTypeSet )
				{
					foreach ( EGender gender in genderSet )
					{
						uint sumNum = 0;
						foreach ( IndJointDis parDis in jointDis.Keys )
						{
							if ( parDis.Gender == gender && parDis.ResidenceType == resiType && parDis.Race == race )
								sumNum += jointDis[ parDis ];
						}
						foreach ( EProvince resiProv in resideProvSet )
						{
							foreach ( IndJointDis parDis in jointDis.Keys )
							{
								if ( parDis.ResideProvin == resiProv && parDis.Gender == gender
									&& parDis.ResidenceType == resiType && parDis.Race == race )
								{
									IndJointDis newResideProvCon = new IndJointDis( gender, EAgeInterval.ZeroToFour,
										resiProv, race, EProvince.Other, EEducateLevel.infant, resiType, ERegistType.other );
									resideProvCon.Add( newResideProvCon, (float)jointDis[ parDis ] / sumNum );
									break;
								}
							}
						}
					}
				}
			}
			//Ethnic Group conditional probability
			foreach ( EProvince resiProv in resideProvSet )
			{
				foreach ( EResidenceType resiType in residenceTypeSet )
				{
					foreach ( EGender gender in genderSet )
					{
						uint sumNum = 0;
						foreach ( IndJointDis parDis in jointDis.Keys )
						{
							if ( parDis.Gender == gender && parDis.ResidenceType == resiType && parDis.ResideProvin == resiProv )
								sumNum += jointDis[ parDis ];
						}
						foreach ( ERaceType race in raceTypeSet )
						{
							foreach ( IndJointDis parDis in jointDis.Keys )
							{
								if ( parDis.Race == race && parDis.Gender == gender
									&& parDis.ResidenceType == resiType && parDis.ResideProvin == resiProv )
								{
									IndJointDis newRaceCon = new IndJointDis( gender, EAgeInterval.ZeroToFour,
										resiProv, race, EProvince.Other, EEducateLevel.infant, resiType, ERegistType.other );
									raceCon.Add( newRaceCon, (float)jointDis[ parDis ] / sumNum );
									break;
								}
							}
						}
					}
				}
			}
			//Residence Type conditional probability
			foreach ( EProvince resiProv in resideProvSet )
			{
				foreach ( ERaceType race in raceTypeSet )
				{
					foreach ( EGender gender in genderSet )
					{
						uint sumNum = 0;
						foreach ( IndJointDis parDis in jointDis.Keys )
						{
							if ( parDis.Gender == gender && parDis.Race == race && parDis.ResideProvin == resiProv )
								sumNum += jointDis[ parDis ];
						}
						foreach ( EResidenceType resiType in residenceTypeSet )
						{
							foreach ( IndJointDis parDis in jointDis.Keys )
							{
								if ( parDis.ResidenceType == resiType && parDis.Gender == gender
									&& parDis.Race == race && parDis.ResideProvin == resiProv )
								{
									IndJointDis newResideTypeCon = new IndJointDis( gender, EAgeInterval.ZeroToFour,
										resiProv, race, EProvince.Other, EEducateLevel.infant, resiType, ERegistType.other );
									resideTypeCon.Add( newResideTypeCon, (float)jointDis[ parDis ] / sumNum );
									break;
								}
							}
						}
					}
				}
			}
			//Gender conditional probability
			foreach ( EProvince resiProv in resideProvSet )
			{
				foreach ( ERaceType race in raceTypeSet )
				{
					foreach ( EResidenceType resiType in residenceTypeSet )
					{
						uint sumNum = 0;
						foreach ( IndJointDis parDis in jointDis.Keys )
						{
							if ( parDis.ResidenceType == resiType && parDis.Race == race && parDis.ResideProvin == resiProv )
								sumNum += jointDis[ parDis ];
						}
						foreach ( EGender gender in genderSet )
						{
							foreach ( IndJointDis parDis in jointDis.Keys )
							{
								if ( parDis.Gender == gender && parDis.ResidenceType == resiType
									&& parDis.Race == race && parDis.ResideProvin == resiProv )
								{
									IndJointDis newGenderCon = new IndJointDis( gender, EAgeInterval.ZeroToFour,
										resiProv, race, EProvince.Other, EEducateLevel.infant, resiType, ERegistType.other );
									genderCon.Add( newGenderCon, (float)jointDis[ parDis ] / sumNum );
									break;
								}
							}
						}
					}
				}
			}
		}

		/// <summary>
		/// compute Age Interval transfer probability
		/// </summary>
		private void GetAgeIntervalCon( )
		{
			Dictionary<IndJointDis, uint> jointDis = new Dictionary<IndJointDis, uint>( );
			Excel.Application excelApp = new Excel.Application( );
			object objOpt = System.Reflection.Missing.Value;
			Excel.Workbook workBook = null;
			Excel.Sheets sheets;
			Excel.Worksheet worksheet;
			Excel.Range range;
			try
			{
				int iRowCount = 0;
				int iColCount = 0;
				string cellContent = null;
				#region city
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0107a.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					for ( int j = 3; j <= iColCount; j++ )
					{
						range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EAgeInterval ageInter = (EAgeInterval)(j - 3);
						range = worksheet.Cells[ i, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						range = worksheet.Cells[ i, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						IndJointDis newMaleJointdis = new IndJointDis( EGender.Male, ageInter, resideProv,
							ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.city, ERegistType.other );
						jointDis.Add( newMaleJointdis, maleNum );
						IndJointDis newFemaleJointdis = new IndJointDis( EGender.Female, ageInter, resideProv,
							ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.city, ERegistType.other );
						jointDis.Add( newFemaleJointdis, femaleNum );
					}
					range = worksheet.Cells[ i, 3 * 2 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint zeroMaleNum = uint.Parse( cellContent );
					range = worksheet.Cells[ i, 3 * 2 + 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint zeroFemaleNum = uint.Parse( cellContent );
					List<IndJointDis> keys = new List<IndJointDis>( );
					keys.AddRange( jointDis.Keys );
					foreach ( IndJointDis parDis in keys )
					{
						if ( parDis.Gender == EGender.Male && parDis.ResideProvin == resideProv
							&& parDis.ResidenceType == EResidenceType.city && parDis.Age == EAgeInterval.ZeroToFour )
						{
							jointDis[ parDis ] += zeroMaleNum;
						}
						if ( parDis.Gender == EGender.Female && parDis.ResideProvin == resideProv
							&& parDis.ResidenceType == EResidenceType.city && parDis.Age == EAgeInterval.ZeroToFour )
						{
							jointDis[ parDis ] += zeroFemaleNum;
						}
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region town
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0107b.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					for ( int j = 3; j <= iColCount; j++ )
					{
						range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EAgeInterval ageInter = (EAgeInterval)(j - 3);
						range = worksheet.Cells[ i, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						range = worksheet.Cells[ i, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						IndJointDis newMaleJointdis = new IndJointDis( EGender.Male, ageInter, resideProv,
							ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.town, ERegistType.other );
						jointDis.Add( newMaleJointdis, maleNum );
						IndJointDis newFemaleJointdis = new IndJointDis( EGender.Female, ageInter, resideProv,
							ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.town, ERegistType.other );
						jointDis.Add( newFemaleJointdis, femaleNum );
					}
					range = worksheet.Cells[ i, 3 * 2 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint zeroMaleNum = uint.Parse( cellContent );
					range = worksheet.Cells[ i, 3 * 2 + 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint zeroFemaleNum = uint.Parse( cellContent );
					List<IndJointDis> keys = new List<IndJointDis>( );
					keys.AddRange( jointDis.Keys );
					foreach ( IndJointDis parDis in keys )
					{
						if ( parDis.Gender == EGender.Male && parDis.ResideProvin == resideProv
							&& parDis.ResidenceType == EResidenceType.town && parDis.Age == EAgeInterval.ZeroToFour )
						{
							jointDis[ parDis ] += zeroMaleNum;
						}
						if ( parDis.Gender == EGender.Female && parDis.ResideProvin == resideProv
							&& parDis.ResidenceType == EResidenceType.town && parDis.Age == EAgeInterval.ZeroToFour )
						{
							jointDis[ parDis ] += zeroFemaleNum;
						}
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region rural
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0107c.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					for ( int j = 3; j <= iColCount; j++ )
					{
						range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EAgeInterval ageInter = (EAgeInterval)(j - 3);
						range = worksheet.Cells[ i, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						range = worksheet.Cells[ i, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						IndJointDis newMaleJointdis = new IndJointDis( EGender.Male, ageInter, resideProv,
							ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.other );
						jointDis.Add( newMaleJointdis, maleNum );
						IndJointDis newFemaleJointdis = new IndJointDis( EGender.Female, ageInter, resideProv,
							ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.other );
						jointDis.Add( newFemaleJointdis, femaleNum );
					}
					range = worksheet.Cells[ i, 3 * 2 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint zeroMaleNum = uint.Parse( cellContent );
					range = worksheet.Cells[ i, 3 * 2 + 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint zeroFemaleNum = uint.Parse( cellContent );
					List<IndJointDis> keys = new List<IndJointDis>( );
					keys.AddRange( jointDis.Keys );
					foreach ( IndJointDis parDis in keys )
					{
						if ( parDis.Gender == EGender.Male && parDis.ResideProvin == resideProv
							&& parDis.ResidenceType == EResidenceType.rural && parDis.Age == EAgeInterval.ZeroToFour )
						{
							jointDis[ parDis ] += zeroMaleNum;
						}
						if ( parDis.Gender == EGender.Female && parDis.ResideProvin == resideProv
							&& parDis.ResidenceType == EResidenceType.rural && parDis.Age == EAgeInterval.ZeroToFour )
						{
							jointDis[ parDis ] += zeroFemaleNum;
						}
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
			} catch ( Exception e )
			{
				throw new ApplicationException( e.Message );
			} finally
			{
				if ( workBook != null )
				{
					workBook.Close( false, objOpt, objOpt );
					System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
					workBook = null;
				}
				excelApp.Workbooks.Close( );
				excelApp.Quit( );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( excelApp );
				excelApp = null;
				GC.Collect( );
				GC.WaitForPendingFinalizers( );
			}
			HashSet<EResidenceType> residenceTypeSet = new HashSet<EResidenceType>( );
			HashSet<EProvince> resideProvSet = new HashSet<EProvince>( );
			HashSet<EGender> genderSet = new HashSet<EGender>( );
			HashSet<EAgeInterval> ageSet = new HashSet<EAgeInterval>( );
			foreach ( IndJointDis parDis in jointDis.Keys )
			{
				resideProvSet.Add( parDis.ResideProvin );
				residenceTypeSet.Add( parDis.ResidenceType );
				genderSet.Add( parDis.Gender );
				ageSet.Add( parDis.Age );
			}
			foreach ( EResidenceType resiType in residenceTypeSet )
			{
				foreach ( EProvince resiProv in resideProvSet )
				{
					foreach ( EGender gender in genderSet )
					{
						uint sumNum = 0;
						foreach ( IndJointDis parDis in jointDis.Keys )
						{
							if ( parDis.Gender == gender && parDis.ResideProvin == resiProv && parDis.ResidenceType == resiType )
								sumNum += jointDis[ parDis ];
						}
						foreach ( EAgeInterval ageInter in ageSet )
						{
							foreach ( IndJointDis parDis in jointDis.Keys )
							{
								if ( parDis.Age == ageInter && parDis.Gender == gender
									&& parDis.ResideProvin == resiProv && parDis.ResidenceType == resiType )
								{
									IndJointDis newAgeCon = new IndJointDis( gender, ageInter, resiProv,
										ERaceType.Other, EProvince.Other, EEducateLevel.infant, resiType, ERegistType.other );
									ageCon.Add( newAgeCon, (float)jointDis[ parDis ] / sumNum );
									break;
								}
							}
						}
					}
				}
			}
		}

		/// <summary>
		/// compute Educational Level transfer probability
		/// </summary>
		private void GetEduLevelCon( )
		{
			Dictionary<IndJointDis, uint> jointDis = new Dictionary<IndJointDis, uint>( );
			Excel.Application excelApp = new Excel.Application( );
			object objOpt = System.Reflection.Missing.Value;
			Excel.Workbook workBook = null;
			Excel.Sheets sheets;
			Excel.Worksheet worksheet;
			Excel.Range range;
			try
			{
				int iRowCount = 0;
				int iColCount = 0;
				string cellContent = null;
				#region city
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0401a.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 2; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ 6 * i - 4, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EAgeInterval ageInter = (EAgeInterval)i;
					for ( int j = 2; j <= iColCount; j++ )
					{
						range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EEducateLevel eduLevel = (EEducateLevel)(j - 1);
						range = worksheet.Cells[ 6 * i - 4, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						range = worksheet.Cells[ 6 * i - 4, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						IndJointDis newMaleEduLvJointDis = new IndJointDis( EGender.Male, ageInter, EProvince.Other,
							ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
						jointDis.Add( newMaleEduLvJointDis, maleNum );
						IndJointDis newFemaleEduLvJointDis = new IndJointDis( EGender.Female, ageInter, EProvince.Other,
							ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
						jointDis.Add( newFemaleEduLvJointDis, femaleNum );
					}
				}
				//6-9 year old people:
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EEducateLevel eduLevel = (EEducateLevel)(j - 1);
					range = worksheet.Cells[ 3, 3 * j ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint maleNum = uint.Parse( cellContent );
					range = worksheet.Cells[ 3, 3 * j + 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint femaleNum = uint.Parse( cellContent );
					IndJointDis newMaleEduLvJointDis = new IndJointDis( EGender.Male, EAgeInterval.FiveToNine, EProvince.Other,
						ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
					jointDis.Add( newMaleEduLvJointDis, maleNum );
					IndJointDis newFemaleEduLvJointDis = new IndJointDis( EGender.Female, EAgeInterval.FiveToNine, EProvince.Other,
						ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
					jointDis.Add( newFemaleEduLvJointDis, femaleNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region town
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0401b.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 2; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ 6 * i - 4, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EAgeInterval ageInter = (EAgeInterval)i;
					for ( int j = 2; j <= iColCount; j++ )
					{
						range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EEducateLevel eduLevel = (EEducateLevel)(j - 1);
						range = worksheet.Cells[ 6 * i - 4, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						range = worksheet.Cells[ 6 * i - 4, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						IndJointDis newMaleEduLvJointDis = new IndJointDis( EGender.Male, ageInter, EProvince.Other,
							ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
						jointDis.Add( newMaleEduLvJointDis, maleNum );
						IndJointDis newFemaleEduLvJointDis = new IndJointDis( EGender.Female, ageInter, EProvince.Other,
							ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
						jointDis.Add( newFemaleEduLvJointDis, femaleNum );
					}
				}
				//6-9 year old people:
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EEducateLevel eduLevel = (EEducateLevel)(j - 1);
					range = worksheet.Cells[ 3, 3 * j ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint maleNum = uint.Parse( cellContent );
					range = worksheet.Cells[ 3, 3 * j + 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint femaleNum = uint.Parse( cellContent );
					IndJointDis newMaleEduLvJointDis = new IndJointDis( EGender.Male, EAgeInterval.FiveToNine, EProvince.Other,
						ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
					jointDis.Add( newMaleEduLvJointDis, maleNum );
					IndJointDis newFemaleEduLvJointDis = new IndJointDis( EGender.Female, EAgeInterval.FiveToNine, EProvince.Other,
						ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
					jointDis.Add( newFemaleEduLvJointDis, femaleNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region rural
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0401c.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 2; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ 6 * i - 4, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EAgeInterval ageInter = (EAgeInterval)i;
					for ( int j = 2; j <= iColCount; j++ )
					{
						range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EEducateLevel eduLevel = (EEducateLevel)(j - 1);
						range = worksheet.Cells[ 6 * i - 4, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						range = worksheet.Cells[ 6 * i - 4, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						IndJointDis newMaleEduLvJointDis = new IndJointDis( EGender.Male, ageInter, EProvince.Other,
							ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
						jointDis.Add( newMaleEduLvJointDis, maleNum );
						IndJointDis newFemaleEduLvJointDis = new IndJointDis( EGender.Female, ageInter, EProvince.Other,
							ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
						jointDis.Add( newFemaleEduLvJointDis, femaleNum );
					}
				}
				//6-9 year old people:
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EEducateLevel eduLevel = (EEducateLevel)(j - 1);
					range = worksheet.Cells[ 3, 3 * j ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint maleNum = uint.Parse( cellContent );
					range = worksheet.Cells[ 3, 3 * j + 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint femaleNum = uint.Parse( cellContent );
					IndJointDis newMaleEduLvJointDis = new IndJointDis( EGender.Male, EAgeInterval.FiveToNine, EProvince.Other,
						ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
					jointDis.Add( newMaleEduLvJointDis, maleNum );
					IndJointDis newFemaleEduLvJointDis = new IndJointDis( EGender.Female, EAgeInterval.FiveToNine, EProvince.Other,
						ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
					jointDis.Add( newFemaleEduLvJointDis, femaleNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
			} catch ( Exception e )
			{
				throw new ApplicationException( e.Message );
			} finally
			{
				if ( workBook != null )
				{
					workBook.Close( false, objOpt, objOpt );
					System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
					workBook = null;
				}
				excelApp.Workbooks.Close( );
				excelApp.Quit( );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( excelApp );
				excelApp = null;
				GC.Collect( );
				GC.WaitForPendingFinalizers( );
			}
			HashSet<EResidenceType> residenceTypeSet = new HashSet<EResidenceType>( );
			HashSet<EAgeInterval> ageSet = new HashSet<EAgeInterval>( );
			HashSet<EGender> genderSet = new HashSet<EGender>( );
			HashSet<EEducateLevel> eduLevelSet = new HashSet<EEducateLevel>( );
			foreach ( IndJointDis parDis in jointDis.Keys )
			{
				residenceTypeSet.Add( parDis.ResidenceType );
				genderSet.Add( parDis.Gender );
				ageSet.Add( parDis.Age );
				eduLevelSet.Add( parDis.EduLevel );
			}
			foreach ( EResidenceType resiType in residenceTypeSet )
			{
				foreach ( EGender gender in genderSet )
				{
					foreach ( EAgeInterval ageInter in ageSet )
					{
						uint sumNum = 0;
						foreach ( IndJointDis parDis in jointDis.Keys )
						{
							if ( parDis.Age == ageInter && parDis.Gender == gender && parDis.ResidenceType == resiType )
								sumNum += jointDis[ parDis ];
						}
						foreach ( EEducateLevel eduLv in eduLevelSet )
						{
							foreach ( IndJointDis parDis in jointDis.Keys )
							{
								if ( parDis.EduLevel == eduLv && parDis.Age == ageInter
									&& parDis.Gender == gender && parDis.ResidenceType == resiType )
								{
									IndJointDis newEduLvCon = new IndJointDis( gender, ageInter, EProvince.Other,
										ERaceType.Other, EProvince.Other, eduLv, resiType, ERegistType.other );
									eduLevelCon.Add( newEduLvCon, (float)jointDis[ parDis ] / sumNum );
									if ( ageInter == EAgeInterval.SixtyFiveToSixtyNine )
									{
										IndJointDis EduLvCon70_74 = new IndJointDis( gender, EAgeInterval.SeventyToSeventyFour,
											EProvince.Other, ERaceType.Other, EProvince.Other, eduLv, resiType, ERegistType.other );
										eduLevelCon.Add( EduLvCon70_74, (float)jointDis[ parDis ] / sumNum );
										IndJointDis EduLvCon75_79 = new IndJointDis( gender, EAgeInterval.SeventyFiveToSeventyNine,
											EProvince.Other, ERaceType.Other, EProvince.Other, eduLv, resiType, ERegistType.other );
										eduLevelCon.Add( EduLvCon75_79, (float)jointDis[ parDis ] / sumNum );
										IndJointDis EduLvCon80_84 = new IndJointDis( gender, EAgeInterval.EightyToEightyFour,
											EProvince.Other, ERaceType.Other, EProvince.Other, eduLv, resiType, ERegistType.other );
										eduLevelCon.Add( EduLvCon80_84, (float)jointDis[ parDis ] / sumNum );
										IndJointDis EduLvCon85_89 = new IndJointDis( gender, EAgeInterval.EightyFiveToEightyNine,
											EProvince.Other, ERaceType.Other, EProvince.Other, eduLv, resiType, ERegistType.other );
										eduLevelCon.Add( EduLvCon85_89, (float)jointDis[ parDis ] / sumNum );
										IndJointDis EduLvCon90_94 = new IndJointDis( gender, EAgeInterval.NinetyToNinetyFour,
											EProvince.Other, ERaceType.Other, EProvince.Other, eduLv, resiType, ERegistType.other );
										eduLevelCon.Add( EduLvCon90_94, (float)jointDis[ parDis ] / sumNum );
										IndJointDis EduLvCon95_99 = new IndJointDis( gender, EAgeInterval.NinetyFiveToNinetyNine,
											EProvince.Other, ERaceType.Other, EProvince.Other, eduLv, resiType, ERegistType.other );
										eduLevelCon.Add( EduLvCon95_99, (float)jointDis[ parDis ] / sumNum );
										IndJointDis EduLvCon100 = new IndJointDis( gender, EAgeInterval.HundredAndAbove,
											EProvince.Other, ERaceType.Other, EProvince.Other, eduLv, resiType, ERegistType.other );
										eduLevelCon.Add( EduLvCon100, (float)jointDis[ parDis ] / sumNum );
									}
									break;
								}
							}
						}
					}
					IndJointDis infantEduLvCon = new IndJointDis( gender, EAgeInterval.ZeroToFour,
						EProvince.Other, ERaceType.Other, EProvince.Other, EEducateLevel.infant, resiType, ERegistType.other );
					eduLevelCon.Add( infantEduLvCon, 1 );//0-4 year old
				}
			}
		}

		/// <summary>
		/// update individual's attributes according to transfer probabilities
		/// </summary>
		private void UpdateSeed( ref IndJointDis seed )
		{
			//Gender
			double maleProb = 0;
			double femaleProb = 0;
			foreach ( IndJointDis parDis in genderCon.Keys )
			{
				if ( parDis.ResidenceType == seed.ResidenceType && parDis.Race == seed.Race && parDis.ResideProvin == seed.ResideProvin )
				{
					if ( parDis.Gender == EGender.Male )
						maleProb = genderCon[ parDis ];
					else if ( parDis.Gender == EGender.Female )
						femaleProb = genderCon[ parDis ];
				}
			}
			if ( rand.NextDouble( ) <= maleProb )
				seed.Gender = EGender.Male;
			else
				seed.Gender = EGender.Female;
			//Age
			double[ ] ageInterProb = new double[ 21 ];
			foreach ( IndJointDis parDis in ageCon.Keys )
			{
				if ( parDis.ResidenceType == seed.ResidenceType && parDis.ResideProvin == seed.ResideProvin && parDis.Gender == seed.Gender )
				{
					EAgeInterval age = parDis.Age;
					ageInterProb[ (int)age ] = ageCon[ parDis ];
				}
			}
			double ageRatio = rand.NextDouble( );
			double sumRatio = 0;
			for ( int i = 0; i < ageInterProb.Length; i++ )
			{
				sumRatio += ageInterProb[ i ];
				if ( ageRatio <= sumRatio )
				{
					seed.Age = (EAgeInterval)i;
					break;
				}
			}
			//Residential Province
			Dictionary<IndJointDis, double> resideProvProb = new Dictionary<IndJointDis, double>( );
			foreach ( IndJointDis parDis in resideProvCon.Keys )
			{
				if ( parDis.ResidenceType == seed.ResidenceType && parDis.Race == seed.Race && parDis.Gender == seed.Gender )
				{
					resideProvProb.Add( new IndJointDis( parDis.Gender, parDis.Age, parDis.ResideProvin, parDis.Race,
						parDis.RegistProvin, parDis.EduLevel, parDis.ResidenceType, parDis.RegistType ), resideProvCon[ parDis ] );
				}
			}
			List<IndJointDis> resideProvKeys = new List<IndJointDis>( );
			resideProvKeys.AddRange( resideProvProb.Keys );
			double resideProvRatio = rand.NextDouble( );
			sumRatio = 0;
			for ( int i = 0; i < resideProvKeys.Count; i++ )
			{
				sumRatio += resideProvProb[ resideProvKeys[ i ] ];
				if ( resideProvRatio <= sumRatio )
				{
					seed.ResideProvin = resideProvKeys[ i ].ResideProvin;
					break;
				}
			}
			//Ethnic Group
			double[ ] raceProb = new double[ 58 ];
			foreach ( IndJointDis parDis in raceCon.Keys )
			{
				if ( parDis.ResidenceType == seed.ResidenceType && parDis.ResideProvin == seed.ResideProvin && parDis.Gender == seed.Gender )
				{
					ERaceType race = parDis.Race;
					raceProb[ (int)race - 1 ] = raceCon[ parDis ];
				}
			}
			double raceRatio = rand.NextDouble( );
			sumRatio = 0;
			for ( int i = 0; i < raceProb.Length; i++ )
			{
				sumRatio += raceProb[ i ];
				if ( raceRatio <= sumRatio )
				{
					seed.Race = (ERaceType)(i + 1);
					break;
				}
			}
			//Registration Province
			Dictionary<IndJointDis, double> registProvProb = new Dictionary<IndJointDis, double>( );
			foreach ( IndJointDis parDis in registProvCon.Keys )
			{
				if ( parDis.ResideProvin == seed.ResideProvin && parDis.RegistType == seed.RegistType && parDis.Gender == seed.Gender )
				{
					registProvProb.Add( new IndJointDis( parDis.Gender, parDis.Age, parDis.ResideProvin, parDis.Race,
						parDis.RegistProvin, parDis.EduLevel, parDis.ResidenceType, parDis.RegistType ), registProvCon[ parDis ] );
				}
			}
			List<IndJointDis> registProvKeys = new List<IndJointDis>( );
			registProvKeys.AddRange( registProvProb.Keys );
			double registProvRatio = rand.NextDouble( );
			sumRatio = 0;
			for ( int i = 0; i < registProvKeys.Count; i++ )
			{
				sumRatio += registProvProb[ registProvKeys[ i ] ];
				if ( registProvRatio <= sumRatio )
				{
					seed.RegistProvin = registProvKeys[ i ].RegistProvin;
					break;
				}
			}
			//Educational Level
			double[ ] eduLvProb = new double[ 10 ];
			foreach ( IndJointDis parDis in eduLevelCon.Keys )
			{
				if ( parDis.ResidenceType == seed.ResidenceType && parDis.Age == seed.Age && parDis.Gender == seed.Gender )
				{
					EEducateLevel eduLv = parDis.EduLevel;
					eduLvProb[ (int)eduLv ] = eduLevelCon[ parDis ];
				}
			}
			double eduLvRatio = rand.NextDouble( );
			sumRatio = 0;
			for ( int i = 0; i < eduLvProb.Length; i++ )
			{
				sumRatio += eduLvProb[ i ];
				if ( eduLvRatio <= sumRatio )
				{
					seed.EduLevel = (EEducateLevel)i;
					break;
				}
			}
			//Residence Type
			double resideCity = 0;
			double resideTown = 0;
			double resideRural = 0;
			foreach ( IndJointDis parDis in resideTypeCon.Keys )
			{
				if ( parDis.ResideProvin == seed.ResideProvin && parDis.Race == seed.Race && parDis.Gender == seed.Gender )
				{
					if ( parDis.ResidenceType == EResidenceType.city )
						resideCity = resideTypeCon[ parDis ];
					else if ( parDis.ResidenceType == EResidenceType.town )
						resideTown = resideTypeCon[ parDis ];
					else if ( parDis.ResidenceType == EResidenceType.rural )
						resideRural = resideTypeCon[ parDis ];
				}
			}
			double resideTypeRatio = rand.NextDouble( );
			if ( resideTypeRatio <= resideCity )
				seed.ResidenceType = EResidenceType.city;
			else if ( resideTypeRatio <= resideCity + resideTown )
				seed.ResidenceType = EResidenceType.town;
			else
				seed.ResidenceType = EResidenceType.rural;
			//Registration Type
			double registUrban = 0;
			double registRural = 0;
			double registOther = 0;
			foreach ( IndJointDis parDis in registTypeCon.Keys )
			{
				if ( parDis.ResideProvin == seed.ResideProvin && parDis.Gender == seed.Gender )
				{
					if ( parDis.RegistType == ERegistType.urban )
						registUrban = registTypeCon[ parDis ];
					else if ( parDis.RegistType == ERegistType.rural )
						registRural = registTypeCon[ parDis ];
					else if ( parDis.RegistType == ERegistType.other )
						registOther = registTypeCon[ parDis ];
				}
			}
			double registTypeRatio = rand.NextDouble( );
			if ( registTypeRatio <= registUrban )
				seed.RegistType = ERegistType.urban;
			else if ( registTypeRatio <= registUrban + registRural )
				seed.RegistType = ERegistType.rural;
			else
				seed.RegistType = ERegistType.other;
		}
	}
}
