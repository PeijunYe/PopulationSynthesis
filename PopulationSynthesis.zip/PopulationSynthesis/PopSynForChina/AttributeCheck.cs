﻿
namespace PopSynForChina
{
	public class AttributeCheck
	{
		/// <summary>
		/// check the Ethnic Group from the input string name
		/// </summary>
		/// <param name="raceName"></param>
		/// <returns></returns>
		public static ERaceType CheckRace( string raceName )
		{
			ERaceType result = ERaceType.Other;
			switch ( raceName )
			{
				case "汉族": result = ERaceType.Han; break;
				case "蒙古族": result = ERaceType.MengGu; break;
				case "回族": result = ERaceType.Hui; break;
				case "藏族": result = ERaceType.Zang; break;
				case "维吾尔族": result = ERaceType.WeiWuEr; break;
				case "苗族": result = ERaceType.Miao; break;
				case "彝族": result = ERaceType.Yi; break;
				case "壮族": result = ERaceType.Zhuang; break;
				case "布衣族": result = ERaceType.BuYi; break;
				case "布依族": result = ERaceType.BuYi; break;
				case "朝鲜族": result = ERaceType.ChaoXian; break;
				case "满族": result = ERaceType.Man; break;
				case "侗族": result = ERaceType.Dong; break;
				case "瑶族": result = ERaceType.Yao; break;
				case "白族": result = ERaceType.Bai; break;
				case "土家族": result = ERaceType.TuJia; break;
				case "哈尼族": result = ERaceType.HaNi; break;
				case "哈萨克族": result = ERaceType.HaSaKe; break;
				case "傣族": result = ERaceType.Dai; break;
				case "黎族": result = ERaceType.Li; break;
				case "傈僳族": result = ERaceType.LiSu; break;
				case "佤族": result = ERaceType.Wa; break;
				case "畲族": result = ERaceType.She; break;
				case "高山族": result = ERaceType.GaoShan; break;
				case "拉祜族": result = ERaceType.LaHu; break;
				case "水族": result = ERaceType.Shui; break;
				case "东乡族": result = ERaceType.DongXiang; break;
				case "纳西族": result = ERaceType.NaXi; break;
				case "景颇族": result = ERaceType.JingPo; break;
				case "柯尔克孜族": result = ERaceType.KeErKeZi; break;
				case "柯尔柯孜族": result = ERaceType.KeErKeZi; break;
				case "土族": result = ERaceType.Tu; break;
				case "达斡尔族": result = ERaceType.DaWoEr; break;
				case "仫佬族": result = ERaceType.MuLao; break;
				case "羌族": result = ERaceType.Qiang; break;
				case "布朗族": result = ERaceType.BuLang; break;
				case "撒拉族": result = ERaceType.SaLa; break;
				case "毛南族": result = ERaceType.MaoNan; break;
				case "仡佬族": result = ERaceType.GeLao; break;
				case "锡伯族": result = ERaceType.XiBo; break;
				case "阿昌族": result = ERaceType.AChang; break;
				case "普米族": result = ERaceType.PuMi; break;
				case "塔吉克族": result = ERaceType.TaJiKe; break;
				case "怒族": result = ERaceType.Nu; break;
				case "乌孜别克族": result = ERaceType.WuZiBieKe; break;
				case "俄罗斯族": result = ERaceType.ELuoSi; break;
				case "鄂温克族": result = ERaceType.EWenKe; break;
				case "德昂族": result = ERaceType.DeAng; break;
				case "保安族": result = ERaceType.BaoAn; break;
				case "裕固族": result = ERaceType.YuGu; break;
				case "京族": result = ERaceType.Jing; break;
				case "塔塔尔族": result = ERaceType.TaTaEr; break;
				case "独龙族": result = ERaceType.DuLong; break;
				case "鄂伦春族": result = ERaceType.ELunChun; break;
				case "赫哲族": result = ERaceType.HeZhe; break;
				case "门巴族": result = ERaceType.MenBa; break;
				case "珞巴族": result = ERaceType.LuoBa; break;
				case "基诺族": result = ERaceType.JiNuo; break;
				case "其他未识别民族": result = ERaceType.Other; break;
				case "外国人加入中国籍": result = ERaceType.Foreign; break;
			}
			return result;
		}

		/// <summary>
		/// check the Age Interval from the input string
		/// </summary>
		/// <param name="age"></param>
		/// <returns></returns>
		public static EAgeInterval CheckAgeInterval( ushort age )
		{
			if ( age < 5 )
				return EAgeInterval.ZeroToFour;
			else if ( age < 10 )
				return EAgeInterval.FiveToNine;
			else if ( age < 15 )
				return EAgeInterval.TenToFourteen;
			else if ( age < 20 )
				return EAgeInterval.FifteenToNineteen;
			else if ( age < 25 )
				return EAgeInterval.TwentyToTwentyFour;
			else if ( age < 30 )
				return EAgeInterval.TwentyFiveToTwentyNine;
			else if ( age < 35 )
				return EAgeInterval.ThirtyToThirtyFour;
			else if ( age < 40 )
				return EAgeInterval.ThirtyFiveToThirtyNine;
			else if ( age < 45 )
				return EAgeInterval.FortyToFortyFour;
			else if ( age < 50 )
				return EAgeInterval.FortyFiveToFortyNine;
			else if ( age < 55 )
				return EAgeInterval.FiftyToFiftyFour;
			else if ( age < 60 )
				return EAgeInterval.FiftyFiveToFiftyNine;
			else if ( age < 65 )
				return EAgeInterval.SixtyToSixtyFour;
			else if ( age < 70 )
				return EAgeInterval.SixtyFiveToSixtyNine;
			else if ( age < 75 )
				return EAgeInterval.SeventyToSeventyFour;
			else if ( age < 80 )
				return EAgeInterval.SeventyFiveToSeventyNine;
			else if ( age < 85 )
				return EAgeInterval.EightyToEightyFour;
			else if ( age < 90 )
				return EAgeInterval.EightyFiveToEightyNine;
			else if ( age < 95 )
				return EAgeInterval.NinetyToNinetyFour;
			else if ( age < 100 )
				return EAgeInterval.NinetyFiveToNinetyNine;
			else
				return EAgeInterval.HundredAndAbove;
		}

		/// <summary>
		/// check the Province from the input string
		/// </summary>
		/// <param name="provName"></param>
		/// <returns></returns>
		public static EProvince CheckProvince( string provName )
		{
			EProvince result = EProvince.Other;
			switch ( provName )
			{
				case "北京市": result = EProvince.Beijing; break;
				case "天津市": result = EProvince.Tianjin; break;
				case "河北省": result = EProvince.Hebei; break;
				case "山西省": result = EProvince.Shan_1xi; break;
				case "内蒙古自治区": result = EProvince.Neimenggu; break;
				case "辽宁省": result = EProvince.Liaoning; break;
				case "吉林省": result = EProvince.Jilin; break;
				case "黑龙江省": result = EProvince.Heilongjiang; break;
				case "上海市": result = EProvince.Shanghai; break;
				case "江苏省": result = EProvince.Jiangsu; break;
				case "浙江省": result = EProvince.Zhejiang; break;
				case "安徽省": result = EProvince.Anhui; break;
				case "福建省": result = EProvince.Fujian; break;
				case "江西省": result = EProvince.Jiangxi; break;
				case "山东省": result = EProvince.Shandong; break;
				case "河南省": result = EProvince.Henan; break;
				case "湖北省": result = EProvince.Hubei; break;
				case "湖南省": result = EProvince.Hunan; break;
				case "广东省": result = EProvince.Guangdong; break;
				case "广西壮族自治区": result = EProvince.Guangxi; break;
				case "海南省": result = EProvince.Hainan; break;
				case "重庆市": result = EProvince.Chongqing; break;
				case "四川省": result = EProvince.Sichuan; break;
				case "贵州省": result = EProvince.Guizhou; break;
				case "云南省": result = EProvince.Yunnan; break;
				case "西藏自治区": result = EProvince.Xizang; break;
				case "陕西省": result = EProvince.Shan_3xi; break;
				case "甘肃省": result = EProvince.Gansu; break;
				case "青海省": result = EProvince.Qinghai; break;
				case "宁夏回族自治区": result = EProvince.Ningxia; break;
				case "新疆维吾尔自治区": result = EProvince.Xinjiang; break;
			}
			return result;
		}
	}
}
