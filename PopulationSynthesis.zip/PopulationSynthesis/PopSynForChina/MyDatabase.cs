﻿using System.IO;
using LevelDB;

namespace PopSynForChina
{
	public class MyDatabase
	{
		private string dbFullName;//db name
		private DB database;

		public MyDatabase( string dbFullName )
		{
			this.dbFullName = dbFullName;
		}

		public static bool DBExist( string dbFullName )
		{
			bool result = Directory.Exists( dbFullName );
			return result;
		}

		public static void DBDelete( string dbFullName )
		{
			Directory.Delete( dbFullName, true );
		}

		public void DBOpen( )
		{
			database = DB.Open( dbFullName );
		}

		public void WriteAsyn( string keyStr, string valueStr )
		{
			database.Put( WriteOptions.Default, keyStr, valueStr );
		}

		public void WriteSyn( string keyStr, string valueStr )
		{
			WriteOptions wOpt = WriteOptions.Default;
			wOpt.Sync = true;
			database.Put( wOpt, keyStr, valueStr );
		}

		public string Read( string keyStr )
		{
			Slice result = "";
			try
			{
				result = database.Get( ReadOptions.Default, keyStr );
			} catch ( LevelDBException e )
			{
				if ( e.Message.Contains( "NotFound" ) )
					return "";
				else
					throw e;
			}
			return result.ToString( );
		}

		public string ReadOnly( string keyStr )
		{
			ReadOptions rOpt = ReadOptions.Default;
			rOpt.Snapshot = database.GetSnapshot( );
			Slice result = "";
			try
			{
				result = database.Get( rOpt, keyStr );
			} catch ( LevelDBException e )
			{
				if ( e.Message.Contains( "NotFound" ) )
					return "";
				else
					throw e;
			}
			return result.ToString( );
		}

		public void Update( string keyStr, string valueStr )
		{
			WriteAsyn( keyStr, valueStr );
		}

		public void Delete( string keyStr )
		{
			database.Delete( WriteOptions.Default, keyStr );
		}

		public void DBDispose( )
		{
			database.Dispose( );
		}

		public DBIterator GetIterator( )
		{
			return new DBIterator( database.NewIterator( ReadOptions.Default ) );
		}

		public DBIterator GetReadOnlyIterator( )
		{
			ReadOptions option = ReadOptions.Default;
			option.Snapshot = database.GetSnapshot( );
			return new DBIterator( database.NewIterator( option ) );
		}
	}

	public class DBIterator
	{
		private LevelDB.Iterator dbIter;
		public DBIterator( LevelDB.Iterator dbIter )
		{
			this.dbIter = dbIter;
		}
		public string Key( )
		{
			return dbIter.Key( ).ToString( );
		}
		public void Next( )
		{
			dbIter.Next( );
		}
		public void Prev( )
		{
			dbIter.Prev( );
		}
		public void Seek( string key )
		{
			Slice keySlice = key;
			dbIter.Seek( keySlice );
		}
		public void SeekToFirst( )
		{
			dbIter.SeekToFirst( );
		}
		public void SeekToLast( )
		{
			dbIter.SeekToLast( );
		}
		public bool Valid( )
		{
			return dbIter.Valid( );
		}
		public string Value( )
		{
			return dbIter.Value( ).ToString( );
		}
		public void Dispose( )
		{
			dbIter.Dispose( );
		}
	}
}
