﻿using System;
using System.Collections.Generic;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;

namespace PopSynForChina
{
	public class SFFGenerator
	{
		private uint agentID;

		public SFFGenerator( )
		{
			agentID = 0;
		}

		public void PopGeneration( )
		{
			GenRaceByResiProvByResiTypeByGenderPop( );
			Console.WriteLine( "Race by reside province by residence type by gender Pop generated!" );
			UpdateAgeInterval( );
			Console.WriteLine( "Age interval updated!" );
			UpdateEduLevel( );
			Console.WriteLine( "Education level updated!" );
			UpdateRegistType( );
			Console.WriteLine( "Registration type updated!" );
			UpdateRegistProvince( );
			Console.WriteLine( "Registration province updated!" );
		}

		/// <summary>
		/// generate initial population pool
		/// </summary>
		private void GenRaceByResiProvByResiTypeByGenderPop( )
		{
			string populationDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, InputPara.popDBName );
			MyDatabase populationDB = new MyDatabase( populationDBName );
			if ( Directory.Exists( populationDBName ) )
				Directory.Delete( populationDBName, true );
			Excel.Application excelApp = new Excel.Application( );
			object objOpt = System.Reflection.Missing.Value;
			Excel.Workbook workBook = null;
			Excel.Sheets sheets;
			Excel.Worksheet worksheet;
			Excel.Range range;
			try
			{

				int iRowCount = 0;
				int iColCount = 0;
				string cellContent = null;
				//city
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0106a.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					ERaceType race = (ERaceType)(j - 1);
					for ( int i = 3; i <= iRowCount; i++ )
					{
						range = worksheet.Cells[ i, 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "Other";
						EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
						range = worksheet.Cells[ i, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						if ( maleNum != 0 )
						{
							uint targetPopNum = (uint)Math.Round( maleNum * InputPara.popSizeRatio );
							populationDB.DBOpen( );
							for ( int k = 0; k < targetPopNum; k++ )
							{
								Individual newInd = new Individual( agentID, EGender.Male, 0, 0, 0,
									race, EProvince.Other, ERegistType.other, EEducateLevel.infant, resideProv, EResidenceType.city );
								//write db:
								string agentIDStr = agentID.ToString( );
								string valueStr = ((int)newInd.Gender).ToString( );
								valueStr += "-" + newInd.BirthYear.ToString( );
								valueStr += "-" + newInd.BirthMonth.ToString( );
								valueStr += "-" + newInd.Age.ToString( );
								valueStr += "-" + ((int)newInd.RaceType).ToString( );
								valueStr += "-" + ((int)newInd.RegistProvin).ToString( );
								valueStr += "-" + ((int)newInd.RegistType).ToString( );
								valueStr += "-" + ((int)newInd.EducateLevel).ToString( );
								valueStr += "-" + ((int)newInd.Provin).ToString( );
								valueStr += "-" + ((int)newInd.ResidenceType).ToString( );
								populationDB.WriteAsyn( agentIDStr, valueStr );
								agentID++;
							}
							populationDB.DBDispose( );
						}
						range = worksheet.Cells[ i, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						if ( femaleNum != 0 )
						{
							uint targetPopNum = (uint)Math.Round( femaleNum * InputPara.popSizeRatio );
							populationDB.DBOpen( );
							for ( int k = 0; k < targetPopNum; k++ )
							{
								Individual newInd = new Individual( agentID, EGender.Female, 0, 0, 0,
									race, EProvince.Other, ERegistType.other, EEducateLevel.infant, resideProv, EResidenceType.city );
								//write db:
								string agentIDStr = agentID.ToString( );
								string valueStr = ((int)newInd.Gender).ToString( );
								valueStr += "-" + newInd.BirthYear.ToString( );
								valueStr += "-" + newInd.BirthMonth.ToString( );
								valueStr += "-" + newInd.Age.ToString( );
								valueStr += "-" + ((int)newInd.RaceType).ToString( );
								valueStr += "-" + ((int)newInd.RegistProvin).ToString( );
								valueStr += "-" + ((int)newInd.RegistType).ToString( );
								valueStr += "-" + ((int)newInd.EducateLevel).ToString( );
								valueStr += "-" + ((int)newInd.Provin).ToString( );
								valueStr += "-" + ((int)newInd.ResidenceType).ToString( );
								populationDB.WriteAsyn( agentIDStr, valueStr );
								agentID++;
							}
							populationDB.DBDispose( );
						}
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				Console.WriteLine( "InitPop City complete ..." );
				//town
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0106b.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					ERaceType race = (ERaceType)(j - 1);
					for ( int i = 3; i <= iRowCount; i++ )
					{
						range = worksheet.Cells[ i, 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "Other";
						EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
						range = worksheet.Cells[ i, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						if ( maleNum != 0 )
						{
							uint targetPopNum = (uint)Math.Round( maleNum * InputPara.popSizeRatio );
							populationDB.DBOpen( );
							for ( int k = 0; k < targetPopNum; k++ )
							{
								Individual newInd = new Individual( agentID, EGender.Male, 0, 0, 0,
									race, EProvince.Other, ERegistType.other, EEducateLevel.infant, resideProv, EResidenceType.town );
								//write db:
								string agentIDStr = agentID.ToString( );
								string valueStr = ((int)newInd.Gender).ToString( );
								valueStr += "-" + newInd.BirthYear.ToString( );
								valueStr += "-" + newInd.BirthMonth.ToString( );
								valueStr += "-" + newInd.Age.ToString( );
								valueStr += "-" + ((int)newInd.RaceType).ToString( );
								valueStr += "-" + ((int)newInd.RegistProvin).ToString( );
								valueStr += "-" + ((int)newInd.RegistType).ToString( );
								valueStr += "-" + ((int)newInd.EducateLevel).ToString( );
								valueStr += "-" + ((int)newInd.Provin).ToString( );
								valueStr += "-" + ((int)newInd.ResidenceType).ToString( );
								populationDB.WriteAsyn( agentIDStr, valueStr );
								agentID++;
							}
							populationDB.DBDispose( );
						}
						range = worksheet.Cells[ i, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						if ( femaleNum != 0 )
						{
							uint targetPopNum = (uint)Math.Round( femaleNum * InputPara.popSizeRatio );
							populationDB.DBOpen( );
							for ( int k = 0; k < targetPopNum; k++ )
							{
								Individual newInd = new Individual( agentID, EGender.Female, 0, 0, 0,
									race, EProvince.Other, ERegistType.other, EEducateLevel.infant, resideProv, EResidenceType.town );
								//write db:
								string agentIDStr = agentID.ToString( );
								string valueStr = ((int)newInd.Gender).ToString( );
								valueStr += "-" + newInd.BirthYear.ToString( );
								valueStr += "-" + newInd.BirthMonth.ToString( );
								valueStr += "-" + newInd.Age.ToString( );
								valueStr += "-" + ((int)newInd.RaceType).ToString( );
								valueStr += "-" + ((int)newInd.RegistProvin).ToString( );
								valueStr += "-" + ((int)newInd.RegistType).ToString( );
								valueStr += "-" + ((int)newInd.EducateLevel).ToString( );
								valueStr += "-" + ((int)newInd.Provin).ToString( );
								valueStr += "-" + ((int)newInd.ResidenceType).ToString( );
								populationDB.WriteAsyn( agentIDStr, valueStr );
								agentID++;
							}
							populationDB.DBDispose( );
						}
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				Console.WriteLine( "InitPop Town complete ..." );
				//rural
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0106c.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					ERaceType race = (ERaceType)(j - 1);
					for ( int i = 3; i <= iRowCount; i++ )
					{
						range = worksheet.Cells[ i, 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "Other";
						EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
						range = worksheet.Cells[ i, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						if ( maleNum != 0 )
						{
							uint targetPopNum = (uint)Math.Round( maleNum * InputPara.popSizeRatio );
							populationDB.DBOpen( );
							for ( int k = 0; k < targetPopNum; k++ )
							{
								Individual newInd = new Individual( agentID, EGender.Male, 0, 0, 0,
									race, EProvince.Other, ERegistType.other, EEducateLevel.infant, resideProv, EResidenceType.rural );
								//write db:
								string agentIDStr = agentID.ToString( );
								string valueStr = ((int)newInd.Gender).ToString( );
								valueStr += "-" + newInd.BirthYear.ToString( );
								valueStr += "-" + newInd.BirthMonth.ToString( );
								valueStr += "-" + newInd.Age.ToString( );
								valueStr += "-" + ((int)newInd.RaceType).ToString( );
								valueStr += "-" + ((int)newInd.RegistProvin).ToString( );
								valueStr += "-" + ((int)newInd.RegistType).ToString( );
								valueStr += "-" + ((int)newInd.EducateLevel).ToString( );
								valueStr += "-" + ((int)newInd.Provin).ToString( );
								valueStr += "-" + ((int)newInd.ResidenceType).ToString( );
								populationDB.WriteAsyn( agentIDStr, valueStr );
								agentID++;
							}
							populationDB.DBDispose( );
						}
						range = worksheet.Cells[ i, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						if ( femaleNum != 0 )
						{
							uint targetPopNum = (uint)Math.Round( femaleNum * InputPara.popSizeRatio );
							populationDB.DBOpen( );
							for ( int k = 0; k < targetPopNum; k++ )
							{
								Individual newInd = new Individual( agentID, EGender.Female, 0, 0, 0,
									race, EProvince.Other, ERegistType.other, EEducateLevel.infant, resideProv, EResidenceType.rural );
								//write db:
								string agentIDStr = agentID.ToString( );
								string valueStr = ((int)newInd.Gender).ToString( );
								valueStr += "-" + newInd.BirthYear.ToString( );
								valueStr += "-" + newInd.BirthMonth.ToString( );
								valueStr += "-" + newInd.Age.ToString( );
								valueStr += "-" + ((int)newInd.RaceType).ToString( );
								valueStr += "-" + ((int)newInd.RegistProvin).ToString( );
								valueStr += "-" + ((int)newInd.RegistType).ToString( );
								valueStr += "-" + ((int)newInd.EducateLevel).ToString( );
								valueStr += "-" + ((int)newInd.Provin).ToString( );
								valueStr += "-" + ((int)newInd.ResidenceType).ToString( );
								populationDB.WriteAsyn( agentIDStr, valueStr );
								agentID++;
							}
							populationDB.DBDispose( );
						}
					}
				}
				Console.WriteLine( "InitPop Rural complete ..." );
			} catch ( Exception e )
			{
				throw new ApplicationException( e.Message );
			} finally
			{
				if ( workBook != null )
				{
					workBook.Close( false, objOpt, objOpt );
					System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
					workBook = null;
				}
				excelApp.Workbooks.Close( );
				excelApp.Quit( );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( excelApp );
				excelApp = null;
				GC.Collect( );
				GC.WaitForPendingFinalizers( );
			}
		}

		/// <summary>
		/// update age
		/// </summary>
		private void UpdateAgeInterval( )
		{
			Dictionary<IndJointDis, double> ageDistribution = new Dictionary<IndJointDis, double>( );
			Excel.Application excelApp = new Excel.Application( );
			object objOpt = System.Reflection.Missing.Value;
			Excel.Workbook workBook = null;
			Excel.Sheets sheets;
			Excel.Worksheet worksheet;
			Excel.Range range;
			try
			{
				int iRowCount = 0;
				int iColCount = 0;
				string cellContent = null;
				#region city
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0107a.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					Dictionary<EAgeInterval, uint> maleAgeDis = new Dictionary<EAgeInterval, uint>( );
					Dictionary<EAgeInterval, uint> femaleAgeDis = new Dictionary<EAgeInterval, uint>( );
					for ( int j = 3; j <= iColCount; j++ )
					{
						range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EAgeInterval ageInter = (EAgeInterval)(j - 3);
						range = worksheet.Cells[ i, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						maleAgeDis.Add( ageInter, maleNum );
						range = worksheet.Cells[ i, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						femaleAgeDis.Add( ageInter, femaleNum );
					}
					range = worksheet.Cells[ i, 3 * 2 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint zeroMaleNum = uint.Parse( cellContent );
					maleAgeDis[ EAgeInterval.ZeroToFour ] += zeroMaleNum;
					range = worksheet.Cells[ i, 3 * 2 + 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint zeroFemaleNum = uint.Parse( cellContent );
					femaleAgeDis[ EAgeInterval.ZeroToFour ] += zeroFemaleNum;
					uint maleSum = 0;
					uint femaleSum = 0;
					foreach ( uint maleNum in maleAgeDis.Values )
						maleSum += maleNum;
					foreach ( uint femaleNum in femaleAgeDis.Values )
						femaleSum += femaleNum;
					foreach ( EAgeInterval ageInter in maleAgeDis.Keys )
					{
						IndJointDis newJointDis = new IndJointDis( EGender.Male, ageInter, resideProv,
									ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.city, ERegistType.other );
						ageDistribution.Add( newJointDis, (double)maleAgeDis[ ageInter ] / maleSum );
					}
					foreach ( EAgeInterval ageInter in femaleAgeDis.Keys )
					{
						IndJointDis newJointDis = new IndJointDis( EGender.Female, ageInter, resideProv,
									ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.city, ERegistType.other );
						ageDistribution.Add( newJointDis, (double)femaleAgeDis[ ageInter ] / femaleSum );
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region town
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0107b.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					Dictionary<EAgeInterval, uint> maleAgeDis = new Dictionary<EAgeInterval, uint>( );
					Dictionary<EAgeInterval, uint> femaleAgeDis = new Dictionary<EAgeInterval, uint>( );
					for ( int j = 3; j <= iColCount; j++ )
					{
						range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EAgeInterval ageInter = (EAgeInterval)(j - 3);
						range = worksheet.Cells[ i, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						maleAgeDis.Add( ageInter, maleNum );
						range = worksheet.Cells[ i, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						femaleAgeDis.Add( ageInter, femaleNum );
					}
					range = worksheet.Cells[ i, 3 * 2 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint zeroMaleNum = uint.Parse( cellContent );
					maleAgeDis[ EAgeInterval.ZeroToFour ] += zeroMaleNum;
					range = worksheet.Cells[ i, 3 * 2 + 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint zeroFemaleNum = uint.Parse( cellContent );
					femaleAgeDis[ EAgeInterval.ZeroToFour ] += zeroFemaleNum;
					uint maleSum = 0;
					uint femaleSum = 0;
					foreach ( uint maleNum in maleAgeDis.Values )
						maleSum += maleNum;
					foreach ( uint femaleNum in femaleAgeDis.Values )
						femaleSum += femaleNum;
					foreach ( EAgeInterval ageInter in maleAgeDis.Keys )
					{
						IndJointDis newJointDis = new IndJointDis( EGender.Male, ageInter, resideProv,
									ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.town, ERegistType.other );
						ageDistribution.Add( newJointDis, (double)maleAgeDis[ ageInter ] / maleSum );
					}
					foreach ( EAgeInterval ageInter in femaleAgeDis.Keys )
					{
						IndJointDis newJointDis = new IndJointDis( EGender.Female, ageInter, resideProv,
									ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.town, ERegistType.other );
						ageDistribution.Add( newJointDis, (double)femaleAgeDis[ ageInter ] / femaleSum );
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region rural
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0107c.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					Dictionary<EAgeInterval, uint> maleAgeDis = new Dictionary<EAgeInterval, uint>( );
					Dictionary<EAgeInterval, uint> femaleAgeDis = new Dictionary<EAgeInterval, uint>( );
					for ( int j = 3; j <= iColCount; j++ )
					{
						range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EAgeInterval ageInter = (EAgeInterval)(j - 3);
						range = worksheet.Cells[ i, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						maleAgeDis.Add( ageInter, maleNum );
						range = worksheet.Cells[ i, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						femaleAgeDis.Add( ageInter, femaleNum );
					}
					range = worksheet.Cells[ i, 3 * 2 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint zeroMaleNum = uint.Parse( cellContent );
					maleAgeDis[ EAgeInterval.ZeroToFour ] += zeroMaleNum;
					range = worksheet.Cells[ i, 3 * 2 + 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint zeroFemaleNum = uint.Parse( cellContent );
					femaleAgeDis[ EAgeInterval.ZeroToFour ] += zeroFemaleNum;
					uint maleSum = 0;
					uint femaleSum = 0;
					foreach ( uint maleNum in maleAgeDis.Values )
						maleSum += maleNum;
					foreach ( uint femaleNum in femaleAgeDis.Values )
						femaleSum += femaleNum;
					foreach ( EAgeInterval ageInter in maleAgeDis.Keys )
					{
						IndJointDis newJointDis = new IndJointDis( EGender.Male, ageInter, resideProv,
									ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.other );
						ageDistribution.Add( newJointDis, (double)maleAgeDis[ ageInter ] / maleSum );
					}
					foreach ( EAgeInterval ageInter in femaleAgeDis.Keys )
					{
						IndJointDis newJointDis = new IndJointDis( EGender.Female, ageInter, resideProv,
									ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.other );
						ageDistribution.Add( newJointDis, (double)femaleAgeDis[ ageInter ] / femaleSum );
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
			} catch ( Exception e )
			{
				throw new ApplicationException( e.Message );
			} finally
			{
				if ( workBook != null )
				{
					workBook.Close( false, objOpt, objOpt );
					System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
					workBook = null;
				}
				excelApp.Workbooks.Close( );
				excelApp.Quit( );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( excelApp );
				excelApp = null;
				GC.Collect( );
				GC.WaitForPendingFinalizers( );
			}
			string populationDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, InputPara.popDBName );
			MyDatabase populationDB = new MyDatabase( populationDBName );
			if ( !Directory.Exists( populationDBName ) )
			{
				throw new ApplicationException( InputPara.popDBName + " does not exist!!" );
			}
			populationDB.DBOpen( );
			DBIterator dbIter = populationDB.GetIterator( );
			uint lineNum = 0;
			Random rand = new Random( );
			for ( dbIter.SeekToFirst( ); dbIter.Valid( ); dbIter.Next( ) )
			{
				string keyStr = dbIter.Key( ).ToString( );
				string valueStr = dbIter.Value( ).ToString( );
				string[ ] attributes = valueStr.Split( '-' );
				EGender gender = (EGender)(int.Parse( attributes[ 0 ] ));
				ushort birthYear = ushort.Parse( attributes[ 1 ] );
				ushort birthMonth = ushort.Parse( attributes[ 2 ] );
				ushort age = ushort.Parse( attributes[ 3 ] );
				ERaceType race = (ERaceType)(int.Parse( attributes[ 4 ] ));
				EProvince registProvin = (EProvince)(int.Parse( attributes[ 5 ] ));
				ERegistType registType = (ERegistType)(int.Parse( attributes[ 6 ] ));
				EEducateLevel eduLv = (EEducateLevel)(int.Parse( attributes[ 7 ] ));
				EProvince resideProvin = (EProvince)(int.Parse( attributes[ 8 ] ));
				EResidenceType resideType = (EResidenceType)(int.Parse( attributes[ 9 ] ));
				EAgeInterval allocatedAgeInter = EAgeInterval.HundredAndAbove;
				Dictionary<EAgeInterval, double> ageAjustProb = new Dictionary<EAgeInterval, double>( );
				foreach ( IndJointDis parDis in ageDistribution.Keys )
				{
					if ( parDis.Gender == gender && parDis.ResideProvin == resideProvin && parDis.ResidenceType == resideType )
					{
						if ( ageAjustProb.ContainsKey( parDis.Age ) )
							throw new ApplicationException( "Already contains the Age Inter!!" );
						else
							ageAjustProb.Add( parDis.Age, ageDistribution[ parDis ] );
					}
				}
				EAgeInterval[ ] ageKeys = new EAgeInterval[ ageAjustProb.Count ];
				double[ ] ageProb = new double[ ageAjustProb.Count ];
				double sumRatio = 0;
				int index = 0;
				foreach ( EAgeInterval ageInter in ageAjustProb.Keys )
				{
					ageKeys[ index ] = ageInter;
					ageProb[ index ] = ageAjustProb[ ageInter ];
					index++;
					sumRatio += ageAjustProb[ ageInter ];
				}
				double alloSeed = rand.NextDouble( );
				sumRatio = 0;
				for ( int i = 0; i < ageProb.Length; i++ )
				{
					sumRatio += ageProb[ i ];
					if ( alloSeed <= sumRatio )
					{
						allocatedAgeInter = ageKeys[ i ];
						break;
					}
				}
				age = GenRandomAge( allocatedAgeInter );
				birthYear = (ushort)(2000 - age);
				string newValueStr = ((int)gender).ToString( );
				newValueStr += "-" + birthYear.ToString( );
				newValueStr += "-" + birthMonth.ToString( );
				newValueStr += "-" + age.ToString( );
				newValueStr += "-" + ((int)race).ToString( );
				newValueStr += "-" + ((int)registProvin).ToString( );
				newValueStr += "-" + ((int)registType).ToString( );
				newValueStr += "-" + ((int)eduLv).ToString( );
				newValueStr += "-" + ((int)resideProvin).ToString( );
				newValueStr += "-" + ((int)resideType).ToString( );
				populationDB.Update( keyStr, newValueStr );
				lineNum++;
				if ( lineNum % 10000000 == 0 )
					Console.WriteLine( "Age: " + string.Format( "{0:0,0}", lineNum ) + " ..." );
			}
			dbIter.Dispose( );
			populationDB.DBDispose( );
		}

		/// <summary>
		/// update eduLv
		/// </summary>
		private void UpdateEduLevel( )
		{
			Dictionary<IndJointDis, double> eduLvDistribution = new Dictionary<IndJointDis, double>( );
			Excel.Application excelApp = new Excel.Application( );
			object objOpt = System.Reflection.Missing.Value;
			Excel.Workbook workBook = null;
			Excel.Sheets sheets;
			Excel.Worksheet worksheet;
			Excel.Range range;
			try
			{
				int iRowCount = 0;
				int iColCount = 0;
				string cellContent = null;
				#region city
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0401a.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 2; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ 6 * i - 4, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EAgeInterval ageInter = (EAgeInterval)i;
					Dictionary<EEducateLevel, uint> maleEduLvDis = new Dictionary<EEducateLevel, uint>( );
					Dictionary<EEducateLevel, uint> femaleEduLvDis = new Dictionary<EEducateLevel, uint>( );
					for ( int j = 2; j <= iColCount; j++ )
					{
						range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EEducateLevel eduLevel = (EEducateLevel)(j - 1);
						range = worksheet.Cells[ 6 * i - 4, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						maleEduLvDis.Add( eduLevel, maleNum );
						range = worksheet.Cells[ 6 * i - 4, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						femaleEduLvDis.Add( eduLevel, femaleNum );
					}
					uint maleSum = 0;
					uint femaleSum = 0;
					foreach ( uint maleNum in maleEduLvDis.Values )
						maleSum += maleNum;
					foreach ( uint femaleNum in femaleEduLvDis.Values )
						femaleSum += femaleNum;
					foreach ( EEducateLevel eduLv in maleEduLvDis.Keys )
					{
						IndJointDis newJointDis = new IndJointDis( EGender.Male, ageInter, EProvince.Other,
									ERaceType.Other, EProvince.Other, eduLv, EResidenceType.city, ERegistType.other );
						eduLvDistribution.Add( newJointDis, (double)maleEduLvDis[ eduLv ] / maleSum );
					}
					foreach ( EEducateLevel eduLv in femaleEduLvDis.Keys )
					{
						IndJointDis newJointDis = new IndJointDis( EGender.Female, ageInter, EProvince.Other,
									ERaceType.Other, EProvince.Other, eduLv, EResidenceType.city, ERegistType.other );
						eduLvDistribution.Add( newJointDis, (double)femaleEduLvDis[ eduLv ] / femaleSum );
					}
				}
				//6-9 year old people:
				Dictionary<EEducateLevel, uint> maleEduLvDis5_9city = new Dictionary<EEducateLevel, uint>( );
				Dictionary<EEducateLevel, uint> femaleEduLvDis5_9city = new Dictionary<EEducateLevel, uint>( );
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EEducateLevel eduLevel = (EEducateLevel)(j - 1);
					range = worksheet.Cells[ 3, 3 * j ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint maleNum = uint.Parse( cellContent );
					maleEduLvDis5_9city.Add( eduLevel, maleNum );
					range = worksheet.Cells[ 3, 3 * j + 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint femaleNum = uint.Parse( cellContent );
					femaleEduLvDis5_9city.Add( eduLevel, femaleNum );
				}
				uint maleSum5_9 = 0;
				uint femaleSum5_9 = 0;
				foreach ( uint maleNum in maleEduLvDis5_9city.Values )
					maleSum5_9 += maleNum;
				foreach ( uint femaleNum in femaleEduLvDis5_9city.Values )
					femaleSum5_9 += femaleNum;
				foreach ( EEducateLevel eduLv in maleEduLvDis5_9city.Keys )
				{
					IndJointDis newJointDis = new IndJointDis( EGender.Male, EAgeInterval.FiveToNine, EProvince.Other,
									ERaceType.Other, EProvince.Other, eduLv, EResidenceType.city, ERegistType.other );
					eduLvDistribution.Add( newJointDis, (double)maleEduLvDis5_9city[ eduLv ] / maleSum5_9 );
				}
				foreach ( EEducateLevel eduLv in femaleEduLvDis5_9city.Keys )
				{
					IndJointDis newJointDis = new IndJointDis( EGender.Female, EAgeInterval.FiveToNine, EProvince.Other,
									ERaceType.Other, EProvince.Other, eduLv, EResidenceType.city, ERegistType.other );
					eduLvDistribution.Add( newJointDis, (double)femaleEduLvDis5_9city[ eduLv ] / femaleSum5_9 );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region town
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0401b.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 2; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ 6 * i - 4, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EAgeInterval ageInter = (EAgeInterval)i;
					Dictionary<EEducateLevel, uint> maleEduLvDis = new Dictionary<EEducateLevel, uint>( );
					Dictionary<EEducateLevel, uint> femaleEduLvDis = new Dictionary<EEducateLevel, uint>( );
					for ( int j = 2; j <= iColCount; j++ )
					{
						range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EEducateLevel eduLevel = (EEducateLevel)(j - 1);
						range = worksheet.Cells[ 6 * i - 4, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						maleEduLvDis.Add( eduLevel, maleNum );
						range = worksheet.Cells[ 6 * i - 4, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						femaleEduLvDis.Add( eduLevel, femaleNum );
					}
					uint maleSum = 0;
					uint femaleSum = 0;
					foreach ( uint maleNum in maleEduLvDis.Values )
						maleSum += maleNum;
					foreach ( uint femaleNum in femaleEduLvDis.Values )
						femaleSum += femaleNum;
					foreach ( EEducateLevel eduLv in maleEduLvDis.Keys )
					{
						IndJointDis newJointDis = new IndJointDis( EGender.Male, ageInter, EProvince.Other,
									ERaceType.Other, EProvince.Other, eduLv, EResidenceType.town, ERegistType.other );
						eduLvDistribution.Add( newJointDis, (double)maleEduLvDis[ eduLv ] / maleSum );
					}
					foreach ( EEducateLevel eduLv in femaleEduLvDis.Keys )
					{
						IndJointDis newJointDis = new IndJointDis( EGender.Female, ageInter, EProvince.Other,
									ERaceType.Other, EProvince.Other, eduLv, EResidenceType.town, ERegistType.other );
						eduLvDistribution.Add( newJointDis, (double)femaleEduLvDis[ eduLv ] / femaleSum );
					}
				}
				//6-9 year old people:
				Dictionary<EEducateLevel, uint> maleEduLvDis5_9town = new Dictionary<EEducateLevel, uint>( );
				Dictionary<EEducateLevel, uint> femaleEduLvDis5_9town = new Dictionary<EEducateLevel, uint>( );
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EEducateLevel eduLevel = (EEducateLevel)(j - 1);
					range = worksheet.Cells[ 3, 3 * j ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint maleNum = uint.Parse( cellContent );
					maleEduLvDis5_9town.Add( eduLevel, maleNum );
					range = worksheet.Cells[ 3, 3 * j + 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint femaleNum = uint.Parse( cellContent );
					femaleEduLvDis5_9town.Add( eduLevel, femaleNum );
				}
				maleSum5_9 = 0;
				femaleSum5_9 = 0;
				foreach ( uint maleNum in maleEduLvDis5_9town.Values )
					maleSum5_9 += maleNum;
				foreach ( uint femaleNum in femaleEduLvDis5_9town.Values )
					femaleSum5_9 += femaleNum;
				foreach ( EEducateLevel eduLv in maleEduLvDis5_9town.Keys )
				{
					IndJointDis newJointDis = new IndJointDis( EGender.Male, EAgeInterval.FiveToNine, EProvince.Other,
									ERaceType.Other, EProvince.Other, eduLv, EResidenceType.town, ERegistType.other );
					eduLvDistribution.Add( newJointDis, (double)maleEduLvDis5_9town[ eduLv ] / maleSum5_9 );
				}
				foreach ( EEducateLevel eduLv in femaleEduLvDis5_9town.Keys )
				{
					IndJointDis newJointDis = new IndJointDis( EGender.Female, EAgeInterval.FiveToNine, EProvince.Other,
									ERaceType.Other, EProvince.Other, eduLv, EResidenceType.town, ERegistType.other );
					eduLvDistribution.Add( newJointDis, (double)femaleEduLvDis5_9town[ eduLv ] / femaleSum5_9 );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region rural
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0401c.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 2; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ 6 * i - 4, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EAgeInterval ageInter = (EAgeInterval)i;
					Dictionary<EEducateLevel, uint> maleEduLvDis = new Dictionary<EEducateLevel, uint>( );
					Dictionary<EEducateLevel, uint> femaleEduLvDis = new Dictionary<EEducateLevel, uint>( );
					for ( int j = 2; j <= iColCount; j++ )
					{
						range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EEducateLevel eduLevel = (EEducateLevel)(j - 1);
						range = worksheet.Cells[ 6 * i - 4, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						maleEduLvDis.Add( eduLevel, maleNum );
						range = worksheet.Cells[ 6 * i - 4, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						femaleEduLvDis.Add( eduLevel, femaleNum );
					}
					uint maleSum = 0;
					uint femaleSum = 0;
					foreach ( uint maleNum in maleEduLvDis.Values )
						maleSum += maleNum;
					foreach ( uint femaleNum in femaleEduLvDis.Values )
						femaleSum += femaleNum;
					foreach ( EEducateLevel eduLv in maleEduLvDis.Keys )
					{
						IndJointDis newJointDis = new IndJointDis( EGender.Male, ageInter, EProvince.Other,
									ERaceType.Other, EProvince.Other, eduLv, EResidenceType.rural, ERegistType.other );
						eduLvDistribution.Add( newJointDis, (double)maleEduLvDis[ eduLv ] / maleSum );
					}
					foreach ( EEducateLevel eduLv in femaleEduLvDis.Keys )
					{
						IndJointDis newJointDis = new IndJointDis( EGender.Female, ageInter, EProvince.Other,
									ERaceType.Other, EProvince.Other, eduLv, EResidenceType.rural, ERegistType.other );
						eduLvDistribution.Add( newJointDis, (double)femaleEduLvDis[ eduLv ] / femaleSum );
					}
				}
				//6-9 year old people:
				Dictionary<EEducateLevel, uint> maleEduLvDis5_9rural = new Dictionary<EEducateLevel, uint>( );
				Dictionary<EEducateLevel, uint> femaleEduLvDis5_9rural = new Dictionary<EEducateLevel, uint>( );
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EEducateLevel eduLevel = (EEducateLevel)(j - 1);
					range = worksheet.Cells[ 3, 3 * j ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint maleNum = uint.Parse( cellContent );
					maleEduLvDis5_9rural.Add( eduLevel, maleNum );
					range = worksheet.Cells[ 3, 3 * j + 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint femaleNum = uint.Parse( cellContent );
					femaleEduLvDis5_9rural.Add( eduLevel, femaleNum );
				}
				maleSum5_9 = 0;
				femaleSum5_9 = 0;
				foreach ( uint maleNum in maleEduLvDis5_9rural.Values )
					maleSum5_9 += maleNum;
				foreach ( uint femaleNum in femaleEduLvDis5_9rural.Values )
					femaleSum5_9 += femaleNum;
				foreach ( EEducateLevel eduLv in maleEduLvDis5_9rural.Keys )
				{
					IndJointDis newJointDis = new IndJointDis( EGender.Male, EAgeInterval.FiveToNine, EProvince.Other,
									ERaceType.Other, EProvince.Other, eduLv, EResidenceType.rural, ERegistType.other );
					eduLvDistribution.Add( newJointDis, (double)maleEduLvDis5_9rural[ eduLv ] / maleSum5_9 );
				}
				foreach ( EEducateLevel eduLv in femaleEduLvDis5_9rural.Keys )
				{
					IndJointDis newJointDis = new IndJointDis( EGender.Female, EAgeInterval.FiveToNine, EProvince.Other,
									ERaceType.Other, EProvince.Other, eduLv, EResidenceType.rural, ERegistType.other );
					eduLvDistribution.Add( newJointDis, (double)femaleEduLvDis5_9rural[ eduLv ] / femaleSum5_9 );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
			} catch ( Exception e )
			{
				throw new ApplicationException( e.Message );
			} finally
			{
				if ( workBook != null )
				{
					workBook.Close( false, objOpt, objOpt );
					System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
					workBook = null;
				}
				excelApp.Workbooks.Close( );
				excelApp.Quit( );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( excelApp );
				excelApp = null;
				GC.Collect( );
				GC.WaitForPendingFinalizers( );
			}
			string populationDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, InputPara.popDBName );
			MyDatabase populationDB = new MyDatabase( populationDBName );
			if ( !Directory.Exists( populationDBName ) )
			{
				throw new ApplicationException( InputPara.popDBName + " does not exist!!" );
			}
			populationDB.DBOpen( );
			DBIterator dbIter = populationDB.GetIterator( );
			uint lineNum = 0;
			Random rand = new Random( );
			for ( dbIter.SeekToFirst( ); dbIter.Valid( ); dbIter.Next( ) )
			{
				string keyStr = dbIter.Key( ).ToString( );
				string valueStr = dbIter.Value( ).ToString( );
				string[ ] attributes = valueStr.Split( '-' );
				EGender gender = (EGender)(int.Parse( attributes[ 0 ] ));
				ushort birthYear = ushort.Parse( attributes[ 1 ] );
				ushort birthMonth = ushort.Parse( attributes[ 2 ] );
				ushort age = ushort.Parse( attributes[ 3 ] );
				ERaceType race = (ERaceType)(int.Parse( attributes[ 4 ] ));
				EProvince registProvin = (EProvince)(int.Parse( attributes[ 5 ] ));
				ERegistType registType = (ERegistType)(int.Parse( attributes[ 6 ] ));
				EEducateLevel eduLv = (EEducateLevel)(int.Parse( attributes[ 7 ] ));
				EProvince resideProvin = (EProvince)(int.Parse( attributes[ 8 ] ));
				EResidenceType resideType = (EResidenceType)(int.Parse( attributes[ 9 ] ));

				EAgeInterval ageInter = AttributeCheck.CheckAgeInterval( age );
				if ( ageInter == EAgeInterval.ZeroToFour )
					eduLv = EEducateLevel.infant;
				else
				{
					if ( ageInter > EAgeInterval.SixtyFiveToSixtyNine )
						ageInter = EAgeInterval.SixtyFiveToSixtyNine;
					Dictionary<EEducateLevel, double> eduLvAjustProb = new Dictionary<EEducateLevel, double>( );
					foreach ( IndJointDis parDis in eduLvDistribution.Keys )
					{
						if ( parDis.Gender == gender && parDis.ResidenceType == resideType && parDis.Age == ageInter )
						{
							if ( eduLvAjustProb.ContainsKey( parDis.EduLevel ) )
								throw new ApplicationException( "Already contains the EduLv!!" );
							else
								eduLvAjustProb.Add( parDis.EduLevel, eduLvDistribution[ parDis ] );
						}
					}
					EEducateLevel[ ] eduLvKeys = new EEducateLevel[ eduLvAjustProb.Count ];
					double[ ] eduLvProb = new double[ eduLvAjustProb.Count ];
					double sumRatio = 0;
					int index = 0;
					foreach ( EEducateLevel parEduLv in eduLvAjustProb.Keys )
					{
						eduLvKeys[ index ] = parEduLv;
						eduLvProb[ index ] = eduLvAjustProb[ parEduLv ];
						index++;
						sumRatio += eduLvAjustProb[ parEduLv ];
					}
					double alloSeed = rand.NextDouble( );
					sumRatio = 0;
					for ( int i = 0; i < eduLvProb.Length; i++ )
					{
						sumRatio += eduLvProb[ i ];
						if ( alloSeed <= sumRatio )
						{
							eduLv = eduLvKeys[ i ];
							break;
						}
					}
				}
				string newValueStr = ((int)gender).ToString( );
				newValueStr += "-" + birthYear.ToString( );
				newValueStr += "-" + birthMonth.ToString( );
				newValueStr += "-" + age.ToString( );
				newValueStr += "-" + ((int)race).ToString( );
				newValueStr += "-" + ((int)registProvin).ToString( );
				newValueStr += "-" + ((int)registType).ToString( );
				newValueStr += "-" + ((int)eduLv).ToString( );
				newValueStr += "-" + ((int)resideProvin).ToString( );
				newValueStr += "-" + ((int)resideType).ToString( );
				populationDB.Update( keyStr, newValueStr );
				lineNum++;
				if ( lineNum % 10000000 == 0 )
					Console.WriteLine( "Edu Lv: " + string.Format( "{0:0,0}", lineNum ) + " ..." );
			}
			dbIter.Dispose( );
			populationDB.DBDispose( );
		}

		/// <summary>
		/// update Registration Type
		/// </summary>
		private void UpdateRegistType( )
		{
			Dictionary<EProvince, uint> ruralMale = new Dictionary<EProvince, uint>( );
			Dictionary<EProvince, uint> ruralFemale = new Dictionary<EProvince, uint>( );
			Dictionary<EProvince, uint> urbanMale = new Dictionary<EProvince, uint>( );
			Dictionary<EProvince, uint> urbanFemale = new Dictionary<EProvince, uint>( );
			Dictionary<EProvince, uint> noRegMale = new Dictionary<EProvince, uint>( );
			Dictionary<EProvince, uint> noRegFemale = new Dictionary<EProvince, uint>( );
			Excel.Application excelApp = new Excel.Application( );
			object objOpt = System.Reflection.Missing.Value;
			Excel.Workbook workBook = null;
			Excel.Sheets sheets;
			Excel.Worksheet worksheet;
			Excel.Range range;
			try
			{
				int iRowCount = 0;
				int iColCount = 0;
				string cellContent = null;
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0105.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					range = worksheet.Cells[ i, 6 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint ruralMaleNum = uint.Parse( cellContent );
					ruralMale.Add( resideProv, ruralMaleNum );
					range = worksheet.Cells[ i, 7 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint ruralFemaleNum = uint.Parse( cellContent );
					ruralFemale.Add( resideProv, ruralFemaleNum );
					range = worksheet.Cells[ i, 9 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint urbanMaleNum = uint.Parse( cellContent );
					urbanMale.Add( resideProv, urbanMaleNum );
					range = worksheet.Cells[ i, 10 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint urbanFemaleNum = uint.Parse( cellContent );
					urbanFemale.Add( resideProv, urbanFemaleNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0102.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					range = worksheet.Cells[ i, 3 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint cenRegMale = uint.Parse( cellContent );
					range = worksheet.Cells[ i, 4 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint cenRegFemale = uint.Parse( cellContent );
					if ( cenRegMale >= ruralMale[ resideProv ] + urbanMale[ resideProv ] )
						noRegMale.Add( resideProv, cenRegMale - ruralMale[ resideProv ] - urbanMale[ resideProv ] );
					else
						throw new ApplicationException( "cenRegMale - abroadMale < ruralMale[ resideProv ] + ruralFemale[ resideProv ]" );
					if ( cenRegFemale >= ruralFemale[ resideProv ] + urbanFemale[ resideProv ] )
						noRegFemale.Add( resideProv, cenRegFemale - ruralFemale[ resideProv ] - urbanFemale[ resideProv ] );
					else
						throw new ApplicationException( "cenRegFemale - abroadFemale < ruralFemale[ resideProv ] + urbanFemale[ resideProv ]" );
				}
			} catch ( Exception e )
			{
				throw new ApplicationException( e.Message );
			} finally
			{
				if ( workBook != null )
				{
					workBook.Close( false, objOpt, objOpt );
					System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
					workBook = null;
				}
				excelApp.Workbooks.Close( );
				excelApp.Quit( );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( excelApp );
				excelApp = null;
				GC.Collect( );
				GC.WaitForPendingFinalizers( );
			}
			string populationDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, InputPara.popDBName );
			MyDatabase populationDB = new MyDatabase( populationDBName );
			if ( !Directory.Exists( populationDBName ) )
			{
				throw new ApplicationException( InputPara.popDBName + " does not exist!!" );
			}
			populationDB.DBOpen( );
			DBIterator dbIter = populationDB.GetIterator( );
			uint lineNum = 0;
			Random rand = new Random( );
			for ( dbIter.SeekToFirst( ); dbIter.Valid( ); dbIter.Next( ) )
			{
				string keyStr = dbIter.Key( ).ToString( );
				string valueStr = dbIter.Value( ).ToString( );
				string[ ] attributes = valueStr.Split( '-' );
				EGender gender = (EGender)(int.Parse( attributes[ 0 ] ));
				ushort birthYear = ushort.Parse( attributes[ 1 ] );
				ushort birthMonth = ushort.Parse( attributes[ 2 ] );
				ushort age = ushort.Parse( attributes[ 3 ] );
				ERaceType race = (ERaceType)(int.Parse( attributes[ 4 ] ));
				EProvince registProvin = (EProvince)(int.Parse( attributes[ 5 ] ));
				ERegistType registType = (ERegistType)(int.Parse( attributes[ 6 ] ));
				EEducateLevel eduLv = (EEducateLevel)(int.Parse( attributes[ 7 ] ));
				EProvince resideProvin = (EProvince)(int.Parse( attributes[ 8 ] ));
				EResidenceType resideType = (EResidenceType)(int.Parse( attributes[ 9 ] ));

				if ( gender == EGender.Male )
				{
					double urbanRatio = (double)urbanMale[ resideProvin ]
						/ (urbanMale[ resideProvin ] + ruralMale[ resideProvin ] + noRegMale[ resideProvin ]);
					double ruralRatio = (double)ruralMale[ resideProvin ]
						/ (urbanMale[ resideProvin ] + ruralMale[ resideProvin ] + noRegMale[ resideProvin ]);
					double noRegRatio = 1 - urbanRatio - ruralRatio;
					double alloSeed = rand.NextDouble( );
					if ( alloSeed < urbanRatio )
						registType = ERegistType.urban;
					else if ( alloSeed < urbanRatio + ruralRatio )
						registType = ERegistType.rural;
					else
						registType = ERegistType.other;
				} else
				{
					double urbanRatio = (double)urbanFemale[ resideProvin ]
						/ (urbanFemale[ resideProvin ] + ruralFemale[ resideProvin ] + noRegFemale[ resideProvin ]);
					double ruralRatio = (double)ruralFemale[ resideProvin ]
						/ (urbanFemale[ resideProvin ] + ruralFemale[ resideProvin ] + noRegFemale[ resideProvin ]);
					double noRegRatio = 1 - urbanRatio - ruralRatio;
					double alloSeed = rand.NextDouble( );
					if ( alloSeed < urbanRatio )
						registType = ERegistType.urban;
					else if ( alloSeed < urbanRatio + ruralRatio )
						registType = ERegistType.rural;
					else
						registType = ERegistType.other;
				}
				string newValueStr = ((int)gender).ToString( );
				newValueStr += "-" + birthYear.ToString( );
				newValueStr += "-" + birthMonth.ToString( );
				newValueStr += "-" + age.ToString( );
				newValueStr += "-" + ((int)race).ToString( );
				newValueStr += "-" + ((int)registProvin).ToString( );
				newValueStr += "-" + ((int)registType).ToString( );
				newValueStr += "-" + ((int)eduLv).ToString( );
				newValueStr += "-" + ((int)resideProvin).ToString( );
				newValueStr += "-" + ((int)resideType).ToString( );
				populationDB.Update( keyStr, newValueStr );
				lineNum++;
				if ( lineNum % 10000000 == 0 )
					Console.WriteLine( "Regist Type: " + string.Format( "{0:0,0}", lineNum ) + " ..." );
			}
			dbIter.Dispose( );
			populationDB.DBDispose( );
		}

		/// <summary>
		/// update Registration Province
		/// </summary>
		private void UpdateRegistProvince( )
		{
			//immigrant registered people
			Dictionary<IndJointDis, uint> resideTypeResideProvRegistProvPartial = new Dictionary<IndJointDis, uint>( );
			//total registered people
			Dictionary<EProvince, uint> regNum = new Dictionary<EProvince, uint>( );
			Excel.Application excelApp = new Excel.Application( );
			object objOpt = System.Reflection.Missing.Value;
			Excel.Workbook workBook = null;
			Excel.Sheets sheets;
			Excel.Worksheet worksheet;
			Excel.Range range;
			try
			{
				int iRowCount = 0;
				int iColCount = 0;
				string cellContent = null;
				#region local registered people
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0102.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					range = worksheet.Cells[ i, 2 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint totalNum = uint.Parse( cellContent );
					range = worksheet.Cells[ i, 14 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint undeterNum = uint.Parse( cellContent );
					range = worksheet.Cells[ i, 17 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint noRegNum = uint.Parse( cellContent );
					if ( totalNum <= undeterNum + noRegNum )
						throw new ApplicationException( "totalNum <= undeterNum + noRegNum" );
					regNum.Add( resideProv, totalNum - undeterNum - noRegNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region immigrant registered people
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0702a.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					Dictionary<EProvince, uint> otherRegistProvNum = new Dictionary<EProvince, uint>( );
					for ( int j = 3; j <= iColCount; j++ )
					{
						if ( i == j )
							continue;
						range = worksheet.Cells[ 1, j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EProvince registProv = AttributeCheck.CheckProvince( cellContent );
						range = worksheet.Cells[ i, j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint indNum = uint.Parse( cellContent );
						otherRegistProvNum.Add( registProv, indNum );
					}
					foreach ( EProvince parProv in otherRegistProvNum.Keys )
					{
						IndJointDis newRegistProvInd = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour, resideProv,
									ERaceType.Other, parProv, EEducateLevel.infant, EResidenceType.city, ERegistType.other );
						resideTypeResideProvRegistProvPartial.Add( newRegistProvInd, otherRegistProvNum[ parProv ] );
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0702b.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					Dictionary<EProvince, uint> otherRegistProvNum = new Dictionary<EProvince, uint>( );
					for ( int j = 3; j <= iColCount; j++ )
					{
						if ( i == j )
							continue;
						range = worksheet.Cells[ 1, j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EProvince registProv = AttributeCheck.CheckProvince( cellContent );
						range = worksheet.Cells[ i, j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint indNum = uint.Parse( cellContent );
						otherRegistProvNum.Add( registProv, indNum );
					}
					foreach ( EProvince parProv in otherRegistProvNum.Keys )
					{
						IndJointDis newRegistProvInd = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour, resideProv,
									ERaceType.Other, parProv, EEducateLevel.infant, EResidenceType.town, ERegistType.other );
						resideTypeResideProvRegistProvPartial.Add( newRegistProvInd, otherRegistProvNum[ parProv ] );
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0702c.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					Dictionary<EProvince, uint> otherRegistProvNum = new Dictionary<EProvince, uint>( );
					for ( int j = 3; j <= iColCount; j++ )
					{
						if ( i == j )
							continue;
						range = worksheet.Cells[ 1, j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EProvince registProv = AttributeCheck.CheckProvince( cellContent );
						range = worksheet.Cells[ i, j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint indNum = uint.Parse( cellContent );
						otherRegistProvNum.Add( registProv, indNum );
					}
					foreach ( EProvince parProv in otherRegistProvNum.Keys )
					{
						IndJointDis newRegistProvInd = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour, resideProv,
									ERaceType.Other, parProv, EEducateLevel.infant, EResidenceType.rural, ERegistType.other );
						resideTypeResideProvRegistProvPartial.Add( newRegistProvInd, otherRegistProvNum[ parProv ] );
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
			} catch ( Exception e )
			{
				throw new ApplicationException( e.Message );
			} finally
			{
				if ( workBook != null )
				{
					workBook.Close( false, objOpt, objOpt );
					System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
					workBook = null;
				}
				excelApp.Workbooks.Close( );
				excelApp.Quit( );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( excelApp );
				excelApp = null;
				GC.Collect( );
				GC.WaitForPendingFinalizers( );
			}
			string populationDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, InputPara.popDBName );
			MyDatabase populationDB = new MyDatabase( populationDBName );
			if ( !Directory.Exists( populationDBName ) )
			{
				throw new ApplicationException( InputPara.popDBName + " does not exist!!" );
			}
			populationDB.DBOpen( );
			DBIterator dbIter = populationDB.GetIterator( );
			uint lineNum = 0;
			Random rand = new Random( );
			for ( dbIter.SeekToFirst( ); dbIter.Valid( ); dbIter.Next( ) )
			{
				string keyStr = dbIter.Key( ).ToString( );
				string valueStr = dbIter.Value( ).ToString( );
				string[ ] attributes = valueStr.Split( '-' );
				EGender gender = (EGender)(int.Parse( attributes[ 0 ] ));
				ushort birthYear = ushort.Parse( attributes[ 1 ] );
				ushort birthMonth = ushort.Parse( attributes[ 2 ] );
				ushort age = ushort.Parse( attributes[ 3 ] );
				ERaceType race = (ERaceType)(int.Parse( attributes[ 4 ] ));
				EProvince registProvin = (EProvince)(int.Parse( attributes[ 5 ] ));
				ERegistType registType = (ERegistType)(int.Parse( attributes[ 6 ] ));
				EEducateLevel eduLv = (EEducateLevel)(int.Parse( attributes[ 7 ] ));
				EProvince resideProvin = (EProvince)(int.Parse( attributes[ 8 ] ));
				EResidenceType resideType = (EResidenceType)(int.Parse( attributes[ 9 ] ));
				if ( registType == ERegistType.other )
					registProvin = EProvince.Other;
				else
				{
					Dictionary<EProvince, uint> otherProvNum = new Dictionary<EProvince, uint>( );
					uint otherProvSum = 0;
					foreach ( IndJointDis parDis in resideTypeResideProvRegistProvPartial.Keys )
					{
						if ( parDis.ResideProvin == resideProvin && parDis.ResidenceType == resideType )
						{
							otherProvNum.Add( parDis.RegistProvin, resideTypeResideProvRegistProvPartial[ parDis ] );
							otherProvSum += resideTypeResideProvRegistProvPartial[ parDis ];
						}
					}
					EProvince[ ] otherProvKeys = new EProvince[ 31 ];
					double[ ] otherProvProbs = new double[ 31 ];
					int index = 1;
					foreach ( EProvince otherProv in otherProvNum.Keys )
					{
						otherProvKeys[ index ] = otherProv;
						otherProvProbs[ index ] = ((double)otherProvNum[ otherProv ]) / (otherProvSum + regNum[ resideProvin ]);
						index++;
					}
					otherProvKeys[ 0 ] = resideProvin;
					otherProvProbs[ 0 ] = (double)regNum[ resideProvin ] / (otherProvSum + regNum[ resideProvin ]);
					double alloSeed = rand.NextDouble( );
					double sumRatio = 0;
					for ( int i = 0; i < otherProvProbs.Length; i++ )
					{
						sumRatio += otherProvProbs[ i ];
						if ( alloSeed <= sumRatio )
						{
							registProvin = otherProvKeys[ i ];
							break;
						}
					}
				}
				string newValueStr = ((int)gender).ToString( );
				newValueStr += "-" + birthYear.ToString( );
				newValueStr += "-" + birthMonth.ToString( );
				newValueStr += "-" + age.ToString( );
				newValueStr += "-" + ((int)race).ToString( );
				newValueStr += "-" + ((int)registProvin).ToString( );
				newValueStr += "-" + ((int)registType).ToString( );
				newValueStr += "-" + ((int)eduLv).ToString( );
				newValueStr += "-" + ((int)resideProvin).ToString( );
				newValueStr += "-" + ((int)resideType).ToString( );
				populationDB.Update( keyStr, newValueStr );

				lineNum++;
				if ( lineNum % 10000000 == 0 )
					Console.WriteLine( "Regist Provin: " + string.Format( "{0:0,0}", lineNum ) + " ..." );
			}
			dbIter.Dispose( );
			populationDB.DBDispose( );
		}


		private ushort GenRandomAge( EAgeInterval ageInter )
		{
			int minBound = 0;
			int age = 0;
			switch ( ageInter )
			{
				case EAgeInterval.ZeroToFour: minBound = 0; break;
				case EAgeInterval.FiveToNine: minBound = 5; break;
				case EAgeInterval.TenToFourteen: minBound = 10; break;
				case EAgeInterval.FifteenToNineteen: minBound = 15; break;
				case EAgeInterval.TwentyToTwentyFour: minBound = 20; break;
				case EAgeInterval.TwentyFiveToTwentyNine: minBound = 25; break;
				case EAgeInterval.ThirtyToThirtyFour: minBound = 30; break;
				case EAgeInterval.ThirtyFiveToThirtyNine: minBound = 35; break;
				case EAgeInterval.FortyToFortyFour: minBound = 40; break;
				case EAgeInterval.FortyFiveToFortyNine: minBound = 45; break;
				case EAgeInterval.FiftyToFiftyFour: minBound = 50; break;
				case EAgeInterval.FiftyFiveToFiftyNine: minBound = 55; break;
				case EAgeInterval.SixtyToSixtyFour: minBound = 60; break;
				case EAgeInterval.SixtyFiveToSixtyNine: minBound = 65; break;
				case EAgeInterval.SeventyToSeventyFour: minBound = 70; break;
				case EAgeInterval.SeventyFiveToSeventyNine: minBound = 75; break;
				case EAgeInterval.EightyToEightyFour: minBound = 80; break;
				case EAgeInterval.EightyFiveToEightyNine: minBound = 85; break;
				case EAgeInterval.NinetyToNinetyFour: minBound = 90; break;
				case EAgeInterval.NinetyFiveToNinetyNine: minBound = 95; break;
				default: minBound = 100; break;
			}
			Random rand = new Random( );
			double ratio = rand.NextDouble( );
			if ( ratio < 0.2 )
				age = minBound;
			else if ( ratio < 0.4 )
				age = minBound + 1;
			else if ( ratio < 0.6 )
				age = minBound + 2;
			else if ( ratio < 0.8 )
				age = minBound + 3;
			else if ( ratio < 1 )
				age = minBound + 4;
			return (ushort)age;
		}
	}
}
