﻿
namespace PopSynForChina
{
	/// <summary>
	/// individual attribute combination
	/// </summary>
	public struct IndJointDis
	{
		private EGender gender;
		private EAgeInterval age;
		private EProvince resideProvin;
		private ERaceType race;
		private EProvince registProvin;
		private EEducateLevel eduLevel;
		private EResidenceType residenceType;
		private ERegistType registType;
		#region properties
		public EGender Gender
		{
			get { return gender; }
			set { gender = value; }
		}
		public EAgeInterval Age
		{
			get { return age; }
			set { age = value; }
		}
		public EProvince ResideProvin
		{
			get { return resideProvin; }
			set { resideProvin = value; }
		}
		public ERaceType Race
		{
			get { return race; }
			set { race = value; }
		}
		public EResidenceType ResidenceType
		{
			get { return residenceType; }
			set { residenceType = value; }
		}
		public ERegistType RegistType
		{
			get { return registType; }
			set { registType = value; }
		}
		public EEducateLevel EduLevel
		{
			get { return eduLevel; }
			set { eduLevel = value; }
		}
		public EProvince RegistProvin
		{
			get { return registProvin; }
			set { registProvin = value; }
		}
		#endregion
		public IndJointDis( EGender gender, EAgeInterval age, EProvince resideProvin,
			ERaceType race, EProvince registProvin, EEducateLevel eduLevel, EResidenceType residenceType, ERegistType registType )
		{
			this.gender = gender;
			this.age = age;
			this.resideProvin = resideProvin;
			this.race = race;
			this.registProvin = registProvin;
			this.eduLevel = eduLevel;
			this.residenceType = residenceType;
			this.registType = registType;
		}
	}

	public class Individual
	{
		private uint agentID;//unique agentID
		private EGender gender;
		private ushort birthYear;
		private ushort birthMonth;
		private ushort age;
		private ERaceType raceType;
		private EProvince registProvin;
		private ERegistType registType;
		private EEducateLevel educateLevel;

		private EProvince provin;
		private EResidenceType residenceType;

		#region properties
		public EProvince RegistProvin
		{
			get { return registProvin; }
			set { registProvin = value; }
		}
		public ERaceType RaceType
		{
			get { return raceType; }
			set { raceType = value; }
		}
		public ushort Age
		{
			get { return age; }
		}
		public EResidenceType ResidenceType
		{
			get { return residenceType; }
			set { residenceType = value; }
		}
		public EProvince Provin
		{
			get { return provin; }
			set { provin = value; }
		}
		public EEducateLevel EducateLevel
		{
			get { return educateLevel; }
			set { educateLevel = value; }
		}
		public ERegistType RegistType
		{
			get { return registType; }
			set { registType = value; }
		}
		public ushort BirthMonth
		{
			get { return birthMonth; }
		}
		public ushort BirthYear
		{
			get { return birthYear; }
		}
		public EGender Gender
		{
			get { return gender; }
		}
		public uint AgentID
		{
			get { return agentID; }
			set { agentID = value; }
		}
		#endregion

		public Individual( uint agentID, EGender gender, ushort birthYear, ushort birthMonth, ushort age, ERaceType race,
			EProvince registProvin, ERegistType registType, EEducateLevel educateLevel, EProvince provin, EResidenceType residenceType )
		{
			this.agentID = agentID;
			this.gender = gender;
			this.birthYear = birthYear;
			this.birthMonth = birthMonth;
			this.age = age;
			this.raceType = race;
			this.registProvin = registProvin;
			this.registType = registType;
			this.educateLevel = educateLevel;
			this.provin = provin;
			this.residenceType = residenceType;
		}
	}
}
