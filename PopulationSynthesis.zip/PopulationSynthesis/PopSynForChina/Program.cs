﻿using System;
using System.Diagnostics;

namespace PopSynForChina
{
	class Program
	{
		static void Main( string[ ] args )
		{
			if ( args.Length != 1 )
				return;
			try
			{
				Stopwatch stopw = new Stopwatch( );
				if ( args[ 0 ] == "SFF" )
				{
					stopw.Start( );
					InputPara.LoadSFFPara( );
					SFFGenerator SFFGen = new SFFGenerator( );
					SFFGen.PopGeneration( );
					stopw.Stop( );
					Console.WriteLine( "Time Elapsed: " + stopw.Elapsed );
				} else if ( args[ 0 ] == "MCMC" )
				{
					stopw.Start( );
					InputPara.LoadMCMCPara( );
					MCMCGenerator MCMGen = new MCMCGenerator( InputPara.transferNum, InputPara.sampleInterval,
						InputPara.sampleSize, InputPara.jointDisDBName, InputPara.readJointDisFromDB );
					MCMGen.PopGeneration( );
					stopw.Stop( );
					Console.WriteLine( "Time Elapsed: " + stopw.Elapsed );
				} else if ( args[ 0 ] == "JDI" )
				{
					stopw.Start( );
					InputPara.LoadJDIPara( );
					JDIGenerator JDIGen = new JDIGenerator( InputPara.readJointDisFromDB );
					JDIGen.PopGeneration( );
					stopw.Stop( );
					Console.WriteLine( "Time Elapsed: " + stopw.Elapsed );
				} else
				{
					Console.WriteLine( "please enter correct parameter..." );
				}
			} catch ( Exception e )
			{
				Console.WriteLine( e.Message );
				Console.WriteLine( e.StackTrace );
				Console.WriteLine( e.Source );
				Console.WriteLine( e.InnerException.Message );
			}
			Console.ReadLine( );
		}
	}
}
