﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using Excel = Microsoft.Office.Interop.Excel;

namespace PopSynForChina
{
	public class JDIGenerator
	{
		private bool readJointDisFromDB;//control flag for ditribution fitting or population realization
		private Dictionary<IndJointDis, uint> jointDistribution;//joint distribution
		//attribute sets:
		private HashSet<EProvince> resideProvSet;
		private HashSet<EResidenceType> residenceTypeSet;
		private HashSet<EProvince> registProvSet;
		private HashSet<EAgeInterval> ageSet;
		private HashSet<EGender> genderSet;
		private HashSet<EEducateLevel> eduLevelSet;
		private HashSet<ERaceType> raceSet;
		private HashSet<ERegistType> registTypeSet;

		public JDIGenerator( bool readJointDisFromDB )
		{
			jointDistribution = new Dictionary<IndJointDis, uint>( );
			resideProvSet = new HashSet<EProvince>( );
			residenceTypeSet = new HashSet<EResidenceType>( );
			registProvSet = new HashSet<EProvince>( );
			ageSet = new HashSet<EAgeInterval>( );
			genderSet = new HashSet<EGender>( );
			eduLevelSet = new HashSet<EEducateLevel>( );
			raceSet = new HashSet<ERaceType>( );
			registTypeSet = new HashSet<ERegistType>( );
			this.readJointDisFromDB = readJointDisFromDB;
		}

		public void PopGeneration( )
		{
			if ( !readJointDisFromDB )
			{
				JointDisInference( );
				Console.WriteLine( "JDI Fitted distribution has been stored in database." );
				jointDistribution.Clear( );
			} else
			{
				Console.WriteLine( "Allocation starts..." );
				Allocation( );
				Console.WriteLine( "Allocation complete!!" );
			}
		}

		private void JointDisInference( )
		{
			IniGenderRaceResideTypeResideProv( );

			ExtendAge( );
			Console.WriteLine( "Generate Age complete!" );

			ExtendEducationLevel( );
			Console.WriteLine( "Generate Education Level complete!" );

			ExtendRegistType( );
			Console.WriteLine( "Generate Regist Type complete!" );

			ExtendRegistProv( );
			Console.WriteLine( "Generate Regist Province complete!" );
		}


		/// <summary>
		/// compute Gender*Ethnic Group*Residence Type*Residential Province partial joint distribution
		/// </summary>
		private void IniGenderRaceResideTypeResideProv( )
		{
			Excel.Application excelApp = new Excel.Application( );
			object objOpt = System.Reflection.Missing.Value;
			Excel.Workbook workBook = null;
			Excel.Sheets sheets;
			Excel.Worksheet worksheet;
			Excel.Range range;
			try
			{
				int iRowCount = 0;
				int iColCount = 0;
				string cellContent = null;
				//city
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0106a.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					ERaceType race = (ERaceType)(j - 1);
					uint totalNumByRace = uint.Parse( cellContent );
					for ( int i = 3; i <= iRowCount; i++ )
					{
						range = worksheet.Cells[ i, 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
						range = worksheet.Cells[ i, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						IndJointDis maleJointDis = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour,
							resideProv, race, EProvince.Other, EEducateLevel.infant, EResidenceType.city, ERegistType.other );
						jointDistribution.Add( maleJointDis, maleNum );
						range = worksheet.Cells[ i, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						IndJointDis femaleJointDis = new IndJointDis( EGender.Female, EAgeInterval.ZeroToFour,
							resideProv, race, EProvince.Other, EEducateLevel.infant, EResidenceType.city, ERegistType.other );
						jointDistribution.Add( femaleJointDis, femaleNum );
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				//town
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0106b.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					ERaceType race = (ERaceType)(j - 1);
					uint totalNumByRace = uint.Parse( cellContent );
					for ( int i = 3; i <= iRowCount; i++ )
					{
						range = worksheet.Cells[ i, 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
						range = worksheet.Cells[ i, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						IndJointDis maleJointDis = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour,
							resideProv, race, EProvince.Other, EEducateLevel.infant, EResidenceType.town, ERegistType.other );
						jointDistribution.Add( maleJointDis, maleNum );
						range = worksheet.Cells[ i, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						IndJointDis femaleJointDis = new IndJointDis( EGender.Female, EAgeInterval.ZeroToFour,
							resideProv, race, EProvince.Other, EEducateLevel.infant, EResidenceType.town, ERegistType.other );
						jointDistribution.Add( femaleJointDis, femaleNum );
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				//rural
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0106c.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					ERaceType race = (ERaceType)(j - 1);
					uint totalNumByRace = uint.Parse( cellContent );
					for ( int i = 3; i <= iRowCount; i++ )
					{
						range = worksheet.Cells[ i, 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
						range = worksheet.Cells[ i, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						IndJointDis maleJointDis = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour,
							resideProv, race, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.other );
						jointDistribution.Add( maleJointDis, maleNum );
						range = worksheet.Cells[ i, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						IndJointDis femaleJointDis = new IndJointDis( EGender.Female, EAgeInterval.ZeroToFour,
							resideProv, race, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.other );
						jointDistribution.Add( femaleJointDis, femaleNum );
					}
				}
			} catch ( Exception e )
			{
				throw new ApplicationException( e.Message );
			} finally
			{
				if ( workBook != null )
				{
					workBook.Close( false, objOpt, objOpt );
					System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
					workBook = null;
				}
				excelApp.Workbooks.Close( );
				excelApp.Quit( );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( excelApp );
				excelApp = null;
				GC.Collect( );
				GC.WaitForPendingFinalizers( );
			}
			List<IndJointDis> keys = new List<IndJointDis>( );
			keys.AddRange( jointDistribution.Keys );
			foreach ( IndJointDis parDis in keys )
			{
				if ( jointDistribution[ parDis ] == 0 )
				{
					jointDistribution.Remove( parDis );
				}
			}
			foreach ( IndJointDis parDis in jointDistribution.Keys )
			{
				genderSet.Add( parDis.Gender );
				raceSet.Add( parDis.Race );
				residenceTypeSet.Add( parDis.ResidenceType );
				resideProvSet.Add( parDis.ResideProvin );
			}
			//Gender allocation probability
			{
				uint maleSum = 0;
				uint femaleSum = 0;
				foreach ( IndJointDis parDis in jointDistribution.Keys )
				{
					if ( parDis.Gender == EGender.Male )
						maleSum += jointDistribution[ parDis ];
					else
						femaleSum += jointDistribution[ parDis ];
				}
				double maleProb = (double)maleSum / (maleSum + femaleSum);
				double femaleProb = (double)femaleSum / (maleSum + femaleSum);
				string genderConProDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, "Gender" );
				MyDatabase genderConProDB = new MyDatabase( genderConProDBName );
				if ( Directory.Exists( genderConProDBName ) )
					Directory.Delete( genderConProDBName, true );
				genderConProDB.DBOpen( );
				string keyStr = EGender.Male.ToString( );
				string valStr = maleProb.ToString( );
				genderConProDB.WriteAsyn( keyStr, valStr );
				keyStr = EGender.Female.ToString( );
				valStr = femaleProb.ToString( );
				genderConProDB.WriteAsyn( keyStr, valStr );
				genderConProDB.DBDispose( );
				Console.WriteLine( "Gender probability generated!" );
			}
			//Ethnic Group conditional probability
			{
				string raceConProDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, "Race" );
				MyDatabase raceConProDB = new MyDatabase( raceConProDBName );
				if ( Directory.Exists( raceConProDBName ) )
					Directory.Delete( raceConProDBName, true );
				raceConProDB.DBOpen( );
				foreach ( EGender gender in genderSet )
				{
					uint sumNum = 0;
					Dictionary<ERaceType, uint> indNums = new Dictionary<ERaceType, uint>( );
					foreach ( ERaceType race in raceSet )
						indNums.Add( race, 0 );
					foreach ( IndJointDis parDis in jointDistribution.Keys )
					{
						if ( parDis.Gender == gender )
						{
							sumNum += jointDistribution[ parDis ];
							indNums[ parDis.Race ] += jointDistribution[ parDis ];
						}
					}
					foreach ( ERaceType race in raceSet )
					{
						string keyStr = gender.ToString( );
						keyStr += "-" + race.ToString( );
						if ( sumNum > 0 )
						{
							string valStr = ((double)indNums[ race ] / sumNum).ToString( );
							raceConProDB.WriteAsyn( keyStr, valStr );
						}
					}
				}
				raceConProDB.DBDispose( );
				Console.WriteLine( "Race probability generated!" );
			}
			//Residence Type conditional probability
			{
				string resideTypeConProDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, "ResideType" );
				MyDatabase resideTypeConProDB = new MyDatabase( resideTypeConProDBName );
				if ( Directory.Exists( resideTypeConProDBName ) )
					Directory.Delete( resideTypeConProDBName, true );
				resideTypeConProDB.DBOpen( );
				foreach ( EGender gender in genderSet )
				{
					foreach ( ERaceType race in raceSet )
					{
						uint sumNum = 0;
						Dictionary<EResidenceType, uint> indNums = new Dictionary<EResidenceType, uint>( );
						foreach ( EResidenceType resideType in residenceTypeSet )
							indNums.Add( resideType, 0 );
						foreach ( IndJointDis parDis in jointDistribution.Keys )
						{
							if ( parDis.Gender == gender && parDis.Race == race )
							{
								sumNum += jointDistribution[ parDis ];
								indNums[ parDis.ResidenceType ] += jointDistribution[ parDis ];
							}
						}
						foreach ( EResidenceType resideType in residenceTypeSet )
						{
							string keyStr = gender.ToString( );
							keyStr += "-" + race.ToString( );
							keyStr += "-" + resideType.ToString( );
							if ( sumNum > 0 )
							{
								string valStr = ((double)indNums[ resideType ] / sumNum).ToString( );
								resideTypeConProDB.WriteAsyn( keyStr, valStr );
							}
						}
					}
				}
				resideTypeConProDB.DBDispose( );
				Console.WriteLine( "Residence type probability generated!" );
			}
			//Residential Province conditional probability
			{
				string resideProvConProDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, "ResideProv" );
				MyDatabase resideProvConProDB = new MyDatabase( resideProvConProDBName );
				if ( Directory.Exists( resideProvConProDBName ) )
					Directory.Delete( resideProvConProDBName, true );
				resideProvConProDB.DBOpen( );
				foreach ( EGender gender in genderSet )
				{
					foreach ( ERaceType race in raceSet )
					{
						foreach ( EResidenceType resideType in residenceTypeSet )
						{
							uint sumNum = 0;
							Dictionary<EProvince, uint> indNums = new Dictionary<EProvince, uint>( );
							foreach ( EProvince resideProv in resideProvSet )
								indNums.Add( resideProv, 0 );
							foreach ( IndJointDis parDis in jointDistribution.Keys )
							{
								if ( parDis.Gender == gender && parDis.Race == race && parDis.ResidenceType == resideType )
								{
									sumNum += jointDistribution[ parDis ];
									indNums[ parDis.ResideProvin ] += jointDistribution[ parDis ];
								}
							}
							foreach ( EProvince resideProv in resideProvSet )
							{
								string keyStr = gender.ToString( );
								keyStr += "-" + race.ToString( );
								keyStr += "-" + resideType.ToString( );
								keyStr += "-" + resideProv.ToString( );
								if ( sumNum > 0 )
								{
									string valStr = ((double)indNums[ resideProv ] / sumNum).ToString( );
									resideProvConProDB.WriteAsyn( keyStr, valStr );
								}
							}
						}
					}
				}
				resideProvConProDB.DBDispose( );
				Console.WriteLine( "Reside province probability generated!" );
			}
		}

		/// <summary>
		/// expand Age Interval
		/// </summary>
		private void ExtendAge( )
		{
			//Age Interval marginal
			Dictionary<IndJointDis, uint> ageMarginal = new Dictionary<IndJointDis, uint>( );
			//Residential Province*Age Interval partial joint distribution
			Dictionary<IndJointDis, uint> resideProvAgePartial = new Dictionary<IndJointDis, uint>( );
			Excel.Application excelApp = new Excel.Application( );
			object objOpt = System.Reflection.Missing.Value;
			Excel.Workbook workBook = null;
			Excel.Sheets sheets;
			Excel.Worksheet worksheet;
			Excel.Range range;
			try
			{
				int iRowCount = 0;
				int iColCount = 0;
				string cellContent = null;
				//Age Interval marginal
				#region city
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0201a.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					ERaceType race = (ERaceType)(j - 1);
					for ( int i = 1; i <= iRowCount; i++ )
					{
						range = worksheet.Cells[ 6 * i - 3, 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						string ageNum = null;
						foreach ( char item in cellContent )
						{
							if ( item >= 48 && item <= 58 )
							{
								ageNum += item;
							} else
							{
								break;
							}
						}
						EAgeInterval age = AttributeCheck.CheckAgeInterval( ushort.Parse( ageNum ) );
						range = worksheet.Cells[ 6 * i - 3, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						IndJointDis newMaleInd = new IndJointDis( EGender.Male, age, EProvince.Other, race,
							EProvince.Other, EEducateLevel.infant, EResidenceType.city, ERegistType.other );
						ageMarginal.Add( newMaleInd, maleNum );
						range = worksheet.Cells[ 6 * i - 3, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						IndJointDis newFemaleInd = new IndJointDis( EGender.Female, age, EProvince.Other, race,
							EProvince.Other, EEducateLevel.infant, EResidenceType.city, ERegistType.other );
						ageMarginal.Add( newFemaleInd, femaleNum );
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region town
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0201b.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					ERaceType race = (ERaceType)(j - 1);
					for ( int i = 1; i <= iRowCount; i++ )
					{
						range = worksheet.Cells[ 6 * i - 3, 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						string ageNum = null;
						foreach ( char item in cellContent )
						{
							if ( item >= 48 && item <= 58 )
							{
								ageNum += item;
							} else
							{
								break;
							}
						}
						EAgeInterval age = AttributeCheck.CheckAgeInterval( ushort.Parse( ageNum ) );
						range = worksheet.Cells[ 6 * i - 3, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						IndJointDis newMaleInd = new IndJointDis( EGender.Male, age, EProvince.Other, race,
							EProvince.Other, EEducateLevel.infant, EResidenceType.town, ERegistType.other );
						ageMarginal.Add( newMaleInd, maleNum );
						range = worksheet.Cells[ 6 * i - 3, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						IndJointDis newFemaleInd = new IndJointDis( EGender.Female, age, EProvince.Other, race,
							EProvince.Other, EEducateLevel.infant, EResidenceType.town, ERegistType.other );
						ageMarginal.Add( newFemaleInd, femaleNum );
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region rural
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0201c.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					ERaceType race = (ERaceType)(j - 1);
					for ( int i = 1; i <= iRowCount; i++ )
					{
						range = worksheet.Cells[ 6 * i - 3, 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						string ageNum = null;
						foreach ( char item in cellContent )
						{
							if ( item >= 48 && item <= 58 )
							{
								ageNum += item;
							} else
							{
								break;
							}
						}
						EAgeInterval age = AttributeCheck.CheckAgeInterval( ushort.Parse( ageNum ) );
						range = worksheet.Cells[ 6 * i - 3, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						IndJointDis newMaleInd = new IndJointDis( EGender.Male, age, EProvince.Other, race,
							EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.other );
						ageMarginal.Add( newMaleInd, maleNum );
						range = worksheet.Cells[ 6 * i - 3, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						IndJointDis newFemaleInd = new IndJointDis( EGender.Female, age, EProvince.Other, race,
							EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.other );
						ageMarginal.Add( newFemaleInd, femaleNum );
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				//Residential Province*Age Interval partial joint distribution
				#region city
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0107a.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					for ( int j = 3; j <= iColCount; j++ )
					{
						range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EAgeInterval ageInter = (EAgeInterval)(j - 3);
						range = worksheet.Cells[ i, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						IndJointDis newMaleInd = new IndJointDis( EGender.Male, ageInter, resideProv,
							ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.city, ERegistType.other );
						resideProvAgePartial.Add( newMaleInd, maleNum );
						range = worksheet.Cells[ i, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						IndJointDis newFemaleInd = new IndJointDis( EGender.Female, ageInter, resideProv,
							ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.city, ERegistType.other );
						resideProvAgePartial.Add( newFemaleInd, femaleNum );
					}
					List<IndJointDis> partialDisKeys = new List<IndJointDis>( );
					partialDisKeys.AddRange( resideProvAgePartial.Keys );
					range = worksheet.Cells[ i, 3 * 2 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint zeroMaleNum = uint.Parse( cellContent );
					foreach ( IndJointDis parDis in partialDisKeys )
					{
						if ( parDis.Gender == EGender.Male && parDis.ResidenceType == EResidenceType.city
							&& parDis.ResideProvin == resideProv && parDis.Age == EAgeInterval.ZeroToFour )
							resideProvAgePartial[ parDis ] += zeroMaleNum;
					}
					range = worksheet.Cells[ i, 3 * 2 + 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint zeroFemaleNum = uint.Parse( cellContent );
					foreach ( IndJointDis parDis in partialDisKeys )
					{
						if ( parDis.Gender == EGender.Female && parDis.ResidenceType == EResidenceType.city
							&& parDis.ResideProvin == resideProv && parDis.Age == EAgeInterval.ZeroToFour )
							resideProvAgePartial[ parDis ] += zeroFemaleNum;
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region town
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0107b.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					for ( int j = 3; j <= iColCount; j++ )
					{
						range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EAgeInterval ageInter = (EAgeInterval)(j - 3);
						range = worksheet.Cells[ i, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						IndJointDis newMaleInd = new IndJointDis( EGender.Male, ageInter, resideProv,
							ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.town, ERegistType.other );
						resideProvAgePartial.Add( newMaleInd, maleNum );
						range = worksheet.Cells[ i, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						IndJointDis newFemaleInd = new IndJointDis( EGender.Female, ageInter, resideProv,
							ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.town, ERegistType.other );
						resideProvAgePartial.Add( newFemaleInd, femaleNum );
					}
					List<IndJointDis> partialDisKeys = new List<IndJointDis>( );
					partialDisKeys.AddRange( resideProvAgePartial.Keys );
					range = worksheet.Cells[ i, 3 * 2 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint zeroMaleNum = uint.Parse( cellContent );
					foreach ( IndJointDis parDis in partialDisKeys )
					{
						if ( parDis.Gender == EGender.Male && parDis.ResidenceType == EResidenceType.town
							&& parDis.ResideProvin == resideProv && parDis.Age == EAgeInterval.ZeroToFour )
							resideProvAgePartial[ parDis ] += zeroMaleNum;
					}
					range = worksheet.Cells[ i, 3 * 2 + 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint zeroFemaleNum = uint.Parse( cellContent );
					foreach ( IndJointDis parDis in partialDisKeys )
					{
						if ( parDis.Gender == EGender.Female && parDis.ResidenceType == EResidenceType.town
							&& parDis.ResideProvin == resideProv && parDis.Age == EAgeInterval.ZeroToFour )
							resideProvAgePartial[ parDis ] += zeroFemaleNum;
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region rural
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0107c.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					for ( int j = 3; j <= iColCount; j++ )
					{
						range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EAgeInterval ageInter = (EAgeInterval)(j - 3);
						range = worksheet.Cells[ i, 3 * j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						IndJointDis newMaleInd = new IndJointDis( EGender.Male, ageInter, resideProv,
							ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.other );
						resideProvAgePartial.Add( newMaleInd, maleNum );
						range = worksheet.Cells[ i, 3 * j + 1 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						IndJointDis newFemaleInd = new IndJointDis( EGender.Female, ageInter, resideProv,
							ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.other );
						resideProvAgePartial.Add( newFemaleInd, femaleNum );
					}
					List<IndJointDis> partialDisKeys = new List<IndJointDis>( );
					partialDisKeys.AddRange( resideProvAgePartial.Keys );
					range = worksheet.Cells[ i, 3 * 2 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint zeroMaleNum = uint.Parse( cellContent );
					foreach ( IndJointDis parDis in partialDisKeys )
					{
						if ( parDis.Gender == EGender.Male && parDis.ResidenceType == EResidenceType.rural
							&& parDis.ResideProvin == resideProv && parDis.Age == EAgeInterval.ZeroToFour )
							resideProvAgePartial[ parDis ] += zeroMaleNum;
					}
					range = worksheet.Cells[ i, 3 * 2 + 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint zeroFemaleNum = uint.Parse( cellContent );
					foreach ( IndJointDis parDis in partialDisKeys )
					{
						if ( parDis.Gender == EGender.Female && parDis.ResidenceType == EResidenceType.rural
							&& parDis.ResideProvin == resideProv && parDis.Age == EAgeInterval.ZeroToFour )
							resideProvAgePartial[ parDis ] += zeroFemaleNum;
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
			} catch ( Exception e )
			{
				throw new ApplicationException( e.Message );
			} finally
			{
				if ( workBook != null )
				{
					workBook.Close( false, objOpt, objOpt );
					System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
					workBook = null;
				}
				excelApp.Workbooks.Close( );
				excelApp.Quit( );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( excelApp );
				excelApp = null;
				GC.Collect( );
				GC.WaitForPendingFinalizers( );
			}
			List<IndJointDis> jointKeys = new List<IndJointDis>( );
			jointKeys.AddRange( jointDistribution.Keys );
			foreach ( IndJointDis parDis in jointKeys )
			{
				if ( jointDistribution[ parDis ] == 0 )
				{
					jointDistribution.Remove( parDis );
				}
			}
			foreach ( IndJointDis parDis in ageMarginal.Keys )
			{
				ageSet.Add( parDis.Age );
				if ( ageSet.Count >= 21 )
					break;
			}
			jointKeys = null;
			string ageConProDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, "Age" );
			MyDatabase ageConProDB = new MyDatabase( ageConProDBName );
			if ( Directory.Exists( ageConProDBName ) )
				Directory.Delete( ageConProDBName, true );
			ageConProDB.DBOpen( );
			foreach ( EGender gender in genderSet )
			{
				foreach ( ERaceType race in raceSet )
				{
					foreach ( EResidenceType resideType in residenceTypeSet )
					{
						Dictionary<EProvince, uint> resideProvConMarginal = new Dictionary<EProvince, uint>( );
						foreach ( IndJointDis parDis in jointDistribution.Keys )
						{
							if ( parDis.Gender == gender && parDis.Race == race && parDis.ResidenceType == resideType )
							{
								if ( resideProvConMarginal.ContainsKey( parDis.ResideProvin ) )
								{
									resideProvConMarginal[ parDis.ResideProvin ] += jointDistribution[ parDis ];
								} else
								{
									resideProvConMarginal.Add( parDis.ResideProvin, jointDistribution[ parDis ] );
								}
							}
						}
						Dictionary<EAgeInterval, uint> ageConMarginal = new Dictionary<EAgeInterval, uint>( );
						foreach ( IndJointDis parDis in ageMarginal.Keys )
						{
							if ( parDis.Gender == gender && parDis.Race == race && parDis.ResidenceType == resideType )
							{
								if ( ageConMarginal.ContainsKey( parDis.Age ) )
								{
									ageConMarginal[ parDis.Age ] += ageMarginal[ parDis ];
								} else
								{
									ageConMarginal.Add( parDis.Age, ageMarginal[ parDis ] );
								}
							}
						}
						List<IndJointDis> keys = new List<IndJointDis>( );
						foreach ( IndJointDis parDis in resideProvAgePartial.Keys )
						{
							if ( parDis.Gender == gender && parDis.ResidenceType == resideType )
								keys.Add( parDis );
						}
						//IPF
						uint error = uint.MaxValue;
						for ( int i = 0; i < 100; i++ )
						{
							foreach ( EProvince resideProv in resideProvSet )
							{
								uint resideProvSumNum = 0;
								foreach ( IndJointDis parDis in keys )
								{
									if ( parDis.ResideProvin == resideProv )
										resideProvSumNum += resideProvAgePartial[ parDis ];
								}
								foreach ( IndJointDis parDis in keys )
								{
									if ( resideProvAgePartial[ parDis ] == 0 )
										continue;
									if ( parDis.ResideProvin == resideProv )
									{
										if ( resideProvConMarginal.ContainsKey( resideProv ) )
										{
											uint indNum = Convert.ToUInt32( (double)resideProvAgePartial[ parDis ]
																		/ resideProvSumNum * resideProvConMarginal[ resideProv ] );
											if ( indNum != 0 )
												resideProvAgePartial[ parDis ] = Convert.ToUInt32( (double)resideProvAgePartial[ parDis ]
																			/ resideProvSumNum * resideProvConMarginal[ resideProv ] );
											else
												resideProvAgePartial[ parDis ] = 1;
										} else
											resideProvAgePartial[ parDis ] = 0;
									}
								}
							}
							foreach ( EAgeInterval age in ageSet )
							{
								uint ageSumNum = 0;
								foreach ( IndJointDis parDis in keys )
								{
									if ( parDis.Age == age )
										ageSumNum += resideProvAgePartial[ parDis ];
								}
								foreach ( IndJointDis parDis in keys )
								{
									if ( resideProvAgePartial[ parDis ] == 0 )
										continue;
									if ( parDis.Age == age )
									{
										if ( ageConMarginal.ContainsKey( age ) )
										{
											uint indNum = Convert.ToUInt32( (double)resideProvAgePartial[ parDis ]
																				/ ageSumNum * ageConMarginal[ age ] );
											if ( indNum != 0 )
												resideProvAgePartial[ parDis ] = Convert.ToUInt32( (double)resideProvAgePartial[ parDis ]
																					/ ageSumNum * ageConMarginal[ age ] );
											else
												resideProvAgePartial[ parDis ] = 1;
										} else
											resideProvAgePartial[ parDis ] = 0;
									}
								}
							}
							error = ComputeL1Error( resideProvAgePartial, keys, resideProvConMarginal, ageConMarginal );
							if ( error < 100 )
								break;
						}
						//compute (Gender*Ethnic Group*Residence Type)*Residential Province*Age Interval joint distribution
						uint genderRaceResideTypeSum = 0;
						List<IndJointDis> jointDisKeys = new List<IndJointDis>( );
						foreach ( IndJointDis parDis in jointDistribution.Keys )
						{
							if ( parDis.Gender == gender && parDis.Race == race && parDis.ResidenceType == resideType )
							{
								genderRaceResideTypeSum += jointDistribution[ parDis ];
								jointDisKeys.Add( parDis );
							}
						}
						uint resideProvAgeSum = 0;
						foreach ( IndJointDis parDis in keys )
						{
							resideProvAgeSum += resideProvAgePartial[ parDis ];
						}
						foreach ( IndJointDis parDis in jointDisKeys )
						{
							uint origIndNum = jointDistribution[ parDis ];
							jointDistribution.Remove( parDis );
							Dictionary<EAgeInterval, uint> conFreq = new Dictionary<EAgeInterval, uint>( );
							uint sumNum = 0;
							foreach ( EAgeInterval age in ageSet )
							{
								IndJointDis newJointDis = new IndJointDis( parDis.Gender, age,
									parDis.ResideProvin, parDis.Race, parDis.RegistProvin, parDis.EduLevel, parDis.ResidenceType, parDis.RegistType );
								uint indNum = 0;
								foreach ( IndJointDis partialDis in keys )
								{
									if ( partialDis.ResideProvin == parDis.ResideProvin && partialDis.Age == age )
									{
										if ( resideProvAgeSum != 0 )
											indNum = (uint)(Math.Round( (double)resideProvAgePartial[ partialDis ]
												/ resideProvAgeSum * genderRaceResideTypeSum ));
										else
											indNum = 1;
										break;
									}
								}
								jointDistribution.Add( newJointDis, indNum );
								conFreq.Add( age, indNum );
								sumNum += indNum;
							}
							//conditional probability
							foreach ( EAgeInterval age in conFreq.Keys )
							{
								string keyStr = parDis.Gender.ToString( );
								keyStr += "-" + parDis.Race.ToString( );
								keyStr += "-" + parDis.ResidenceType.ToString( );
								keyStr += "-" + parDis.ResideProvin.ToString( );
								keyStr += "-" + age.ToString( );
								if ( sumNum > 0 )
								{
									string valStr = ((double)conFreq[ age ] / sumNum).ToString( );
									ageConProDB.WriteAsyn( keyStr, valStr );
								}
							}
						}
					}
				}
			}
			ageConProDB.DBDispose( );
		}

		/// <summary>
		/// expand Educational Level
		/// </summary>
		private void ExtendEducationLevel( )
		{
			//Educational Level marginal
			Dictionary<IndJointDis, uint> eduLvMarginal = new Dictionary<IndJointDis, uint>( );
			//Residential Province*Educational Level partial joint distribution
			Dictionary<IndJointDis, uint> resideProvEduLvPartial = new Dictionary<IndJointDis, uint>( );
			Excel.Application excelApp = new Excel.Application( );
			object objOpt = System.Reflection.Missing.Value;
			Excel.Workbook workBook = null;
			Excel.Sheets sheets;
			Excel.Worksheet worksheet;
			Excel.Range range;
			try
			{
				int iRowCount = 0;
				int iColCount = 0;
				string cellContent = null;
				//Educational Level marginal
				#region city
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0401a.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 2; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ 6 * i - 4, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EAgeInterval ageInter = (EAgeInterval)i;
					if ( (int)ageInter <= 12 )
					{
						for ( int j = 2; j <= iColCount; j++ )
						{
							range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
							cellContent = range.Text as string;
							cellContent = cellContent.Trim( );
							if ( cellContent == "" )
								break;
							EEducateLevel eduLevel = (EEducateLevel)(j - 1);
							range = worksheet.Cells[ 6 * i - 4, 3 * j ] as Excel.Range;
							cellContent = range.Text as string;
							cellContent = cellContent.Trim( );
							if ( cellContent == "" )
								cellContent = "0";
							uint maleNum = uint.Parse( cellContent );
							range = worksheet.Cells[ 6 * i - 4, 3 * j + 1 ] as Excel.Range;
							cellContent = range.Text as string;
							cellContent = cellContent.Trim( );
							if ( cellContent == "" )
								cellContent = "0";
							uint femaleNum = uint.Parse( cellContent );
							IndJointDis newMaleEduLvJointDis = new IndJointDis( EGender.Male, ageInter, EProvince.Other,
								ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
							eduLvMarginal.Add( newMaleEduLvJointDis, maleNum );
							IndJointDis newFemaleEduLvJointDis = new IndJointDis( EGender.Female, ageInter, EProvince.Other,
								ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
							eduLvMarginal.Add( newFemaleEduLvJointDis, femaleNum );
						}
					} else
					{
						for ( int j = 2; j <= iColCount; j++ )
						{
							range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
							cellContent = range.Text as string;
							cellContent = cellContent.Trim( );
							if ( cellContent == "" )
								break;
							EEducateLevel eduLevel = (EEducateLevel)(j - 1);
							range = worksheet.Cells[ 6 * i - 4, 3 * j ] as Excel.Range;
							cellContent = range.Text as string;
							cellContent = cellContent.Trim( );
							if ( cellContent == "" )
								cellContent = "0";
							uint maleNum = uint.Parse( cellContent );
							IndJointDis maleEduLv65To69 = new IndJointDis( EGender.Male, EAgeInterval.SixtyFiveToSixtyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
							eduLvMarginal.Add( maleEduLv65To69, maleNum / 8 );
							IndJointDis maleEduLv70To74 = new IndJointDis( EGender.Male, EAgeInterval.SeventyToSeventyFour, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
							eduLvMarginal.Add( maleEduLv70To74, maleNum / 8 );
							IndJointDis maleEduLv75To79 = new IndJointDis( EGender.Male, EAgeInterval.SeventyFiveToSeventyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
							eduLvMarginal.Add( maleEduLv75To79, maleNum / 8 );
							IndJointDis maleEduLv80To84 = new IndJointDis( EGender.Male, EAgeInterval.EightyToEightyFour, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
							eduLvMarginal.Add( maleEduLv80To84, maleNum / 8 );
							IndJointDis maleEduLv85To89 = new IndJointDis( EGender.Male, EAgeInterval.EightyFiveToEightyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
							eduLvMarginal.Add( maleEduLv85To89, maleNum / 8 );
							IndJointDis maleEduLv90To94 = new IndJointDis( EGender.Male, EAgeInterval.NinetyToNinetyFour, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
							eduLvMarginal.Add( maleEduLv90To94, maleNum / 8 );
							IndJointDis maleEduLv95To99 = new IndJointDis( EGender.Male, EAgeInterval.NinetyFiveToNinetyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
							eduLvMarginal.Add( maleEduLv95To99, maleNum / 8 );
							IndJointDis maleEduLv100above = new IndJointDis( EGender.Male, EAgeInterval.HundredAndAbove, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
							eduLvMarginal.Add( maleEduLv100above, maleNum / 8 );
							range = worksheet.Cells[ 6 * i - 4, 3 * j + 1 ] as Excel.Range;
							cellContent = range.Text as string;
							cellContent = cellContent.Trim( );
							if ( cellContent == "" )
								cellContent = "0";
							uint femaleNum = uint.Parse( cellContent );
							IndJointDis femaleEduLv65To69 = new IndJointDis( EGender.Female, EAgeInterval.SixtyFiveToSixtyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv65To69, femaleNum / 8 );
							IndJointDis femaleEduLv70To74 = new IndJointDis( EGender.Female, EAgeInterval.SeventyToSeventyFour, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv70To74, femaleNum / 8 );
							IndJointDis femaleEduLv75To79 = new IndJointDis( EGender.Female, EAgeInterval.SeventyFiveToSeventyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv75To79, femaleNum / 8 );
							IndJointDis femaleEduLv80To84 = new IndJointDis( EGender.Female, EAgeInterval.EightyToEightyFour, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv80To84, femaleNum / 8 );
							IndJointDis femaleEduLv85To89 = new IndJointDis( EGender.Female, EAgeInterval.EightyFiveToEightyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv85To89, femaleNum / 8 );
							IndJointDis femaleEduLv90To94 = new IndJointDis( EGender.Female, EAgeInterval.NinetyToNinetyFour, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv90To94, femaleNum / 8 );
							IndJointDis femaleEduLv95To99 = new IndJointDis( EGender.Female, EAgeInterval.NinetyFiveToNinetyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv95To99, femaleNum / 8 );
							IndJointDis femaleEduLv100above = new IndJointDis( EGender.Female, EAgeInterval.HundredAndAbove, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv100above, femaleNum / 8 );
						}
					}
				}
				//6-9 year old people:
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EEducateLevel eduLevel = (EEducateLevel)(j - 1);
					range = worksheet.Cells[ 3, 3 * j ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint maleNum = uint.Parse( cellContent );
					range = worksheet.Cells[ 3, 3 * j + 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint femaleNum = uint.Parse( cellContent );
					IndJointDis newMaleEduLvJointDis = new IndJointDis( EGender.Male, EAgeInterval.FiveToNine, EProvince.Other,
						ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
					eduLvMarginal.Add( newMaleEduLvJointDis, maleNum );
					IndJointDis newFemaleEduLvJointDis = new IndJointDis( EGender.Female, EAgeInterval.FiveToNine, EProvince.Other,
						ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.city, ERegistType.other );
					eduLvMarginal.Add( newFemaleEduLvJointDis, femaleNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region town
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0401b.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 2; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ 6 * i - 4, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EAgeInterval ageInter = (EAgeInterval)i;
					if ( (int)ageInter <= 12 )
					{
						for ( int j = 2; j <= iColCount; j++ )
						{
							range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
							cellContent = range.Text as string;
							cellContent = cellContent.Trim( );
							if ( cellContent == "" )
								break;
							EEducateLevel eduLevel = (EEducateLevel)(j - 1);
							range = worksheet.Cells[ 6 * i - 4, 3 * j ] as Excel.Range;
							cellContent = range.Text as string;
							cellContent = cellContent.Trim( );
							if ( cellContent == "" )
								cellContent = "0";
							uint maleNum = uint.Parse( cellContent );
							range = worksheet.Cells[ 6 * i - 4, 3 * j + 1 ] as Excel.Range;
							cellContent = range.Text as string;
							cellContent = cellContent.Trim( );
							if ( cellContent == "" )
								cellContent = "0";
							uint femaleNum = uint.Parse( cellContent );
							IndJointDis newMaleEduLvJointDis = new IndJointDis( EGender.Male, ageInter, EProvince.Other,
								ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
							eduLvMarginal.Add( newMaleEduLvJointDis, maleNum );
							IndJointDis newFemaleEduLvJointDis = new IndJointDis( EGender.Female, ageInter, EProvince.Other,
								ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
							eduLvMarginal.Add( newFemaleEduLvJointDis, femaleNum );
						}
					} else
					{
						for ( int j = 2; j <= iColCount; j++ )
						{
							range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
							cellContent = range.Text as string;
							cellContent = cellContent.Trim( );
							if ( cellContent == "" )
								break;
							EEducateLevel eduLevel = (EEducateLevel)(j - 1);
							range = worksheet.Cells[ 6 * i - 4, 3 * j ] as Excel.Range;
							cellContent = range.Text as string;
							cellContent = cellContent.Trim( );
							if ( cellContent == "" )
								cellContent = "0";
							uint maleNum = uint.Parse( cellContent );
							IndJointDis maleEduLv65To69 = new IndJointDis( EGender.Male, EAgeInterval.SixtyFiveToSixtyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
							eduLvMarginal.Add( maleEduLv65To69, maleNum / 8 );
							IndJointDis maleEduLv70To74 = new IndJointDis( EGender.Male, EAgeInterval.SeventyToSeventyFour, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
							eduLvMarginal.Add( maleEduLv70To74, maleNum / 8 );
							IndJointDis maleEduLv75To79 = new IndJointDis( EGender.Male, EAgeInterval.SeventyFiveToSeventyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
							eduLvMarginal.Add( maleEduLv75To79, maleNum / 8 );
							IndJointDis maleEduLv80To84 = new IndJointDis( EGender.Male, EAgeInterval.EightyToEightyFour, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
							eduLvMarginal.Add( maleEduLv80To84, maleNum / 8 );
							IndJointDis maleEduLv85To89 = new IndJointDis( EGender.Male, EAgeInterval.EightyFiveToEightyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
							eduLvMarginal.Add( maleEduLv85To89, maleNum / 8 );
							IndJointDis maleEduLv90To94 = new IndJointDis( EGender.Male, EAgeInterval.NinetyToNinetyFour, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
							eduLvMarginal.Add( maleEduLv90To94, maleNum / 8 );
							IndJointDis maleEduLv95To99 = new IndJointDis( EGender.Male, EAgeInterval.NinetyFiveToNinetyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
							eduLvMarginal.Add( maleEduLv95To99, maleNum / 8 );
							IndJointDis maleEduLv100above = new IndJointDis( EGender.Male, EAgeInterval.HundredAndAbove, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
							eduLvMarginal.Add( maleEduLv100above, maleNum / 8 );
							range = worksheet.Cells[ 6 * i - 4, 3 * j + 1 ] as Excel.Range;
							cellContent = range.Text as string;
							cellContent = cellContent.Trim( );
							if ( cellContent == "" )
								cellContent = "0";
							uint femaleNum = uint.Parse( cellContent );
							IndJointDis femaleEduLv65To69 = new IndJointDis( EGender.Female, EAgeInterval.SixtyFiveToSixtyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv65To69, femaleNum / 8 );
							IndJointDis femaleEduLv70To74 = new IndJointDis( EGender.Female, EAgeInterval.SeventyToSeventyFour, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv70To74, femaleNum / 8 );
							IndJointDis femaleEduLv75To79 = new IndJointDis( EGender.Female, EAgeInterval.SeventyFiveToSeventyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv75To79, femaleNum / 8 );
							IndJointDis femaleEduLv80To84 = new IndJointDis( EGender.Female, EAgeInterval.EightyToEightyFour, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv80To84, femaleNum / 8 );
							IndJointDis femaleEduLv85To89 = new IndJointDis( EGender.Female, EAgeInterval.EightyFiveToEightyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv85To89, femaleNum / 8 );
							IndJointDis femaleEduLv90To94 = new IndJointDis( EGender.Female, EAgeInterval.NinetyToNinetyFour, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv90To94, femaleNum / 8 );
							IndJointDis femaleEduLv95To99 = new IndJointDis( EGender.Female, EAgeInterval.NinetyFiveToNinetyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv95To99, femaleNum / 8 );
							IndJointDis femaleEduLv100above = new IndJointDis( EGender.Female, EAgeInterval.HundredAndAbove, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv100above, femaleNum / 8 );
						}
					}
				}
				//6-9 year old people:
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EEducateLevel eduLevel = (EEducateLevel)(j - 1);
					range = worksheet.Cells[ 3, 3 * j ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint maleNum = uint.Parse( cellContent );
					range = worksheet.Cells[ 3, 3 * j + 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint femaleNum = uint.Parse( cellContent );
					IndJointDis newMaleEduLvJointDis = new IndJointDis( EGender.Male, EAgeInterval.FiveToNine, EProvince.Other,
						ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
					eduLvMarginal.Add( newMaleEduLvJointDis, maleNum );
					IndJointDis newFemaleEduLvJointDis = new IndJointDis( EGender.Female, EAgeInterval.FiveToNine, EProvince.Other,
						ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.town, ERegistType.other );
					eduLvMarginal.Add( newFemaleEduLvJointDis, femaleNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region rural
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0401c.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 2; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ 6 * i - 4, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EAgeInterval ageInter = (EAgeInterval)i;
					if ( (int)ageInter <= 12 )
					{
						for ( int j = 2; j <= iColCount; j++ )
						{
							range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
							cellContent = range.Text as string;
							cellContent = cellContent.Trim( );
							if ( cellContent == "" )
								break;
							EEducateLevel eduLevel = (EEducateLevel)(j - 1);
							range = worksheet.Cells[ 6 * i - 4, 3 * j ] as Excel.Range;
							cellContent = range.Text as string;
							cellContent = cellContent.Trim( );
							if ( cellContent == "" )
								cellContent = "0";
							uint maleNum = uint.Parse( cellContent );
							range = worksheet.Cells[ 6 * i - 4, 3 * j + 1 ] as Excel.Range;
							cellContent = range.Text as string;
							cellContent = cellContent.Trim( );
							if ( cellContent == "" )
								cellContent = "0";
							uint femaleNum = uint.Parse( cellContent );
							IndJointDis newMaleEduLvJointDis = new IndJointDis( EGender.Male, ageInter, EProvince.Other,
								ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
							eduLvMarginal.Add( newMaleEduLvJointDis, maleNum );
							IndJointDis newFemaleEduLvJointDis = new IndJointDis( EGender.Female, ageInter, EProvince.Other,
								ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
							eduLvMarginal.Add( newFemaleEduLvJointDis, femaleNum );
						}
					} else
					{
						for ( int j = 2; j <= iColCount; j++ )
						{
							range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
							cellContent = range.Text as string;
							cellContent = cellContent.Trim( );
							if ( cellContent == "" )
								break;
							EEducateLevel eduLevel = (EEducateLevel)(j - 1);
							range = worksheet.Cells[ 6 * i - 4, 3 * j ] as Excel.Range;
							cellContent = range.Text as string;
							cellContent = cellContent.Trim( );
							if ( cellContent == "" )
								cellContent = "0";
							uint maleNum = uint.Parse( cellContent );
							IndJointDis maleEduLv65To69 = new IndJointDis( EGender.Male, EAgeInterval.SixtyFiveToSixtyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
							eduLvMarginal.Add( maleEduLv65To69, maleNum / 8 );
							IndJointDis maleEduLv70To74 = new IndJointDis( EGender.Male, EAgeInterval.SeventyToSeventyFour, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
							eduLvMarginal.Add( maleEduLv70To74, maleNum / 8 );
							IndJointDis maleEduLv75To79 = new IndJointDis( EGender.Male, EAgeInterval.SeventyFiveToSeventyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
							eduLvMarginal.Add( maleEduLv75To79, maleNum / 8 );
							IndJointDis maleEduLv80To84 = new IndJointDis( EGender.Male, EAgeInterval.EightyToEightyFour, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
							eduLvMarginal.Add( maleEduLv80To84, maleNum / 8 );
							IndJointDis maleEduLv85To89 = new IndJointDis( EGender.Male, EAgeInterval.EightyFiveToEightyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
							eduLvMarginal.Add( maleEduLv85To89, maleNum / 8 );
							IndJointDis maleEduLv90To94 = new IndJointDis( EGender.Male, EAgeInterval.NinetyToNinetyFour, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
							eduLvMarginal.Add( maleEduLv90To94, maleNum / 8 );
							IndJointDis maleEduLv95To99 = new IndJointDis( EGender.Male, EAgeInterval.NinetyFiveToNinetyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
							eduLvMarginal.Add( maleEduLv95To99, maleNum / 8 );
							IndJointDis maleEduLv100above = new IndJointDis( EGender.Male, EAgeInterval.HundredAndAbove, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
							eduLvMarginal.Add( maleEduLv100above, maleNum / 8 );
							range = worksheet.Cells[ 6 * i - 4, 3 * j + 1 ] as Excel.Range;
							cellContent = range.Text as string;
							cellContent = cellContent.Trim( );
							if ( cellContent == "" )
								cellContent = "0";
							uint femaleNum = uint.Parse( cellContent );
							IndJointDis femaleEduLv65To69 = new IndJointDis( EGender.Female, EAgeInterval.SixtyFiveToSixtyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv65To69, femaleNum / 8 );
							IndJointDis femaleEduLv70To74 = new IndJointDis( EGender.Female, EAgeInterval.SeventyToSeventyFour, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv70To74, femaleNum / 8 );
							IndJointDis femaleEduLv75To79 = new IndJointDis( EGender.Female, EAgeInterval.SeventyFiveToSeventyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv75To79, femaleNum / 8 );
							IndJointDis femaleEduLv80To84 = new IndJointDis( EGender.Female, EAgeInterval.EightyToEightyFour, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv80To84, femaleNum / 8 );
							IndJointDis femaleEduLv85To89 = new IndJointDis( EGender.Female, EAgeInterval.EightyFiveToEightyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv85To89, femaleNum / 8 );
							IndJointDis femaleEduLv90To94 = new IndJointDis( EGender.Female, EAgeInterval.NinetyToNinetyFour, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv90To94, femaleNum / 8 );
							IndJointDis femaleEduLv95To99 = new IndJointDis( EGender.Female, EAgeInterval.NinetyFiveToNinetyNine, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv95To99, femaleNum / 8 );
							IndJointDis femaleEduLv100above = new IndJointDis( EGender.Female, EAgeInterval.HundredAndAbove, EProvince.Other,
															ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
							eduLvMarginal.Add( femaleEduLv100above, femaleNum / 8 );
						}
					}
				}
				//6-9 year old people:
				for ( int j = 2; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EEducateLevel eduLevel = (EEducateLevel)(j - 1);
					range = worksheet.Cells[ 3, 3 * j ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint maleNum = uint.Parse( cellContent );
					range = worksheet.Cells[ 3, 3 * j + 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint femaleNum = uint.Parse( cellContent );
					IndJointDis newMaleEduLvJointDis = new IndJointDis( EGender.Male, EAgeInterval.FiveToNine, EProvince.Other,
						ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
					eduLvMarginal.Add( newMaleEduLvJointDis, maleNum );
					IndJointDis newFemaleEduLvJointDis = new IndJointDis( EGender.Female, EAgeInterval.FiveToNine, EProvince.Other,
						ERaceType.Other, EProvince.Other, eduLevel, EResidenceType.rural, ERegistType.other );
					eduLvMarginal.Add( newFemaleEduLvJointDis, femaleNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				//Residential Province*Educational Level partial joint distribution
				#region partial joint distribution
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0108.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					for ( int j = 1; j <= iColCount; j++ )
					{
						range = worksheet.Cells[ i, 3 * j + 2 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EEducateLevel eduLv = (EEducateLevel)j;
						range = worksheet.Cells[ i, 3 * j + 3 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint maleNum = uint.Parse( cellContent );
						range = worksheet.Cells[ i, 3 * j + 4 ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint femaleNum = uint.Parse( cellContent );
						IndJointDis newMaleInd = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour,
							resideProv, ERaceType.Other, EProvince.Other, eduLv, EResidenceType.rural, ERegistType.other );
						resideProvEduLvPartial.Add( newMaleInd, maleNum );
						IndJointDis newFemaleInd = new IndJointDis( EGender.Female, EAgeInterval.ZeroToFour,
							resideProv, ERaceType.Other, EProvince.Other, eduLv, EResidenceType.rural, ERegistType.other );
						resideProvEduLvPartial.Add( newFemaleInd, femaleNum );
					}
				}
				#endregion
			} catch ( Exception e )
			{
				throw new ApplicationException( e.Message );
			} finally
			{
				if ( workBook != null )
				{
					workBook.Close( false, objOpt, objOpt );
					System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
					workBook = null;
				}
				excelApp.Workbooks.Close( );
				excelApp.Quit( );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( excelApp );
				excelApp = null;
				GC.Collect( );
				GC.WaitForPendingFinalizers( );
			}
			List<IndJointDis> jointKeys = new List<IndJointDis>( );
			jointKeys.AddRange( jointDistribution.Keys );
			foreach ( IndJointDis parDis in jointKeys )
			{
				if ( jointDistribution[ parDis ] == 0 )
				{
					jointDistribution.Remove( parDis );
				}
			}
			foreach ( IndJointDis parDis in eduLvMarginal.Keys )
			{
				eduLevelSet.Add( parDis.EduLevel );
				if ( eduLevelSet.Count >= 10 )
					break;
			}
			jointKeys.Clear( );
			jointKeys = null;
			//Educational Level
			string eduLvConProDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, "EduLv" );
			MyDatabase eduLvConProDB = new MyDatabase( eduLvConProDBName );
			if ( Directory.Exists( eduLvConProDBName ) )
				Directory.Delete( eduLvConProDBName, true );
			eduLvConProDB.DBOpen( );
			foreach ( EGender gender in genderSet )
			{
				foreach ( EResidenceType resideType in residenceTypeSet )
				{
					foreach ( EAgeInterval age in ageSet )
					{
						Dictionary<EProvince, uint> resideProvConMarginal = new Dictionary<EProvince, uint>( );
						Dictionary<EEducateLevel, uint> eduLvConMarginal = new Dictionary<EEducateLevel, uint>( );
						if ( age != EAgeInterval.ZeroToFour )//0-4 year old people
						{
							foreach ( IndJointDis parDis in jointDistribution.Keys )
							{
								if ( parDis.Gender == gender && parDis.ResidenceType == resideType && parDis.Age == age )
								{
									if ( resideProvConMarginal.ContainsKey( parDis.ResideProvin ) )
									{
										resideProvConMarginal[ parDis.ResideProvin ] += jointDistribution[ parDis ];
									} else
									{
										resideProvConMarginal.Add( parDis.ResideProvin, jointDistribution[ parDis ] );
									}
								}
							}
							foreach ( IndJointDis parDis in eduLvMarginal.Keys )
							{
								if ( parDis.Gender == gender && parDis.ResidenceType == resideType && parDis.Age == age )
								{
									if ( eduLvConMarginal.ContainsKey( parDis.EduLevel ) )
									{
										eduLvConMarginal[ parDis.EduLevel ] += eduLvMarginal[ parDis ];
									} else
									{
										eduLvConMarginal.Add( parDis.EduLevel, eduLvMarginal[ parDis ] );
									}
								}
							}
							uint resideProvConSum = 0;
							foreach ( uint parVal in resideProvConMarginal.Values )
								resideProvConSum += parVal;
							uint eduLvConSum = 0;
							foreach ( uint parVal in eduLvConMarginal.Values )
								eduLvConSum += parVal;
							List<EProvince> resideProvKeys = new List<EProvince>( );
							resideProvKeys.AddRange( resideProvConMarginal.Keys );
							foreach ( EProvince resideProv in resideProvKeys )
							{
								resideProvConMarginal[ resideProv ] = (uint)(Math.Round( (double)eduLvConSum
														/ resideProvConSum * resideProvConMarginal[ resideProv ] ));
							}
							List<IndJointDis> keys = new List<IndJointDis>( );
							foreach ( IndJointDis parDis in resideProvEduLvPartial.Keys )
							{
								if ( parDis.Gender == gender )
									keys.Add( parDis );
							}
							//IPF
							uint error = uint.MaxValue;
							for ( int i = 0; i < 100; i++ )
							{
								foreach ( EProvince resideProv in resideProvSet )
								{
									uint resideProvSumNum = 0;
									foreach ( IndJointDis parDis in keys )
									{
										if ( parDis.ResideProvin == resideProv )
											resideProvSumNum += resideProvEduLvPartial[ parDis ];
									}
									foreach ( IndJointDis parDis in keys )
									{
										if ( resideProvEduLvPartial[ parDis ] == 0 )
											continue;
										if ( parDis.ResideProvin == resideProv )
										{
											if ( resideProvConMarginal.ContainsKey( resideProv ) )
											{
												uint indNum = (uint)(Math.Round( (double)resideProvEduLvPartial[ parDis ]
																			/ resideProvSumNum * resideProvConMarginal[ resideProv ] ));
												if ( indNum != 0 )
													resideProvEduLvPartial[ parDis ] = (uint)(Math.Round( (double)resideProvEduLvPartial[ parDis ]
																				/ resideProvSumNum * resideProvConMarginal[ resideProv ] ));
												else
													resideProvEduLvPartial[ parDis ] = 1;
											} else
												resideProvEduLvPartial[ parDis ] = 0;
										}
									}
								}
								foreach ( EEducateLevel eduLv in eduLevelSet )
								{
									uint eduLvSumNum = 0;
									foreach ( IndJointDis parDis in keys )
									{
										if ( parDis.EduLevel == eduLv )
											eduLvSumNum += resideProvEduLvPartial[ parDis ];
									}
									foreach ( IndJointDis parDis in keys )
									{
										if ( resideProvEduLvPartial[ parDis ] == 0 )
											continue;
										if ( parDis.EduLevel == eduLv )
										{
											if ( eduLvConMarginal.ContainsKey( eduLv ) )
											{
												uint indNum = (uint)(Math.Round( (double)resideProvEduLvPartial[ parDis ]
																					/ eduLvSumNum * eduLvConMarginal[ eduLv ] ));
												if ( indNum != 0 )
													resideProvEduLvPartial[ parDis ] = (uint)(Math.Round( (double)resideProvEduLvPartial[ parDis ]
																						/ eduLvSumNum * eduLvConMarginal[ eduLv ] ));
												else
													resideProvEduLvPartial[ parDis ] = 1;
											} else
												resideProvEduLvPartial[ parDis ] = 0;
										}
									}
								}
								error = ComputeL1Error( resideProvEduLvPartial, keys, resideProvConMarginal, eduLvConMarginal );
								if ( error < 100 )
									break;
							}
						}
						//compute (Gender*Ethnic Group*Residence Type*Age Interval)*Residential Province*Educational Level joint distribution
						foreach ( ERaceType race in raceSet )
						{
							uint genderRaceResideTypeAgeSum = 0;
							List<IndJointDis> jointDisKeys = new List<IndJointDis>( );
							foreach ( IndJointDis parDis in jointDistribution.Keys )
							{
								if ( parDis.Gender == gender && parDis.Race == race && parDis.ResidenceType == resideType && parDis.Age == age )
								{
									genderRaceResideTypeAgeSum += jointDistribution[ parDis ];
									jointDisKeys.Add( parDis );
								}
							}
							if ( age == EAgeInterval.ZeroToFour )//0-4 year old
							{
								foreach ( IndJointDis parDis in jointDisKeys )
								{
									uint origIndNum = jointDistribution[ parDis ];
									jointDistribution.Remove( parDis );
									IndJointDis newJointDis = new IndJointDis( parDis.Gender, parDis.Age, parDis.ResideProvin,
										parDis.Race, parDis.RegistProvin, EEducateLevel.infant, parDis.ResidenceType, parDis.RegistType );
									jointDistribution.Add( newJointDis, origIndNum );
									//conditional probability
									if ( origIndNum > 0 )
									{
										string keyStr = newJointDis.Gender.ToString( );
										keyStr += "-" + newJointDis.Race.ToString( );
										keyStr += "-" + newJointDis.ResidenceType.ToString( );
										keyStr += "-" + newJointDis.ResideProvin.ToString( );
										keyStr += "-" + newJointDis.Age.ToString( );
										keyStr += "-" + newJointDis.EduLevel.ToString( );
										string valStr = "1";
										eduLvConProDB.WriteAsyn( keyStr, valStr );
									}
									if ( !eduLevelSet.Contains( EEducateLevel.infant ) )
										eduLevelSet.Add( EEducateLevel.infant );
								}
								continue;
							}
							uint resideProvEduLvSum = 0;
							List<IndJointDis> keys = new List<IndJointDis>( );
							foreach ( IndJointDis parDis in resideProvEduLvPartial.Keys )
							{
								if ( parDis.Gender == gender )
									keys.Add( parDis );
							}
							foreach ( IndJointDis parDis in keys )
							{
								resideProvEduLvSum += resideProvEduLvPartial[ parDis ];
							}
							foreach ( IndJointDis parDis in jointDisKeys )
							{
								uint origIndNum = jointDistribution[ parDis ];
								jointDistribution.Remove( parDis );
								Dictionary<EEducateLevel, uint> conFreq = new Dictionary<EEducateLevel, uint>( );
								uint sumNum = 0;
								foreach ( EEducateLevel eduLv in eduLevelSet )
								{
									IndJointDis newJointDis = new IndJointDis( parDis.Gender, parDis.Age,
										parDis.ResideProvin, parDis.Race, parDis.RegistProvin, eduLv, parDis.ResidenceType, parDis.RegistType );
									uint indNum = 0;
									foreach ( IndJointDis partialDis in keys )
									{
										if ( partialDis.ResideProvin == parDis.ResideProvin && partialDis.EduLevel == eduLv )
										{
											if ( resideProvEduLvSum != 0 )
												indNum = (uint)(Math.Round( (double)resideProvEduLvPartial[ partialDis ]
																		/ resideProvEduLvSum * genderRaceResideTypeAgeSum ));
											else
												indNum = 1;
											break;
										}
									}
									jointDistribution.Add( newJointDis, indNum );
									conFreq.Add( eduLv, indNum );
									sumNum += indNum;
								}
								//conditional probability
								foreach ( EEducateLevel eduLv in conFreq.Keys )
								{
									string keyStr = parDis.Gender.ToString( );
									keyStr += "-" + parDis.Race.ToString( );
									keyStr += "-" + parDis.ResidenceType.ToString( );
									keyStr += "-" + parDis.ResideProvin.ToString( );
									keyStr += "-" + parDis.Age.ToString( );
									keyStr += "-" + eduLv.ToString( );
									if ( sumNum > 0 )
									{
										string valStr = ((double)conFreq[ eduLv ] / sumNum).ToString( );
										eduLvConProDB.WriteAsyn( keyStr, valStr );
									}
								}
							}
						}
					}
				}
			}
			eduLvConProDB.DBDispose( );
		}

		/// <summary>
		/// expand Registration Type
		/// </summary>
		private void ExtendRegistType( )
		{
			//Gender*Residential Province*Registration Type partial joint distribution
			Dictionary<IndJointDis, uint> genderResideProvRegistTypePartial = new Dictionary<IndJointDis, uint>( );
			Excel.Application excelApp = new Excel.Application( );
			object objOpt = System.Reflection.Missing.Value;
			Excel.Workbook workBook = null;
			Excel.Sheets sheets;
			Excel.Worksheet worksheet;
			Excel.Range range;
			try
			{
				int iRowCount = 0;
				int iColCount = 0;
				string cellContent = null;
				#region people with Registration
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0105.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					range = worksheet.Cells[ i, 6 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint ruralMaleNum = uint.Parse( cellContent );
					IndJointDis ruralMale = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour, resideProv,
						ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.rural );
					genderResideProvRegistTypePartial.Add( ruralMale, ruralMaleNum );
					range = worksheet.Cells[ i, 7 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint ruralFemaleNum = uint.Parse( cellContent );
					IndJointDis ruralFemale = new IndJointDis( EGender.Female, EAgeInterval.ZeroToFour, resideProv,
						ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.rural );
					genderResideProvRegistTypePartial.Add( ruralFemale, ruralFemaleNum );
					range = worksheet.Cells[ i, 9 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint urbanMaleNum = uint.Parse( cellContent );
					IndJointDis urbanMale = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour, resideProv,
						ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.urban );
					genderResideProvRegistTypePartial.Add( urbanMale, urbanMaleNum );
					range = worksheet.Cells[ i, 10 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint urbanFemaleNum = uint.Parse( cellContent );
					IndJointDis urbanFemale = new IndJointDis( EGender.Female, EAgeInterval.ZeroToFour, resideProv,
						ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.urban );
					genderResideProvRegistTypePartial.Add( urbanFemale, urbanFemaleNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region people without Registration
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0102.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					range = worksheet.Cells[ i, 15 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint unDeterMaleNum = uint.Parse( cellContent );
					range = worksheet.Cells[ i, 18 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint noRegMaleNum = uint.Parse( cellContent );
					IndJointDis noRegMale = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour, resideProv,
							ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.other );
					genderResideProvRegistTypePartial.Add( noRegMale, unDeterMaleNum + noRegMaleNum );
					range = worksheet.Cells[ i, 16 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint unDeterFemaleNum = uint.Parse( cellContent );
					range = worksheet.Cells[ i, 19 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint noRegFemaleNum = uint.Parse( cellContent );
					IndJointDis noRegFemale = new IndJointDis( EGender.Female, EAgeInterval.ZeroToFour, resideProv,
							ERaceType.Other, EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.other );
					genderResideProvRegistTypePartial.Add( noRegFemale, unDeterFemaleNum + noRegFemaleNum );
				}
				#endregion
			} catch ( Exception e )
			{
				throw new ApplicationException( e.Message );
			} finally
			{
				if ( workBook != null )
				{
					workBook.Close( false, objOpt, objOpt );
					System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
					workBook = null;
				}
				excelApp.Workbooks.Close( );
				excelApp.Quit( );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( excelApp );
				excelApp = null;
				GC.Collect( );
				GC.WaitForPendingFinalizers( );
			}
			string registTypeConProDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, "RegistType" );
			MyDatabase registTypeConProDB = new MyDatabase( registTypeConProDBName );
			if ( Directory.Exists( registTypeConProDBName ) )
				Directory.Delete( registTypeConProDBName, true );
			registTypeConProDB.DBOpen( );
			foreach ( EGender gender in genderSet )
			{
				foreach ( EProvince resideProv in resideProvSet )
				{
					Dictionary<ERegistType, uint> registTypeConMarginal = new Dictionary<ERegistType, uint>( );
					foreach ( IndJointDis parDis in genderResideProvRegistTypePartial.Keys )
					{
						if ( parDis.Gender == gender && parDis.ResideProvin == resideProv )
						{
							if ( registTypeConMarginal.ContainsKey( parDis.RegistType ) )
								registTypeConMarginal[ parDis.RegistType ] += genderResideProvRegistTypePartial[ parDis ];
							else
								registTypeConMarginal.Add( parDis.RegistType, genderResideProvRegistTypePartial[ parDis ] );
						}
					}
					uint registTypeSumNum = 0;
					foreach ( uint parVal in registTypeConMarginal.Values )
						registTypeSumNum += parVal;
					List<IndJointDis> keys = new List<IndJointDis>( );
					keys.AddRange( jointDistribution.Keys );
					foreach ( IndJointDis parDis in keys )
					{
						if ( parDis.Gender == gender && parDis.ResideProvin == resideProv )
						{
							uint indNum = jointDistribution[ parDis ];
							jointDistribution.Remove( parDis );
							Dictionary<ERegistType, uint> conFreq = new Dictionary<ERegistType, uint>( );
							uint sumNum = 0;
							foreach ( ERegistType registType in registTypeConMarginal.Keys )
							{
								IndJointDis newInd = new IndJointDis( parDis.Gender, parDis.Age, parDis.ResideProvin,
										parDis.Race, parDis.RegistProvin, parDis.EduLevel, parDis.ResidenceType, registType );
								uint newIndNum = (uint)Math.Round( (double)registTypeConMarginal[ registType ] / registTypeSumNum * indNum );
								if ( newIndNum > 0 )
								{
									jointDistribution.Add( newInd, newIndNum );
									registTypeSet.Add( registType );
									conFreq.Add( registType, newIndNum );
									sumNum += newIndNum;
								}
							}
							//conditional probability
							foreach ( ERegistType registType in conFreq.Keys )
							{
								string keyStr = parDis.Gender.ToString( );
								keyStr += "-" + parDis.Race.ToString( );
								keyStr += "-" + parDis.ResidenceType.ToString( );
								keyStr += "-" + parDis.ResideProvin.ToString( );
								keyStr += "-" + parDis.Age.ToString( );
								keyStr += "-" + parDis.EduLevel.ToString( );
								keyStr += "-" + registType.ToString( );
								if ( sumNum > 0 )
								{
									string valStr = ((double)conFreq[ registType ] / sumNum).ToString( );
									registTypeConProDB.WriteAsyn( keyStr, valStr );
								}
							}
						}
					}
				}
			}
			registTypeConProDB.DBDispose( );
		}

		/// <summary>
		/// expand Registration Province
		/// </summary>
		private void ExtendRegistProv( )
		{
			//Residence Type*Residential Province*Registration Province partial joint distribution
			Dictionary<IndJointDis, uint> resideTypeResideProvRegistProvPartial = new Dictionary<IndJointDis, uint>( );
			//people with Registration
			Dictionary<EProvince, uint> regNum = new Dictionary<EProvince, uint>( );
			Excel.Application excelApp = new Excel.Application( );
			object objOpt = System.Reflection.Missing.Value;
			Excel.Workbook workBook = null;
			Excel.Sheets sheets;
			Excel.Worksheet worksheet;
			Excel.Range range;
			try
			{
				int iRowCount = 0;
				int iColCount = 0;
				string cellContent = null;
				#region local people with Registration
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0102.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					range = worksheet.Cells[ i, 2 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint totalNum = uint.Parse( cellContent );
					range = worksheet.Cells[ i, 14 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint undeterNum = uint.Parse( cellContent );
					range = worksheet.Cells[ i, 17 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					uint noRegNum = uint.Parse( cellContent );
					if ( totalNum <= undeterNum + noRegNum )
						throw new ApplicationException( "totalNum <= undeterNum + noRegNum" );
					regNum.Add( resideProv, totalNum - undeterNum - noRegNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region immigrants with Registration
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0702a.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					Dictionary<EProvince, uint> otherRegistProvNum = new Dictionary<EProvince, uint>( );
					for ( int j = 3; j <= iColCount; j++ )
					{
						if ( i == j )
							continue;
						range = worksheet.Cells[ 1, j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EProvince registProv = AttributeCheck.CheckProvince( cellContent );
						range = worksheet.Cells[ i, j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint indNum = uint.Parse( cellContent );
						otherRegistProvNum.Add( registProv, indNum );
					}
					foreach ( EProvince parProv in otherRegistProvNum.Keys )
					{
						IndJointDis newRegistProvInd = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour, resideProv,
									ERaceType.Other, parProv, EEducateLevel.infant, EResidenceType.city, ERegistType.other );
						resideTypeResideProvRegistProvPartial.Add( newRegistProvInd, otherRegistProvNum[ parProv ] );
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0702b.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					Dictionary<EProvince, uint> otherRegistProvNum = new Dictionary<EProvince, uint>( );
					for ( int j = 3; j <= iColCount; j++ )
					{
						if ( i == j )
							continue;
						range = worksheet.Cells[ 1, j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EProvince registProv = AttributeCheck.CheckProvince( cellContent );
						range = worksheet.Cells[ i, j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint indNum = uint.Parse( cellContent );
						otherRegistProvNum.Add( registProv, indNum );
					}
					foreach ( EProvince parProv in otherRegistProvNum.Keys )
					{
						IndJointDis newRegistProvInd = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour, resideProv,
									ERaceType.Other, parProv, EEducateLevel.infant, EResidenceType.town, ERegistType.other );
						resideTypeResideProvRegistProvPartial.Add( newRegistProvInd, otherRegistProvNum[ parProv ] );
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				workBook = excelApp.Workbooks.Open( Path.Combine( InputPara.statDir, "t0702c.xls" ), objOpt, objOpt,
					objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince resideProv = AttributeCheck.CheckProvince( cellContent );
					Dictionary<EProvince, uint> otherRegistProvNum = new Dictionary<EProvince, uint>( );
					for ( int j = 3; j <= iColCount; j++ )
					{
						if ( i == j )
							continue;
						range = worksheet.Cells[ 1, j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							break;
						EProvince registProv = AttributeCheck.CheckProvince( cellContent );
						range = worksheet.Cells[ i, j ] as Excel.Range;
						cellContent = range.Text as string;
						cellContent = cellContent.Trim( );
						if ( cellContent == "" )
							cellContent = "0";
						uint indNum = uint.Parse( cellContent );
						otherRegistProvNum.Add( registProv, indNum );
					}
					foreach ( EProvince parProv in otherRegistProvNum.Keys )
					{
						IndJointDis newRegistProvInd = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour, resideProv,
									ERaceType.Other, parProv, EEducateLevel.infant, EResidenceType.rural, ERegistType.other );
						resideTypeResideProvRegistProvPartial.Add( newRegistProvInd, otherRegistProvNum[ parProv ] );
					}
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
			} catch ( Exception e )
			{
				throw new ApplicationException( e.Message );
			} finally
			{
				if ( workBook != null )
				{
					workBook.Close( false, objOpt, objOpt );
					System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
					workBook = null;
				}
				excelApp.Workbooks.Close( );
				excelApp.Quit( );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( excelApp );
				excelApp = null;
				GC.Collect( );
				GC.WaitForPendingFinalizers( );
			}
			foreach ( EProvince prov in regNum.Keys )
			{
				registProvSet.Add( prov );
			}
			registProvSet.Add( EProvince.Other );
			//immigrants by Residential Province
			Dictionary<EProvince, uint> immigrantByProv = new Dictionary<EProvince, uint>( );
			foreach ( IndJointDis parDis in resideTypeResideProvRegistProvPartial.Keys )
			{
				if ( immigrantByProv.ContainsKey( parDis.ResideProvin ) )
					immigrantByProv[ parDis.ResideProvin ] += resideTypeResideProvRegistProvPartial[ parDis ];
				else
					immigrantByProv.Add( parDis.ResideProvin, resideTypeResideProvRegistProvPartial[ parDis ] );
			}
			//immigrants by Residential Province*Residence Type
			Dictionary<IndJointDis, uint> immigrantByResideTypeAndProv = new Dictionary<IndJointDis, uint>( );
			foreach ( IndJointDis parDis in resideTypeResideProvRegistProvPartial.Keys )
			{
				List<IndJointDis> immigrantKeys = new List<IndJointDis>( );
				immigrantKeys.AddRange( immigrantByResideTypeAndProv.Keys );
				bool hasKey = false;
				foreach ( IndJointDis resTypeProvDis in immigrantKeys )
				{
					if ( resTypeProvDis.ResidenceType == parDis.ResidenceType && resTypeProvDis.ResideProvin == parDis.ResideProvin )
					{
						immigrantByResideTypeAndProv[ resTypeProvDis ] += resideTypeResideProvRegistProvPartial[ parDis ];
						hasKey = true;
						break;
					}
				}
				if ( !hasKey )
				{
					IndJointDis newJointDis = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour, parDis.ResideProvin,
						ERaceType.Other, EProvince.Other, EEducateLevel.infant, parDis.ResidenceType, ERegistType.other );
					immigrantByResideTypeAndProv.Add( newJointDis, resideTypeResideProvRegistProvPartial[ parDis ] );
				}
			}
			string registProvConProDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, "RegistProv" );
			MyDatabase registProvConProDB = new MyDatabase( registProvConProDBName );
			if ( Directory.Exists( registProvConProDBName ) )
				Directory.Delete( registProvConProDBName, true );
			registProvConProDB.DBOpen( );
			foreach ( IndJointDis parJointDis in jointDistribution.Keys )
			{
				if ( jointDistribution[ parJointDis ] == 0 )
					continue;
				if ( parJointDis.RegistType == ERegistType.other )//people without Registration
				{
					foreach ( EProvince registProv in registProvSet )
					{
						string keyStr = parJointDis.Gender.ToString( );
						keyStr += "-" + parJointDis.Race.ToString( );
						keyStr += "-" + parJointDis.ResidenceType.ToString( );
						keyStr += "-" + parJointDis.ResideProvin.ToString( );
						keyStr += "-" + parJointDis.Age.ToString( );
						keyStr += "-" + parJointDis.EduLevel.ToString( );
						keyStr += "-" + parJointDis.RegistType.ToString( );
						keyStr += "-" + registProv.ToString( );
						string valStr = "0";
						if ( registProv == EProvince.Other )
							valStr = "1";
						registProvConProDB.WriteAsyn( keyStr, valStr );
					}
					continue;
				}
				EResidenceType resideType = parJointDis.ResidenceType;
				EProvince resideProv = parJointDis.ResideProvin;
				uint origNum = jointDistribution[ parJointDis ];
				double otherProvRatio = (double)immigrantByProv[ resideProv ] / regNum[ resideProv ];
				uint sumNumByResideTypeAndProv = 0;
				foreach ( IndJointDis parDis in immigrantByResideTypeAndProv.Keys )
				{
					if ( parDis.ResidenceType == resideType && parDis.ResideProvin == resideProv )
					{
						sumNumByResideTypeAndProv = immigrantByResideTypeAndProv[ parDis ];
						break;
					}
				}
				uint otherProvTotal = 0;
				foreach ( IndJointDis parDis in resideTypeResideProvRegistProvPartial.Keys )
				{
					if ( parDis.ResidenceType == resideType && parDis.ResideProvin == resideProv )
					{
						double parOtherProvRatio = (double)resideTypeResideProvRegistProvPartial[ parDis ] / sumNumByResideTypeAndProv;
						uint otherIndNum = (uint)Math.Round( parOtherProvRatio * otherProvRatio * origNum );
						otherProvTotal += otherIndNum;
						string keyStr = parJointDis.Gender.ToString( );
						keyStr += "-" + parJointDis.Race.ToString( );
						keyStr += "-" + parJointDis.ResidenceType.ToString( );
						keyStr += "-" + parJointDis.ResideProvin.ToString( );
						keyStr += "-" + parJointDis.Age.ToString( );
						keyStr += "-" + parJointDis.EduLevel.ToString( );
						keyStr += "-" + parJointDis.RegistType.ToString( );
						keyStr += "-" + parDis.RegistProvin.ToString( );
						string valStr = ((double)otherIndNum / origNum).ToString( );
						registProvConProDB.WriteAsyn( keyStr, valStr );
					}
				}
				uint nativeIndNum = origNum - otherProvTotal;
				string nativeKeyStr = parJointDis.Gender.ToString( );
				nativeKeyStr += "-" + parJointDis.Race.ToString( );
				nativeKeyStr += "-" + parJointDis.ResidenceType.ToString( );
				nativeKeyStr += "-" + parJointDis.ResideProvin.ToString( );
				nativeKeyStr += "-" + parJointDis.Age.ToString( );
				nativeKeyStr += "-" + parJointDis.EduLevel.ToString( );
				nativeKeyStr += "-" + parJointDis.RegistType.ToString( );
				nativeKeyStr += "-" + resideProv.ToString( );
				string nativeValueStr = ((double)nativeIndNum / origNum).ToString( );
				registProvConProDB.WriteAsyn( nativeKeyStr, nativeValueStr );
			}
			registProvConProDB.DBDispose( );
		}

		/// <summary>
		/// Monte Carlo allocation
		/// </summary>
		private void Allocation( )
		{
			Dictionary<string, double> genderAlloProb = new Dictionary<string, double>( );
			Dictionary<string, double> raceAlloProb = new Dictionary<string, double>( );
			Dictionary<string, double> resideTypeAlloProb = new Dictionary<string, double>( );
			Dictionary<string, double> resideProvAlloProb = new Dictionary<string, double>( );
			Dictionary<string, double> ageAlloProb = new Dictionary<string, double>( );
			Dictionary<string, double> eduLvAlloProb = new Dictionary<string, double>( );
			Dictionary<string, double> registTypeAlloProb = new Dictionary<string, double>( );
			Dictionary<string, double> registProvAlloProb = new Dictionary<string, double>( );
			#region read conditional distributions
			genderSet.Add( EGender.Male );
			genderSet.Add( EGender.Female );
			for ( int i = 1; i <= 58; i++ )
				raceSet.Add( (ERaceType)i );
			residenceTypeSet.Add( EResidenceType.city );
			residenceTypeSet.Add( EResidenceType.town );
			residenceTypeSet.Add( EResidenceType.rural );
			for ( int i = 11; i <= 15; i++ )
			{
				resideProvSet.Add( (EProvince)i );
				registProvSet.Add( (EProvince)i );
			}
			for ( int i = 21; i <= 23; i++ )
			{
				resideProvSet.Add( (EProvince)i );
				registProvSet.Add( (EProvince)i );
			}
			for ( int i = 31; i <= 37; i++ )
			{
				resideProvSet.Add( (EProvince)i );
				registProvSet.Add( (EProvince)i );
			}
			for ( int i = 41; i <= 46; i++ )
			{
				resideProvSet.Add( (EProvince)i );
				registProvSet.Add( (EProvince)i );
			}
			for ( int i = 50; i <= 54; i++ )
			{
				resideProvSet.Add( (EProvince)i );
				registProvSet.Add( (EProvince)i );
			}
			for ( int i = 61; i <= 65; i++ )
			{
				resideProvSet.Add( (EProvince)i );
				registProvSet.Add( (EProvince)i );
			}
			registProvSet.Add( EProvince.Other );
			for ( int i = 0; i <= 20; i++ )
				ageSet.Add( (EAgeInterval)i );
			for ( int i = 0; i <= 9; i++ )
				eduLevelSet.Add( (EEducateLevel)i );
			registTypeSet.Add( ERegistType.urban );
			registTypeSet.Add( ERegistType.rural );
			registTypeSet.Add( ERegistType.other );
			string genderConProDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, "Gender" );
			if ( !Directory.Exists( genderConProDBName ) )
				throw new ApplicationException( "Gender Conditional Prob not exist!!" );
			MyDatabase genderConProDB = new MyDatabase( genderConProDBName );
			genderConProDB.DBOpen( );
			DBIterator dbIter = genderConProDB.GetIterator( );
			for ( dbIter.SeekToFirst( ); dbIter.Valid( ); dbIter.Next( ) )
			{
				string keyStr = dbIter.Key( ).ToString( );
				string valueStr = dbIter.Value( ).ToString( );
				double prob = double.Parse( valueStr );
				if ( prob > 0 )
					genderAlloProb.Add( keyStr, prob );
			}
			dbIter.Dispose( );
			genderConProDB.DBDispose( );
			string raceConProDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, "Race" );
			if ( !Directory.Exists( raceConProDBName ) )
				throw new ApplicationException( "Race Conditional Prob not exist!!" );
			MyDatabase raceConProDB = new MyDatabase( raceConProDBName );
			raceConProDB.DBOpen( );
			dbIter = raceConProDB.GetIterator( );
			for ( dbIter.SeekToFirst( ); dbIter.Valid( ); dbIter.Next( ) )
			{
				string keyStr = dbIter.Key( ).ToString( );
				string valueStr = dbIter.Value( ).ToString( );
				double prob = double.Parse( valueStr );
				if ( prob > 0 )
					raceAlloProb.Add( keyStr, prob );
			}
			dbIter.Dispose( );
			raceConProDB.DBDispose( );
			string resideTypeConProDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, "ResideType" );
			if ( !Directory.Exists( resideTypeConProDBName ) )
				throw new ApplicationException( "ResideType Conditional Prob not exist!!" );
			MyDatabase resideTypeConProDB = new MyDatabase( resideTypeConProDBName );
			resideTypeConProDB.DBOpen( );
			dbIter = resideTypeConProDB.GetIterator( );
			for ( dbIter.SeekToFirst( ); dbIter.Valid( ); dbIter.Next( ) )
			{
				string keyStr = dbIter.Key( ).ToString( );
				string valueStr = dbIter.Value( ).ToString( );
				double prob = double.Parse( valueStr );
				if ( prob > 0 )
					resideTypeAlloProb.Add( keyStr, prob );
			}
			dbIter.Dispose( );
			resideTypeConProDB.DBDispose( );
			string resideProvConProDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, "ResideProv" );
			if ( !Directory.Exists( resideProvConProDBName ) )
				throw new ApplicationException( "ResideProv Conditional Prob not exist!!" );
			MyDatabase resideProvConProDB = new MyDatabase( resideProvConProDBName );
			resideProvConProDB.DBOpen( );
			dbIter = resideProvConProDB.GetIterator( );
			for ( dbIter.SeekToFirst( ); dbIter.Valid( ); dbIter.Next( ) )
			{
				string keyStr = dbIter.Key( ).ToString( );
				string valueStr = dbIter.Value( ).ToString( );
				double prob = double.Parse( valueStr );
				if ( prob > 0 )
					resideProvAlloProb.Add( keyStr, prob );
			}
			dbIter.Dispose( );
			resideProvConProDB.DBDispose( );
			string ageConProDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, "Age" );
			if ( !Directory.Exists( ageConProDBName ) )
				throw new ApplicationException( "Age Conditional Prob not exist!!" );
			MyDatabase ageConProDB = new MyDatabase( ageConProDBName );
			ageConProDB.DBOpen( );
			dbIter = ageConProDB.GetIterator( );
			for ( dbIter.SeekToFirst( ); dbIter.Valid( ); dbIter.Next( ) )
			{
				string keyStr = dbIter.Key( ).ToString( );
				string valueStr = dbIter.Value( ).ToString( );
				double prob = double.Parse( valueStr );
				if ( prob > 0 )
					ageAlloProb.Add( keyStr, prob );
			}
			dbIter.Dispose( );
			ageConProDB.DBDispose( );
			string eduLvConProDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, "EduLv" );
			if ( !Directory.Exists( eduLvConProDBName ) )
				throw new ApplicationException( "EduLv Conditional Prob not exist!!" );
			MyDatabase eduLvConProDB = new MyDatabase( eduLvConProDBName );
			eduLvConProDB.DBOpen( );
			dbIter = eduLvConProDB.GetIterator( );
			for ( dbIter.SeekToFirst( ); dbIter.Valid( ); dbIter.Next( ) )
			{
				string keyStr = dbIter.Key( ).ToString( );
				string valueStr = dbIter.Value( ).ToString( );
				double prob = double.Parse( valueStr );
				if ( prob > 0 )
					eduLvAlloProb.Add( keyStr, prob );
			}
			dbIter.Dispose( );
			eduLvConProDB.DBDispose( );
			string registTypeConProDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, "RegistType" );
			if ( !Directory.Exists( registTypeConProDBName ) )
				throw new ApplicationException( "RegistType Conditional Prob not exist!!" );
			MyDatabase registTypeConProDB = new MyDatabase( registTypeConProDBName );
			registTypeConProDB.DBOpen( );
			dbIter = registTypeConProDB.GetIterator( );
			for ( dbIter.SeekToFirst( ); dbIter.Valid( ); dbIter.Next( ) )
			{
				string keyStr = dbIter.Key( ).ToString( );
				string valueStr = dbIter.Value( ).ToString( );
				double prob = double.Parse( valueStr );
				if ( prob > 0 )
					registTypeAlloProb.Add( keyStr, prob );
			}
			dbIter.Dispose( );
			registTypeConProDB.DBDispose( );
			string registProvConProDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, "RegistProv" );
			if ( !Directory.Exists( registProvConProDBName ) )
				throw new ApplicationException( "RegistProv Conditional Prob not exist!!" );
			MyDatabase registProvConProDB = new MyDatabase( registProvConProDBName );
			registProvConProDB.DBOpen( );
			dbIter = registProvConProDB.GetIterator( );
			for ( dbIter.SeekToFirst( ); dbIter.Valid( ); dbIter.Next( ) )
			{
				string keyStr = dbIter.Key( ).ToString( );
				string valueStr = dbIter.Value( ).ToString( );
				double prob = double.Parse( valueStr );
				if ( prob > 0 )
					registProvAlloProb.Add( keyStr, prob );
			}
			dbIter.Dispose( );
			registProvConProDB.DBDispose( );
			#endregion

			string populationDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, InputPara.popDBName );
			MyDatabase populationDB = new MyDatabase( populationDBName );
			if ( Directory.Exists( populationDBName ) )
				Directory.Delete( populationDBName, true );
			populationDB.DBOpen( );
			Random rand = new Random( );
			uint popSize = (uint)(InputPara.totalPopulation * InputPara.popSizeRatio);//synthetic population scale
			for ( uint agentID = 0; agentID < popSize; )
			{
				IndJointDis seed = new IndJointDis( EGender.Male, EAgeInterval.ZeroToFour, EProvince.Other, ERaceType.Other,
					EProvince.Other, EEducateLevel.infant, EResidenceType.rural, ERegistType.other );
				#region allocation
				double ratio = 0;
				//Gender
				{
					ratio = rand.NextDouble( );
					string keyStr = EGender.Male.ToString( );
					double maleProb = genderAlloProb[ keyStr ];
					if ( ratio <= maleProb )
						seed.Gender = EGender.Male;
					else
						seed.Gender = EGender.Female;
				}
				string deterKeyPart = seed.Gender.ToString( );
				//Ethnic Group
				{
					ERaceType[ ] raceTypeKeys = new ERaceType[ raceSet.Count ];
					double[ ] race = new double[ raceSet.Count ];
					int index = 0;
					foreach ( ERaceType raceType in raceSet )
					{
						string keyStr = deterKeyPart + "-" + raceType.ToString( );
						double probVal = 0;
						if ( raceAlloProb.ContainsKey( keyStr ) )
							probVal = raceAlloProb[ keyStr ];
						raceTypeKeys[ index ] = raceType;
						race[ index ] = probVal;
						index++;
					}
					ratio = rand.NextDouble( );
					double sumRatio = 0;
					for ( int i = 0; i < race.Length; i++ )
					{
						sumRatio += race[ i ];
						if ( ratio <= sumRatio )
						{
							seed.Race = raceTypeKeys[ i ];
							break;
						}
					}
				}
				deterKeyPart += "-" + seed.Race.ToString( );
				//Residence Type
				{
					double resideCity = 0;
					double resideTown = 0;
					double resideRural = 0;
					foreach ( EResidenceType resideType in residenceTypeSet )
					{
						string keyStr = deterKeyPart + "-" + resideType.ToString( );
						double probVal = 0;
						if ( resideTypeAlloProb.ContainsKey( keyStr ) )
							probVal = resideTypeAlloProb[ keyStr ];
						if ( resideType == EResidenceType.city )
							resideCity = probVal;
						else if ( resideType == EResidenceType.town )
							resideTown = probVal;
						else if ( resideType == EResidenceType.rural )
							resideRural = probVal;
					}
					ratio = rand.NextDouble( );
					if ( ratio <= resideCity )
						seed.ResidenceType = EResidenceType.city;
					else if ( ratio <= resideCity + resideTown )
						seed.ResidenceType = EResidenceType.town;
					else
						seed.ResidenceType = EResidenceType.rural;
				}
				deterKeyPart += "-" + seed.ResidenceType.ToString( );
				//Residential Province
				{
					EProvince[ ] resideProvKeys = new EProvince[ resideProvSet.Count ];
					double[ ] resideProvAllocateProb = new double[ resideProvSet.Count ];
					int index = 0;
					foreach ( EProvince prov in resideProvSet )
					{
						string keyStr = deterKeyPart + "-" + prov.ToString( );
						double probVal = 0;
						if ( resideProvAlloProb.ContainsKey( keyStr ) )
							probVal = resideProvAlloProb[ keyStr ];
						resideProvKeys[ index ] = prov;
						resideProvAllocateProb[ index ] = probVal;
						index++;
					}
					ratio = rand.NextDouble( );
					double sumRatio = 0;
					for ( int i = 0; i < resideProvAllocateProb.Length; i++ )
					{
						sumRatio += resideProvAllocateProb[ i ];
						if ( ratio <= sumRatio )
						{
							seed.ResideProvin = resideProvKeys[ i ];
							break;
						}
					}
				}
				deterKeyPart += "-" + seed.ResideProvin.ToString( );
				//Age Interval
				{
					double[ ] ageProb = new double[ 21 ];
					foreach ( EAgeInterval age in ageSet )
					{
						string keyStr = deterKeyPart + "-" + age.ToString( );
						double probVal = 0;
						if ( ageAlloProb.ContainsKey( keyStr ) )
							probVal = ageAlloProb[ keyStr ];
						ageProb[ (int)age ] = probVal;
					}
					ratio = rand.NextDouble( );
					double sumRatio = 0;
					for ( int i = 0; i < ageProb.Length; i++ )
					{
						sumRatio += ageProb[ i ];
						if ( ratio <= sumRatio )
						{
							seed.Age = (EAgeInterval)i;
							break;
						}
					}
				}
				deterKeyPart += "-" + seed.Age.ToString( );
				//Educational Level
				{
					double[ ] eduLvProb = new double[ eduLevelSet.Count ];
					foreach ( EEducateLevel eduLv in eduLevelSet )
					{
						string keyStr = deterKeyPart + "-" + eduLv.ToString( );
						double probVal = 0;
						if ( eduLvAlloProb.ContainsKey( keyStr ) )
							probVal = eduLvAlloProb[ keyStr ];
						eduLvProb[ (int)eduLv ] = probVal;
					}
					ratio = rand.NextDouble( );
					double sumRatio = 0;
					for ( int i = 0; i < eduLvProb.Length; i++ )
					{
						sumRatio += eduLvProb[ i ];
						if ( ratio <= sumRatio )
						{
							seed.EduLevel = (EEducateLevel)i;
							break;
						}
					}
				}
				deterKeyPart += "-" + seed.EduLevel.ToString( );
				//Registration Type
				{
					double registUrban = 0;
					double registRural = 0;
					double registOther = 0;
					foreach ( ERegistType registType in registTypeSet )
					{
						string keyStr = deterKeyPart + "-" + registType.ToString( );
						double probVal = 0;
						if ( registTypeAlloProb.ContainsKey( keyStr ) )
							probVal = registTypeAlloProb[ keyStr ];
						if ( registType == ERegistType.urban )
							registUrban = probVal;
						else if ( registType == ERegistType.rural )
							registRural = probVal;
						else if ( registType == ERegistType.other )
							registOther = probVal;
					}
					ratio = rand.NextDouble( );
					if ( ratio <= registUrban )
						seed.RegistType = ERegistType.urban;
					else if ( ratio <= registUrban + registRural )
						seed.RegistType = ERegistType.rural;
					else
						seed.RegistType = ERegistType.other;
				}
				deterKeyPart += "-" + seed.RegistType.ToString( );
				//Registration Province
				{
					EProvince[ ] registProvKeys = new EProvince[ registProvSet.Count ];
					double[ ] registProvAllocateProb = new double[ registProvSet.Count ];
					int index = 0;
					foreach ( EProvince registProv in registProvSet )
					{
						string keyStr = deterKeyPart + "-" + registProv.ToString( );
						double probVal = 0;
						if ( registProvAlloProb.ContainsKey( keyStr ) )
							probVal = registProvAlloProb[ keyStr ];
						registProvKeys[ index ] = registProv;
						registProvAllocateProb[ index ] = probVal;
						index++;
					}
					ratio = rand.NextDouble( );
					double sumRatio = 0;
					for ( int i = 0; i < registProvAllocateProb.Length; i++ )
					{
						sumRatio += registProvAllocateProb[ i ];
						if ( ratio <= sumRatio )
						{
							seed.RegistProvin = registProvKeys[ i ];
							break;
						}
					}
				}
				#endregion
				ushort basicAge = (ushort)((int)seed.Age * 5);
				int ageDev = rand.Next( 5 );
				ushort ageNum = (ushort)(basicAge + ageDev);
				ushort birthYear = (ushort)(2000 - ageNum);
				ushort birthMonth = (ushort)(rand.Next( 12 ) + 1);
				Individual newInd = new Individual( agentID, seed.Gender, birthYear, birthMonth, ageNum,
						seed.Race, seed.RegistProvin, seed.RegistType, seed.EduLevel, seed.ResideProvin, seed.ResidenceType );
				//write db:
				string agentIDStr = agentID.ToString( );
				string valueStr = ((int)newInd.Gender).ToString( );
				valueStr += "-" + newInd.BirthYear.ToString( );
				valueStr += "-" + newInd.BirthMonth.ToString( );
				valueStr += "-" + newInd.Age.ToString( );
				valueStr += "-" + ((int)newInd.RaceType).ToString( );
				valueStr += "-" + ((int)newInd.RegistProvin).ToString( );
				valueStr += "-" + ((int)newInd.RegistType).ToString( );
				valueStr += "-" + ((int)newInd.EducateLevel).ToString( );
				valueStr += "-" + ((int)newInd.Provin).ToString( );
				valueStr += "-" + ((int)newInd.ResidenceType).ToString( );
				populationDB.WriteAsyn( agentIDStr, valueStr );
				agentID++;
				//avoid too many connections of files
				if ( agentID % 10000000 == 0 )
				{
					populationDB.DBDispose( );
					Thread.Sleep( 10 );
					populationDB.DBOpen( );
				}
				if ( agentID % 10000000 == 0 )
					Console.WriteLine( string.Format( "{0:0,0}", agentID ) + " individuals generated!" );
			}
			populationDB.DBDispose( );
		}


		private uint ComputeL1Error( Dictionary<IndJointDis, uint> resideProvEduLvPartial, List<IndJointDis> keys,
			Dictionary<EProvince, uint> resideProvConMarginal, Dictionary<EEducateLevel, uint> eduLvConMarginal )
		{
			uint resideProvError = 0;
			uint eduLvError = 0;
			foreach ( EProvince resideProv in resideProvConMarginal.Keys )
			{
				uint sumNum = 0;
				foreach ( IndJointDis parDis in keys )
				{
					if ( parDis.ResideProvin == resideProv )
						sumNum += resideProvEduLvPartial[ parDis ];
				}
				resideProvError += CalSinItemError( sumNum, resideProvConMarginal[ resideProv ] );
			}
			foreach ( EEducateLevel eduLv in eduLvConMarginal.Keys )
			{
				uint sumNum = 0;
				foreach ( IndJointDis parDis in keys )
				{
					if ( parDis.EduLevel == eduLv )
						sumNum += resideProvEduLvPartial[ parDis ];
				}
				eduLvError += CalSinItemError( sumNum, eduLvConMarginal[ eduLv ] );
			}
			return (resideProvError + eduLvError) / 2;
		}
		private uint ComputeL1Error( Dictionary<IndJointDis, uint> jointDis, List<IndJointDis> keys,
				Dictionary<EProvince, uint> resideProvMarginal, Dictionary<EAgeInterval, uint> ageMarginal )
		{
			uint resideProvError = 0;
			uint ageError = 0;
			foreach ( EProvince resideProv in resideProvMarginal.Keys )
			{
				uint sumNum = 0;
				foreach ( IndJointDis parDis in keys )
				{
					if ( parDis.ResideProvin == resideProv )
						sumNum += jointDis[ parDis ];
				}
				resideProvError += CalSinItemError( sumNum, resideProvMarginal[ resideProv ] );
			}
			foreach ( EAgeInterval age in ageMarginal.Keys )
			{
				uint sumNum = 0;
				foreach ( IndJointDis parDis in keys )
				{
					if ( parDis.Age == age )
						sumNum += jointDis[ parDis ];
				}
				ageError += CalSinItemError( sumNum, ageMarginal[ age ] );
			}
			return (resideProvError + ageError) / 2;
		}
		private uint CalSinItemError( uint obValue, uint marginal )
		{
			uint dev = 0;
			if ( marginal >= obValue )
				dev = marginal - obValue;
			else
				dev = obValue - marginal;
			return dev;
		}
	}
}
