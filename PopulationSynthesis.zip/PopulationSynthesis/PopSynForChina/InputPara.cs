﻿using System.Configuration;

namespace PopSynForChina
{
	public class InputPara
	{
		public static string statDir;//input data dir
		public static string popDBName;//synthetic population db name
		public static uint totalPopulation;//total target population scale
		public static double popSizeRatio;//synthetic ratio 

		//MCMC
		public static int transferNum;
		public static int sampleInterval;
		public static int sampleSize;
		public static string jointDisDBName;

		//MCMC, JDI
		public static bool readJointDisFromDB;

		public static void LoadSFFPara( )
		{
			SFFConfigSec SFFConfig = (SFFConfigSec)ConfigurationManager.GetSection( "SFF" );
			statDir = SFFConfig.StatFileDir;
			totalPopulation = uint.Parse( SFFConfig.TotalPopulation );
			popSizeRatio = double.Parse( SFFConfig.TargetPopRatio );
			popDBName = SFFConfig.PopulationDBName;
		}

		public static void LoadMCMCPara( )
		{
			MCMCConfigSec MCMCConfig = (MCMCConfigSec)ConfigurationManager.GetSection( "MCMC" );
			statDir = MCMCConfig.StatFileDir;
			totalPopulation = uint.Parse( MCMCConfig.TotalPopulation );
			popSizeRatio = double.Parse( MCMCConfig.TargetPopRatio );
			popDBName = MCMCConfig.PopulationDBName;
			transferNum = int.Parse( MCMCConfig.TransferNum );
			jointDisDBName = MCMCConfig.JointDisDBName;
			sampleSize = int.Parse( MCMCConfig.SampleSize );
			sampleInterval = int.Parse( MCMCConfig.SampleInterval );
			if ( MCMCConfig.ReadJointDisFromDB == "0" )
				readJointDisFromDB = false;
			else
				readJointDisFromDB = true;
		}

		public static void LoadJDIPara( )
		{
			JDIConfigSec JDIConfig = (JDIConfigSec)ConfigurationManager.GetSection( "JDI" );
			statDir = JDIConfig.StatFileDir;
			totalPopulation = uint.Parse( JDIConfig.TotalPopulation );
			popSizeRatio = double.Parse( JDIConfig.TargetPopRatio );
			popDBName = JDIConfig.PopulationDBName;
			if ( JDIConfig.ReadJointDisFromDB == "0" )
				readJointDisFromDB = false;
			else
				readJointDisFromDB = true;
		}
	}

	public class SFFConfigSec : ConfigurationSection
	{
		[ConfigurationProperty( "StatFileDir", IsRequired = true )]
		public string StatFileDir
		{
			get { return this[ "StatFileDir" ].ToString( ); }
		}
		[ConfigurationProperty( "TotalPopulation", IsRequired = true )]
		public string TotalPopulation
		{
			get { return this[ "TotalPopulation" ].ToString( ); }
		}
		[ConfigurationProperty( "TargetPopRatio", IsRequired = true )]
		public string TargetPopRatio
		{
			get { return this[ "TargetPopRatio" ].ToString( ); }
		}
		[ConfigurationProperty( "PopulationDBName", IsRequired = true )]
		public string PopulationDBName
		{
			get { return this[ "PopulationDBName" ].ToString( ); }
		}
	}
	public class MCMCConfigSec : ConfigurationSection
	{
		[ConfigurationProperty( "StatFileDir", IsRequired = true )]
		public string StatFileDir
		{
			get { return this[ "StatFileDir" ].ToString( ); }
		}
		[ConfigurationProperty( "TotalPopulation", IsRequired = true )]
		public string TotalPopulation
		{
			get { return this[ "TotalPopulation" ].ToString( ); }
		}
		[ConfigurationProperty( "TargetPopRatio", IsRequired = true )]
		public string TargetPopRatio
		{
			get { return this[ "TargetPopRatio" ].ToString( ); }
		}
		[ConfigurationProperty( "PopulationDBName", IsRequired = true )]
		public string PopulationDBName
		{
			get { return this[ "PopulationDBName" ].ToString( ); }
		}
		[ConfigurationProperty( "TransferNum", IsRequired = true )]
		public string TransferNum
		{
			get { return this[ "TransferNum" ].ToString( ); }
		}
		[ConfigurationProperty( "JointDisDBName", IsRequired = true )]
		public string JointDisDBName
		{
			get { return this[ "JointDisDBName" ].ToString( ); }
		}
		[ConfigurationProperty( "SampleSize", IsRequired = true )]
		public string SampleSize
		{
			get { return this[ "SampleSize" ].ToString( ); }
		}
		[ConfigurationProperty( "SampleInterval", IsRequired = true )]
		public string SampleInterval
		{
			get { return this[ "SampleInterval" ].ToString( ); }
		}
		[ConfigurationProperty( "ReadJointDisFromDB", IsRequired = true )]
		public string ReadJointDisFromDB
		{
			get { return this[ "ReadJointDisFromDB" ].ToString( ); }
		}
	}
	public class JDIConfigSec : ConfigurationSection
	{
		[ConfigurationProperty( "StatFileDir", IsRequired = true )]
		public string StatFileDir
		{
			get { return this[ "StatFileDir" ].ToString( ); }
		}
		[ConfigurationProperty( "TotalPopulation", IsRequired = true )]
		public string TotalPopulation
		{
			get { return this[ "TotalPopulation" ].ToString( ); }
		}
		[ConfigurationProperty( "TargetPopRatio", IsRequired = true )]
		public string TargetPopRatio
		{
			get { return this[ "TargetPopRatio" ].ToString( ); }
		}
		[ConfigurationProperty( "PopulationDBName", IsRequired = true )]
		public string PopulationDBName
		{
			get { return this[ "PopulationDBName" ].ToString( ); }
		}
		[ConfigurationProperty( "ReadJointDisFromDB", IsRequired = true )]
		public string ReadJointDisFromDB
		{
			get { return this[ "ReadJointDisFromDB" ].ToString( ); }
		}
	}
}
