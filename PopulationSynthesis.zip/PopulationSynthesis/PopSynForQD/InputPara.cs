﻿using System;
using System.Configuration;

namespace PopSynForQD
{
	public class InputPara
	{
		public static string statDir;//input file dir
		public static string popDBName;//synthetic population DB name
		public static int synPopSize;//synthetic population scale

		public static void LoadConfigPara( )
		{
			PopSynConfigSec inputConfig = (PopSynConfigSec)ConfigurationManager.GetSection( "PopSynForQD" );
			statDir = inputConfig.StatFileDir;
			popDBName = inputConfig.PopulationDBName;
			if ( !int.TryParse( inputConfig.SynPopSize, out synPopSize ) )
				throw new ApplicationException( "Cannot convert SynPopSize into int!!!" );
		}
	}
	public class PopSynConfigSec : ConfigurationSection
	{
		[ConfigurationProperty( "StatFileDir", IsRequired = true )]
		public string StatFileDir
		{
			get { return this[ "StatFileDir" ].ToString( ); }
		}
		[ConfigurationProperty( "PopulationDBName", IsRequired = true )]
		public string PopulationDBName
		{
			get { return this[ "PopulationDBName" ].ToString( ); }
		}
		[ConfigurationProperty( "SynPopSize", IsRequired = true )]
		public string SynPopSize
		{
			get { return this[ "SynPopSize" ].ToString( ); }
		}
	}
}
