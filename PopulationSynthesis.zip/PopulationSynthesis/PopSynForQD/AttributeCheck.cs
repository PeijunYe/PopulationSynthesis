﻿using System;

namespace PopSynForQD
{
	public class AttributeCheck
	{
		/// <summary>
		/// convert input string into district
		/// </summary>
		public static EDistrict CheckRegion( string regName )
		{
			EDistrict result = EDistrict.Other;
			switch ( regName )
			{
				case "市南区": result = EDistrict.ShiNan; break;
				case "市北区": result = EDistrict.ShiBei; break;
				case "四方区": result = EDistrict.SiFang; break;
				case "黄岛区": result = EDistrict.HuangDao; break;
				case "崂山区": result = EDistrict.LaoShan; break;
				case "李沧区": result = EDistrict.LiCang; break;
				case "城阳区": result = EDistrict.ChengYang; break;
				case "胶州市": result = EDistrict.JiaoZhou; break;
				case "即墨市": result = EDistrict.JiMo; break;
				case "平度市": result = EDistrict.PingDu; break;
				case "胶南市": result = EDistrict.JiaoNan; break;
				case "莱西市": result = EDistrict.LaiXi; break;
				default: throw new ApplicationException( "region not contained!!" );
			}
			return result;
		}
	}
}
