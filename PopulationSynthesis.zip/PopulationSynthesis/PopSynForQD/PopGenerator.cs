﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace PopSynForQD
{
	public class PopGenerator
	{
		private Dictionary<IndJointDis, int> genderRegionDis;//gender*distric
		private Dictionary<IndJointDis, int> regionResideTypeDis;//district*resideType
		private Dictionary<IndJointDis, int> genderRegAgeDis;//gender*district*ageInter
		private Dictionary<IndJointDis, int> genderRegEduLvDis;//gender*district*eduLv
		private Dictionary<IndJointDis, int> jointDis;//joint distribution

		public PopGenerator( )
		{
			genderRegionDis = new Dictionary<IndJointDis, int>( );
			regionResideTypeDis = new Dictionary<IndJointDis, int>( );
			genderRegAgeDis = new Dictionary<IndJointDis, int>( );
			genderRegEduLvDis = new Dictionary<IndJointDis, int>( );
			jointDis = new Dictionary<IndJointDis, int>( );
		}

		public void Generating( )
		{
			InitIndMarginals( );
			JointDisCompute( );
			Allocation( );
		}

		/// <summary>
		/// read input distributions
		/// </summary>
		private void InitIndMarginals( )
		{
			StreamReader sr = new StreamReader( Path.Combine( InputPara.statDir, "GenderRegionTypeQD.txt" ), Encoding.Default );
			String line = sr.ReadLine( );
			while ( (line = sr.ReadLine( )) != null )
			{
				string[ ] items = line.Split( '\t' );
				for ( int i = 0; i < items.Length; i++ )
					items[ i ] = items[ i ].Trim( );
				EDistrict district = AttributeCheck.CheckRegion( items[ 0 ] );
				int maleNum = int.Parse( items[ 2 ] );
				int femaleNum = int.Parse( items[ 3 ] );
				int urbanNum = int.Parse( items[ 8 ] );
				int ruralNum = -1;
				if ( !int.TryParse( items[ 9 ], out ruralNum ) )
					ruralNum = 0;
				IndJointDis genRegMaleDis = new IndJointDis( EGender.Male, district, EResidenceType.rural, EAgeInterval.ZeroToFour, EEducateLevel.infant );
				genderRegionDis.Add( genRegMaleDis, maleNum );
				IndJointDis genRegFemaleDis = new IndJointDis( EGender.Female, district, EResidenceType.rural, EAgeInterval.ZeroToFour, EEducateLevel.infant );
				genderRegionDis.Add( genRegFemaleDis, femaleNum );
				IndJointDis regUrbanDis = new IndJointDis( EGender.Male, district, EResidenceType.urban, EAgeInterval.ZeroToFour, EEducateLevel.infant );
				regionResideTypeDis.Add( regUrbanDis, urbanNum );
				IndJointDis regRuralDis = new IndJointDis( EGender.Male, district, EResidenceType.rural, EAgeInterval.ZeroToFour, EEducateLevel.infant );
				regionResideTypeDis.Add( regRuralDis, ruralNum );
			}
			sr.Close( );
			sr.Dispose( );
			sr = new StreamReader( Path.Combine( InputPara.statDir, "GenderRegionAgeQD.txt" ), Encoding.Default );
			line = sr.ReadLine( );
			while ( (line = sr.ReadLine( )) != null )
			{
				string[ ] items = line.Split( '\t' );
				for ( int i = 0; i < items.Length; i++ )
					items[ i ] = items[ i ].Trim( );
				EDistrict district = AttributeCheck.CheckRegion( items[ 0 ] );
				for ( int i = 1; i <= 18; i++ )
				{
					EAgeInterval age = (EAgeInterval)i;
					int maleNum = int.Parse( items[ 2 * i + 1 ] );
					int femaleNum = int.Parse( items[ 2 * i + 2 ] );
					if ( age == EAgeInterval.ZeroToFour )
					{
						maleNum += int.Parse( items[ 1 ] );
						femaleNum += int.Parse( items[ 2 ] );
					}
					IndJointDis regAgeMaleDis = new IndJointDis( EGender.Male, district, EResidenceType.rural, age, EEducateLevel.infant );
					genderRegAgeDis.Add( regAgeMaleDis, maleNum );
					IndJointDis regAgeFemaleDis = new IndJointDis( EGender.Female, district, EResidenceType.rural, age, EEducateLevel.infant );
					genderRegAgeDis.Add( regAgeFemaleDis, femaleNum );
				}
			}
			sr.Close( );
			sr.Dispose( );
			sr = new StreamReader( Path.Combine( InputPara.statDir, "GenderRegionEduLvQD.txt" ), Encoding.Default );
			line = sr.ReadLine( );
			while ( (line = sr.ReadLine( )) != null )
			{
				string[ ] items = line.Split( '\t' );
				for ( int i = 0; i < items.Length; i++ )
					items[ i ] = items[ i ].Trim( );
				EDistrict district = AttributeCheck.CheckRegion( items[ 0 ] );
				for ( int i = 1; i <= 9; i++ )
				{
					EEducateLevel eduLv = (EEducateLevel)i;
					int maleNum = int.Parse( items[ 2 * i - 1 ] );
					int femaleNum = int.Parse( items[ 2 * i ] );
					IndJointDis regEduLvMaleDis = new IndJointDis( EGender.Male, district, EResidenceType.rural, EAgeInterval.ZeroToFour, eduLv );
					genderRegEduLvDis.Add( regEduLvMaleDis, maleNum );
					IndJointDis regEduLvFemaleDis = new IndJointDis( EGender.Female, district, EResidenceType.rural, EAgeInterval.ZeroToFour, eduLv );
					genderRegEduLvDis.Add( regEduLvFemaleDis, femaleNum );
				}
			}
			sr.Close( );
			sr.Dispose( );
		}

		/// <summary>
		/// compute joint distribution
		/// </summary>
		private void JointDisCompute( )
		{
			foreach ( IndJointDis indDis in genderRegAgeDis.Keys )
			{
				EGender gender = indDis.Gender;
				EDistrict district = indDis.District;
				EAgeInterval ageInter = indDis.AgeInter;
				int origIndNum = genderRegAgeDis[ indDis ];
				Dictionary<EEducateLevel, int> eduLvDic = new Dictionary<EEducateLevel, int>( );
				int indSum = 0;
				foreach ( IndJointDis parIndDis in genderRegEduLvDis.Keys )
				{
					if ( parIndDis.Gender == gender && parIndDis.District == district )
					{
						eduLvDic.Add( parIndDis.EduLevel, genderRegEduLvDis[ parIndDis ] );
						indSum += genderRegEduLvDis[ parIndDis ];
					}
				}
				int indTotal = 0;
				foreach ( IndJointDis parIndDis in genderRegionDis.Keys )
				{
					if ( parIndDis.Gender == gender && parIndDis.District == district )
					{
						indTotal = genderRegionDis[ parIndDis ];
						break;
					}
				}
				if ( indTotal <= indSum )
					Console.WriteLine( "indTotal <= indSum" );
				eduLvDic.Add( EEducateLevel.infant, indTotal - indSum );
				foreach ( EEducateLevel eduLv in eduLvDic.Keys )
				{
					IndJointDis newIndDis = new IndJointDis( gender, district, EResidenceType.rural, ageInter, eduLv );
					int indNum = (int)Math.Round( ((double)eduLvDic[ eduLv ] / indTotal) * origIndNum );
					jointDis.Add( newIndDis, indNum );
				}
			}
			List<IndJointDis> jointDisKeys = new List<IndJointDis>( );
			jointDisKeys.AddRange( jointDis.Keys );
			foreach ( IndJointDis indDis in jointDisKeys )
			{
				EGender gender = indDis.Gender;
				EDistrict district = indDis.District;
				EAgeInterval ageInter = indDis.AgeInter;
				EEducateLevel eduLv = indDis.EduLevel;
				int origIndNum = jointDis[ indDis ];
				Dictionary<EResidenceType, int> resideTypeDic = new Dictionary<EResidenceType, int>( );
				int indSum = 0;
				foreach ( IndJointDis parIndDis in regionResideTypeDis.Keys )
				{
					if ( parIndDis.District == district )
					{
						resideTypeDic.Add( parIndDis.ResideType, regionResideTypeDis[ parIndDis ] );
						indSum += regionResideTypeDis[ parIndDis ];
					}
				}
				jointDis.Remove( indDis );
				foreach ( EResidenceType resideType in resideTypeDic.Keys )
				{
					IndJointDis newIndDis = new IndJointDis( gender, district, resideType, ageInter, eduLv );
					int indNum = (int)Math.Round( ((double)resideTypeDic[ resideType ] / indSum) * origIndNum );
					jointDis.Add( newIndDis, indNum );
				}
			}
		}

		private void Allocation( )
		{
			//conditional probability
			Dictionary<EGender, double> genderAlloProb = new Dictionary<EGender, double>( );
			Dictionary<IndJointDis, double> districAlloProb = new Dictionary<IndJointDis, double>( );
			Dictionary<IndJointDis, double> resideTypeAlloProb = new Dictionary<IndJointDis, double>( );
			Dictionary<IndJointDis, double> ageAlloProb = new Dictionary<IndJointDis, double>( );
			Dictionary<IndJointDis, double> eduLvAlloProb = new Dictionary<IndJointDis, double>( );
			#region compute allocation probability
			HashSet<EGender> genderSet = new HashSet<EGender>( );
			HashSet<EDistrict> districtSet = new HashSet<EDistrict>( );
			HashSet<EResidenceType> resideTypeSet = new HashSet<EResidenceType>( );
			HashSet<EAgeInterval> ageSet = new HashSet<EAgeInterval>( );
			HashSet<EEducateLevel> eduLvSet = new HashSet<EEducateLevel>( );
			foreach ( IndJointDis indDis in jointDis.Keys )
			{
				genderSet.Add( indDis.Gender );
				districtSet.Add( indDis.District );
				resideTypeSet.Add( indDis.ResideType );
				ageSet.Add( indDis.AgeInter );
				eduLvSet.Add( indDis.EduLevel );
			}
			int maleNum = 0;
			int femaleNum = 0;
			foreach ( IndJointDis indDis in jointDis.Keys )
			{
				if ( indDis.Gender == EGender.Male )
					maleNum += jointDis[ indDis ];
				else
					femaleNum += jointDis[ indDis ];
			}
			double maleProb = (double)maleNum / (maleNum + femaleNum);
			genderAlloProb.Add( EGender.Male, maleProb );
			genderAlloProb.Add( EGender.Female, (1 - maleProb) );
			foreach ( EGender gender in genderSet )
			{
				int indSum = 0;
				Dictionary<EDistrict, int> districDic = new Dictionary<EDistrict, int>( );
				foreach ( IndJointDis indDis in jointDis.Keys )
				{
					if ( indDis.Gender == gender )
					{
						if ( districDic.ContainsKey( indDis.District ) )
							districDic[ indDis.District ] += jointDis[ indDis ];
						else
							districDic.Add( indDis.District, jointDis[ indDis ] );
						indSum += jointDis[ indDis ];
					}
				}
				foreach ( EDistrict district in districDic.Keys )
				{
					IndJointDis newIndDis = new IndJointDis( gender, district, EResidenceType.rural, EAgeInterval.ZeroToFour, EEducateLevel.infant );
					double alloProb = (double)districDic[ district ] / indSum;
					districAlloProb.Add( newIndDis, alloProb );
				}
			}
			foreach ( EGender gender in genderSet )
			{
				foreach ( EDistrict district in districtSet )
				{
					int indSum = 0;
					Dictionary<EResidenceType, int> resideTypeDic = new Dictionary<EResidenceType, int>( );
					foreach ( IndJointDis indDis in jointDis.Keys )
					{
						if ( indDis.Gender == gender && indDis.District == district )
						{
							if ( resideTypeDic.ContainsKey( indDis.ResideType ) )
								resideTypeDic[ indDis.ResideType ] += jointDis[ indDis ];
							else
								resideTypeDic.Add( indDis.ResideType, jointDis[ indDis ] );
							indSum += jointDis[ indDis ];
						}
					}
					foreach ( EResidenceType resideType in resideTypeDic.Keys )
					{
						IndJointDis newIndDis = new IndJointDis( gender, district, resideType, EAgeInterval.ZeroToFour, EEducateLevel.infant );
						double alloProb = (double)resideTypeDic[ resideType ] / indSum;
						resideTypeAlloProb.Add( newIndDis, alloProb );
					}
				}
			}
			foreach ( EGender gender in genderSet )
			{
				foreach ( EDistrict district in districtSet )
				{
					foreach ( EResidenceType resideType in resideTypeSet )
					{
						int indSum = 0;
						Dictionary<EAgeInterval, int> ageDic = new Dictionary<EAgeInterval, int>( );
						foreach ( IndJointDis indDis in jointDis.Keys )
						{
							if ( indDis.Gender == gender && indDis.District == district && indDis.ResideType == resideType )
							{
								if ( ageDic.ContainsKey( indDis.AgeInter ) )
									ageDic[ indDis.AgeInter ] += jointDis[ indDis ];
								else
									ageDic.Add( indDis.AgeInter, jointDis[ indDis ] );
								indSum += jointDis[ indDis ];
							}
						}
						foreach ( EAgeInterval ageInter in ageDic.Keys )
						{
							IndJointDis newIndDis = new IndJointDis( gender, district, resideType, ageInter, EEducateLevel.infant );
							double alloProb = (double)ageDic[ ageInter ] / indSum;
							ageAlloProb.Add( newIndDis, alloProb );
						}
					}
				}
			}
			foreach ( EGender gender in genderSet )
			{
				foreach ( EDistrict district in districtSet )
				{
					foreach ( EResidenceType resideType in resideTypeSet )
					{
						foreach ( EAgeInterval ageInter in ageSet )
						{
							int indSum = 0;
							Dictionary<EEducateLevel, int> eduLvDic = new Dictionary<EEducateLevel, int>( );
							foreach ( IndJointDis indDis in jointDis.Keys )
							{
								if ( indDis.Gender == gender && indDis.District == district && indDis.ResideType == resideType && indDis.AgeInter == ageInter )
								{
									if ( eduLvDic.ContainsKey( indDis.EduLevel ) )
										eduLvDic[ indDis.EduLevel ] += jointDis[ indDis ];
									else
										eduLvDic.Add( indDis.EduLevel, jointDis[ indDis ] );
									indSum += jointDis[ indDis ];
								}
							}
							foreach ( EEducateLevel eduLv in eduLvDic.Keys )
							{
								IndJointDis newIndDis = new IndJointDis( gender, district, resideType, ageInter, eduLv );
								double alloProb = (double)eduLvDic[ eduLv ] / indSum;
								eduLvAlloProb.Add( newIndDis, alloProb );
							}
						}
					}
				}
			}
			#endregion
			string populationDBName = Path.Combine( new DirectoryInfo( Environment.CurrentDirectory ).FullName, InputPara.popDBName );
			MyDatabase populationDB = new MyDatabase( populationDBName );
			if ( Directory.Exists( populationDBName ) )
				Directory.Delete( populationDBName, true );
			populationDB.DBOpen( );
			Random rand = new Random( );
			for ( uint agentID = 1; agentID <= InputPara.synPopSize; agentID++ )
			{
				Individual seed = new Individual( agentID, EGender.Male, EDistrict.Other, EResidenceType.rural, EAgeInterval.ZeroToFour, EEducateLevel.infant );
				#region allocate attribute
				//gender
				double ratio = rand.NextDouble( );
				if ( ratio <= genderAlloProb[ EGender.Male ] )
					seed.Gender = EGender.Male;
				else
					seed.Gender = EGender.Female;
				ratio = rand.NextDouble( );
				//district
				EDistrict[ ] districtKeys = new EDistrict[ districAlloProb.Count ];
				double[ ] districProb = new double[ districAlloProb.Count ];
				int index = 0;
				foreach ( IndJointDis indDis in districAlloProb.Keys )
				{
					if ( indDis.Gender == seed.Gender )
					{
						districtKeys[ index ] = indDis.District;
						districProb[ index ] = districAlloProb[ indDis ];
						index++;
					}
				}
				ratio = rand.NextDouble( );
				double sumRatio = 0;
				for ( int i = 0; i < districtKeys.Length; i++ )
				{
					sumRatio += districProb[ i ];
					if ( ratio <= sumRatio )
					{
						seed.District = districtKeys[ i ];
						break;
					}
				}
				//resideType
				EResidenceType[ ] resideTypeKeys = new EResidenceType[ resideTypeAlloProb.Count ];
				double[ ] resideTypeProb = new double[ resideTypeAlloProb.Count ];
				index = 0;
				foreach ( IndJointDis indDis in resideTypeAlloProb.Keys )
				{
					if ( indDis.Gender == seed.Gender && indDis.District == seed.District )
					{
						resideTypeKeys[ index ] = indDis.ResideType;
						resideTypeProb[ index ] = resideTypeAlloProb[ indDis ];
						index++;
					}
				}
				ratio = rand.NextDouble( );
				sumRatio = 0;
				for ( int i = 0; i < resideTypeKeys.Length; i++ )
				{
					sumRatio += resideTypeProb[ i ];
					if ( ratio <= sumRatio )
					{
						seed.ResideType = resideTypeKeys[ i ];
						break;
					}
				}
				//ageInter
				EAgeInterval[ ] ageInterKeys = new EAgeInterval[ ageAlloProb.Count ];
				double[ ] ageInterProb = new double[ ageAlloProb.Count ];
				index = 0;
				foreach ( IndJointDis indDis in ageAlloProb.Keys )
				{
					if ( indDis.Gender == seed.Gender && indDis.District == seed.District && indDis.ResideType == seed.ResideType )
					{
						ageInterKeys[ index ] = indDis.AgeInter;
						ageInterProb[ index ] = ageAlloProb[ indDis ];
						index++;
					}
				}
				ratio = rand.NextDouble( );
				sumRatio = 0;
				for ( int i = 0; i < ageInterKeys.Length; i++ )
				{
					sumRatio += ageInterProb[ i ];
					if ( ratio <= sumRatio )
					{
						seed.AgeInter = ageInterKeys[ i ];
						break;
					}
				}
				//eduLv
				EEducateLevel[ ] eduLvKeys = new EEducateLevel[ eduLvAlloProb.Count ];
				double[ ] eduLvProb = new double[ eduLvAlloProb.Count ];
				index = 0;
				foreach ( IndJointDis indDis in eduLvAlloProb.Keys )
				{
					if ( indDis.Gender == seed.Gender && indDis.District == seed.District
						&& indDis.ResideType == seed.ResideType && indDis.AgeInter == seed.AgeInter )
					{
						eduLvKeys[ index ] = indDis.EduLevel;
						eduLvProb[ index ] = eduLvAlloProb[ indDis ];
						index++;
					}
				}
				ratio = rand.NextDouble( );
				sumRatio = 0;
				for ( int i = 0; i < eduLvKeys.Length; i++ )
				{
					sumRatio += eduLvProb[ i ];
					if ( ratio <= sumRatio )
					{
						seed.EduLevel = eduLvKeys[ i ];
						break;
					}
				}
				#endregion
				//DB write
				string agentIDStr = agentID.ToString( );
				string valueStr = ((int)seed.Gender).ToString( );
				valueStr += "-" + ((int)seed.District).ToString( );
				valueStr += "-" + ((int)seed.ResideType).ToString( );
				valueStr += "-" + ((int)seed.AgeInter).ToString( );
				valueStr += "-" + ((int)seed.EduLevel).ToString( );
				populationDB.WriteAsyn( agentIDStr, valueStr );
				if ( agentID % 100000 == 0 )
					Console.WriteLine( string.Format( "{0:0,0}", agentID ) + " individuals generated..." );
			}
		}
	}
}
