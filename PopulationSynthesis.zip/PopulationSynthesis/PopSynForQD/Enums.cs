﻿
namespace PopSynForQD
{
	public enum EGender
	{
		Male = 1,
		Female = 2,
	}

	public enum EDistrict
	{
		ShiNan = 1,
		ShiBei = 2,
		SiFang = 3,
		HuangDao = 4,
		LaoShan = 5,
		LiCang = 6,
		ChengYang = 7,
		JiaoZhou = 8,
		JiMo = 9,
		PingDu = 10,
		JiaoNan = 11,
		LaiXi = 12,
		/// <summary>
		/// represent exception
		/// </summary>
		Other = 0,
	}

	public enum EResidenceType
	{
		urban = 1,
		rural = 2,
	}

	public enum EAgeInterval
	{
		ZeroToFour = 1,
		FiveToNine = 2,
		TenToFourteen = 3,
		FifteenToNineteen = 4,
		TwentyToTwentyFour = 5,
		TwentyFiveToTwentyNine = 6,
		ThirtyToThirtyFour = 7,
		ThirtyFiveToThirtyNine = 8,
		FortyToFortyFour = 9,
		FortyFiveToFortyNine = 10,
		FiftyToFiftyFour = 11,
		FiftyFiveToFiftyNine = 12,
		SixtyToSixtyFour = 13,
		SixtyFiveToSixtyNine = 14,
		SeventyToSeventyFour = 15,
		SeventyFiveToSeventyNine = 16,
		EightyToEightyFour = 17,
		EightyFiveAndAbove = 18,
	}

	public enum EEducateLevel
	{
		/// <summary>
		/// represent child below 6 year old
		/// </summary>
		infant = 0,
		notEducated = 1,
		literClass = 2,
		primaSchool = 3,
		junMidSchool = 4,
		senMidSchool = 5,
		polytechSchool = 6,
		college = 7,
		university = 8,
		graduate = 9,
	}
}
