﻿
namespace PopSynForQD
{
	public struct IndJointDis
	{
		private EGender gender;
		private EDistrict district;
		private EResidenceType resideType;
		private EAgeInterval ageInter;
		private EEducateLevel eduLevel;
		#region properties
		public EGender Gender
		{
			get { return gender; }
			set { gender = value; }
		}
		public EDistrict District
		{
			get { return district; }
			set { district = value; }
		}
		public EResidenceType ResideType
		{
			get { return resideType; }
			set { resideType = value; }
		}
		public EAgeInterval AgeInter
		{
			get { return ageInter; }
			set { ageInter = value; }
		}
		public EEducateLevel EduLevel
		{
			get { return eduLevel; }
			set { eduLevel = value; }
		}
		#endregion
		public IndJointDis( EGender gender, EDistrict district, EResidenceType resideType, EAgeInterval ageInter, EEducateLevel eduLevel )
		{
			this.gender = gender;
			this.district = district;
			this.resideType = resideType;
			this.ageInter = ageInter;
			this.eduLevel = eduLevel;
		}
	}

	public class Individual
	{
		private uint agentID;
		private EGender gender;
		private EDistrict district;
		private EResidenceType resideType;
		private EAgeInterval ageInter;
		private EEducateLevel eduLevel;
		#region properties
		public uint AgentID
		{
			get { return agentID; }
		}
		public EGender Gender
		{
			get { return gender; }
			set { gender = value; }
		}
		public EDistrict District
		{
			get { return district; }
			set { district = value; }
		}
		public EResidenceType ResideType
		{
			get { return resideType; }
			set { resideType = value; }
		}
		public EAgeInterval AgeInter
		{
			get { return ageInter; }
			set { ageInter = value; }
		}
		public EEducateLevel EduLevel
		{
			get { return eduLevel; }
			set { eduLevel = value; }
		}
		#endregion
		public Individual( uint agentID, EGender gender, EDistrict district, EResidenceType resideType, EAgeInterval ageInter, EEducateLevel eduLevel )
		{
			this.agentID = agentID;
			this.gender = gender;
			this.district = district;
			this.resideType = resideType;
			this.ageInter = ageInter;
			this.eduLevel = eduLevel;
		}
	}
}
