﻿using System;
using System.Diagnostics;

namespace PopSynForQD
{
	public class Program
	{
		static void Main( string[ ] args )
		{
			Stopwatch stopw = new Stopwatch( );
			stopw.Start( );
			InputPara.LoadConfigPara( );
			PopGenerator popGen = new PopGenerator( );
			popGen.Generating( );
			stopw.Stop( );
			Console.WriteLine( "Done ..." );
			Console.WriteLine( "Time Elapsed: " + stopw.Elapsed );
			Console.ReadLine( );
		}
	}
}
