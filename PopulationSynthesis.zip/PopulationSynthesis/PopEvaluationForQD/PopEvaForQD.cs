﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace PopEvaluationForQD
{
	public class PopEvaForQD
	{
		private string longTableName;
		private string popDBName;
		private Dictionary<IndJointDis, int> genderRegAgeLT;//long table data: gender*region*age (age >= 15)
		private Dictionary<IndJointDis, int> synPopSampled;//sampled population for evaluation
		private int popTotalLT;//total number of population from long table (age >= 15)
		private double sampleRatio;//sample ratio for synthetic population

		public PopEvaForQD( string longTableName, string popDBName )
		{
			this.longTableName = longTableName;
			this.popDBName = popDBName;
			genderRegAgeLT = new Dictionary<IndJointDis, int>( );
			synPopSampled = new Dictionary<IndJointDis, int>( );
			popTotalLT = 0;
			sampleRatio = 0;
		}

		public void Evaluating( )
		{
			ReadLTDis( );
			CalSampleRatio( );
			ReadSynPop( );
			CalIndicator( );
		}

		private void ReadLTDis( )
		{
			StreamReader sr = new StreamReader( longTableName, Encoding.Default );
			String line = sr.ReadLine( );
			while ( (line = sr.ReadLine( )) != null )
			{
				string[ ] items = line.Split( '\t' );
				for ( int i = 0; i < items.Length; i++ )
					items[ i ] = items[ i ].Trim( );
				EDistrict district = CheckRegion( items[ 0 ] );
				int maleNum = int.Parse( items[ 2 ] );
				int femaleNum = int.Parse( items[ 3 ] );
				IndJointDis genRegMaleDis = new IndJointDis( EGender.Male, district, EResidenceType.rural, EAgeInterval.FifteenToNineteen, EEducateLevel.infant );
				genderRegAgeLT.Add( genRegMaleDis, maleNum );
				IndJointDis genRegFemaleDis = new IndJointDis( EGender.Female, district, EResidenceType.rural, EAgeInterval.FifteenToNineteen, EEducateLevel.infant );
				genderRegAgeLT.Add( genRegFemaleDis, femaleNum );
				popTotalLT += maleNum + femaleNum;
			}
			sr.Close( );
			sr.Dispose( );
		}

		private void CalSampleRatio( )
		{
			MyDatabase popDB = new MyDatabase( popDBName );
			if ( !Directory.Exists( popDBName ) )
			{
				Console.WriteLine( "Population database does not exist!" );
				return;
			}
			popDB.DBOpen( );
			DBIterator dbIter = popDB.GetIterator( );
			int synPopNum = 0;
			for ( dbIter.SeekToFirst( ); dbIter.Valid( ); dbIter.Next( ) )
			{
				string keyStr = dbIter.Key( ).ToString( );
				string valueStr = dbIter.Value( ).ToString( );
				string[ ] attributes = valueStr.Split( '-' );
				EGender gender = (EGender)(int.Parse( attributes[ 0 ] ));
				EDistrict district = (EDistrict)(int.Parse( attributes[ 1 ] ));
				EResidenceType resideType = (EResidenceType)(int.Parse( attributes[ 2 ] ));
				EAgeInterval ageInter = (EAgeInterval)(int.Parse( attributes[ 3 ] ));
				EEducateLevel eduLv = (EEducateLevel)(int.Parse( attributes[ 4 ] ));
				if ( ageInter == EAgeInterval.ZeroToFour || ageInter == EAgeInterval.FiveToNine || ageInter == EAgeInterval.TenToFourteen )
					continue;
				synPopNum++;
			}
			dbIter.Dispose( );
			popDB.DBDispose( );
			sampleRatio = (double)popTotalLT / synPopNum;
		}

		private void ReadSynPop( )
		{
			MyDatabase popDB = new MyDatabase( popDBName );
			if ( !Directory.Exists( popDBName ) )
			{
				Console.WriteLine( "Population database does not exist!" );
				return;
			}
			popDB.DBOpen( );
			DBIterator dbIter = popDB.GetIterator( );
			Random rand = new Random( );
			int lineNum = 0;
			for ( dbIter.SeekToFirst( ); dbIter.Valid( ); dbIter.Next( ) )
			{
				string keyStr = dbIter.Key( ).ToString( );
				string valueStr = dbIter.Value( ).ToString( );
				string[ ] attributes = valueStr.Split( '-' );
				EGender gender = (EGender)(int.Parse( attributes[ 0 ] ));
				EDistrict district = (EDistrict)(int.Parse( attributes[ 1 ] ));
				EResidenceType resideType = (EResidenceType)(int.Parse( attributes[ 2 ] ));
				EAgeInterval ageInter = (EAgeInterval)(int.Parse( attributes[ 3 ] ));
				EEducateLevel eduLv = (EEducateLevel)(int.Parse( attributes[ 4 ] ));
				if ( ageInter == EAgeInterval.ZeroToFour || ageInter == EAgeInterval.FiveToNine || ageInter == EAgeInterval.TenToFourteen )
					continue;
				double ratio = rand.NextDouble( );
				if ( ratio > sampleRatio )
					continue;
				List<IndJointDis> synPopSampledKeys = new List<IndJointDis>( );
				synPopSampledKeys.AddRange( synPopSampled.Keys );
				bool hasKey = false;
				foreach ( IndJointDis indDis in synPopSampledKeys )
				{
					if ( indDis.Gender == gender && indDis.District == district )
					{
						synPopSampled[ indDis ]++;
						hasKey = true;
						break;
					}
				}
				if ( !hasKey )
				{
					IndJointDis newIndDis = new IndJointDis( gender, district, EResidenceType.rural, EAgeInterval.FifteenToNineteen, EEducateLevel.infant );
					synPopSampled.Add( newIndDis, 1 );
				}
				lineNum++;
			}
			dbIter.Dispose( );
			popDB.DBDispose( );
			Console.WriteLine( lineNum + " records sampled----------" );
		}

		private void CalIndicator( )
		{
			StreamWriter evalWriter = new StreamWriter( "QDResult.txt", false );
			foreach ( IndJointDis indCon in genderRegAgeLT.Keys )
			{
				int constraint = genderRegAgeLT[ indCon ];
				int synNum = 0;
				foreach ( IndJointDis indDis in synPopSampled.Keys )
				{
					if ( indDis.Gender == indCon.Gender && indDis.District == indCon.District )
					{
						synNum = synPopSampled[ indDis ];
						break;
					}
				}
				if ( synNum == 0 )
					Console.WriteLine( "does not have this distribution!!" );
				int error = constraint - synNum;
				string line = indCon.Gender.ToString( ) + "*" + indCon.District.ToString( ) ;
				line += "\t" + constraint + "\t" + synNum + "\t" + error + "\t" + ((double)error / constraint).ToString( "0.0000" );
				evalWriter.WriteLine( line );
			}
			evalWriter.Close( );
		}

		/// <summary>
		/// check region
		/// </summary>
		private EDistrict CheckRegion( string regName )
		{
			EDistrict result = EDistrict.Other;
			switch ( regName )
			{
				case "市南区": result = EDistrict.ShiNan; break;
				case "市北区": result = EDistrict.ShiBei; break;
				case "四方区": result = EDistrict.SiFang; break;
				case "黄岛区": result = EDistrict.HuangDao; break;
				case "崂山区": result = EDistrict.LaoShan; break;
				case "李沧区": result = EDistrict.LiCang; break;
				case "城阳区": result = EDistrict.ChengYang; break;
				case "胶州市": result = EDistrict.JiaoZhou; break;
				case "即墨市": result = EDistrict.JiMo; break;
				case "平度市": result = EDistrict.PingDu; break;
				case "胶南市": result = EDistrict.JiaoNan; break;
				case "莱西市": result = EDistrict.LaiXi; break;
				default: throw new ApplicationException( "region not contained!!" );
			}
			return result;
		}
	}
}
