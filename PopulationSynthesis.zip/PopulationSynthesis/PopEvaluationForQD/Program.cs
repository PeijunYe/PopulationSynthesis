﻿using System;

namespace PopEvaluationForQD
{
	class Program
	{
		static void Main( string[ ] args )
		{
			string longTableName = @"PopLTForQD.txt";//long table file name
			string popDBName = @"QDSynPop";//synthetic population DB name

			PopEvaForQD popEva = new PopEvaForQD( longTableName, popDBName );
			popEva.Evaluating( );
			Console.WriteLine( "Done ..." );
			Console.ReadLine( );
		}
	}
}
