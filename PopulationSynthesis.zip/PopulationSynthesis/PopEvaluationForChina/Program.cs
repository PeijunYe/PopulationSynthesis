﻿using System;

namespace PopEvaluationForChina
{
	class Program
	{
		static void Main( string[ ] args )
		{
			string statDir = "LongTable";
			string dbName = "SynPopDB";
			double sampleRatio = 0.095;
			if ( args.Length == 2 )
			{
				statDir = args[ 0 ];
				dbName = args[ 1 ];
			} else if ( args.Length == 2 )
			{
				statDir = args[ 0 ];
				dbName = args[ 1 ];
				if ( !double.TryParse( args[ 2 ], out sampleRatio ) )
				{
					sampleRatio = 0.095;
				}
			} else
			{
				Console.WriteLine( "Please enter two or three parameters:\n" );
				Console.WriteLine( "LongTableDir, dbName OR LongTableDir, dbName, SampleRatio" );
				return;
			}
			PopEvaluation popEval = new PopEvaluation( statDir, dbName, sampleRatio );
			popEval.Evaluating( );

			Console.WriteLine( "done..." );
			Console.ReadLine( );
		}
	}
}
