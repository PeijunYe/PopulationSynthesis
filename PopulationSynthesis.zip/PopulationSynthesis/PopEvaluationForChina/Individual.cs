﻿
namespace PopEvaluationForChina
{
	//attributes combinations of partial joint distributions:
	public struct GenResideTypeResideProv
	{
		private EGender gender;
		private EResidenceType residenceType;
		private EProvince resideProvin;
		#region Properties
		public EGender Gender
		{
			get { return gender; }
			set { gender = value; }
		}
		public EProvince ResideProvin
		{
			get { return resideProvin; }
			set { resideProvin = value; }
		}
		public EResidenceType ResidenceType
		{
			get { return residenceType; }
			set { residenceType = value; }
		}
		#endregion
		public GenResideTypeResideProv( EGender gender, EResidenceType residenceType, EProvince resideProvin )
		{
			this.gender = gender;
			this.resideProvin = resideProvin;
			this.residenceType = residenceType;
		}
	}

	public struct GenResideTypeAge
	{
		private EGender gender;
		private EResidenceType residenceType;
		private EAgeInterval age;
		#region Properties
		public EGender Gender
		{
			get { return gender; }
			set { gender = value; }
		}
		public EAgeInterval Age
		{
			get { return age; }
			set { age = value; }
		}
		public EResidenceType ResidenceType
		{
			get { return residenceType; }
			set { residenceType = value; }
		}
		#endregion
		public GenResideTypeAge( EGender gender, EResidenceType residenceType, EAgeInterval age )
		{
			this.gender = gender;
			this.age = age;
			this.residenceType = residenceType;
		}
	}

	public struct GenderRace
	{
		private EGender gender;
		private ERaceType race;
		#region Properties
		public EGender Gender
		{
			get { return gender; }
			set { gender = value; }
		}
		public ERaceType Race
		{
			get { return race; }
			set { race = value; }
		}
		#endregion
		public GenderRace( EGender gender, ERaceType race )
		{
			this.gender = gender;
			this.race = race;
		}
	}

	public struct GenResideTypeEduLv
	{
		private EGender gender;
		private EResidenceType residenceType;
		private EEducateLevel eduLevel;
		#region Properties
		public EGender Gender
		{
			get { return gender; }
			set { gender = value; }
		}
		public EResidenceType ResidenceType
		{
			get { return residenceType; }
			set { residenceType = value; }
		}
		public EEducateLevel EduLevel
		{
			get { return eduLevel; }
			set { eduLevel = value; }
		}
		#endregion
		public GenResideTypeEduLv( EGender gender, EResidenceType residenceType, EEducateLevel eduLevel )
		{
			this.gender = gender;
			this.residenceType = residenceType;
			this.eduLevel = eduLevel;
		}
	}
}
