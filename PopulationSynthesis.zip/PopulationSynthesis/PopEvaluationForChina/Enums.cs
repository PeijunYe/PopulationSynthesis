﻿
namespace PopEvaluationForChina
{
	/// <summary>
	/// province code (31 provinces, 1 "other")
	/// </summary>
	public enum EProvince
	{
		Beijing = 11,
		Tianjin = 12,
		Hebei = 13,
		Shan_1xi = 14,
		Neimenggu = 15,
		Liaoning = 21,
		Jilin = 22,
		Heilongjiang = 23,
		Shanghai = 31,
		Jiangsu = 32,
		Zhejiang = 33,
		Anhui = 34,
		Fujian = 35,
		Jiangxi = 36,
		Shandong = 37,
		Henan = 41,
		Hubei = 42,
		Hunan = 43,
		Guangdong = 44,
		Guangxi = 45,
		Hainan = 46,
		Chongqing = 50,
		Sichuan = 51,
		Guizhou = 52,
		Yunnan = 53,
		Xizang = 54,
		Shan_3xi = 61,
		Gansu = 62,
		Qinghai = 63,
		Ningxia = 64,
		Xinjiang = 65,
		/// <summary>
		/// represent the one without registration
		/// </summary>
		Other = 0,
	}

	/// <summary>
	/// Registration Type (Agricultural, Non-agricultural)
	/// </summary>
	public enum ERegistType
	{
		/// <summary>
		/// Agricultural
		/// </summary>
		rural = 1,
		/// <summary>
		/// Non-agricultural
		/// </summary>
		urban = 2,
		/// <summary>
		/// represent the one without registration
		/// </summary>
		other = 3,
	}

	/// <summary>
	/// Gender
	/// </summary>
	public enum EGender
	{
		Male = 1,
		Female = 2,
	}

	/// <summary>
	/// Educational Level
	/// </summary>
	public enum EEducateLevel
	{
		/// <summary>
		/// for the child below 6 year old who is not investigated
		/// </summary>
		infant = 0,
		notEducated = 1,
		literClass = 2,
		primaSchool = 3,
		junMidSchool = 4,
		senMidSchool = 5,
		polytechSchool = 6,
		college = 7,
		university = 8,
		graduate = 9,
	}

	/// <summary>
	/// Residence Type
	/// </summary>
	public enum EResidenceType
	{
		city = 1,
		town = 2,
		rural = 3,
	}

	/// <summary>
	/// Ethnic Group (56 groups, 1 "other", 1 foreigner)
	/// </summary>
	public enum ERaceType
	{
		Han = 1,
		MengGu = 2,
		Hui = 3,
		Zang = 4,
		WeiWuEr = 5,
		Miao = 6,
		Yi = 7,
		Zhuang = 8,
		BuYi = 9,
		ChaoXian = 10,
		Man = 11,
		Dong = 12,
		Yao = 13,
		Bai = 14,
		TuJia = 15,
		HaNi = 16,
		HaSaKe = 17,
		Dai = 18,
		Li = 19,
		LiSu = 20,
		Wa = 21,
		She = 22,
		GaoShan = 23,
		LaHu = 24,
		Shui = 25,
		DongXiang = 26,
		NaXi = 27,
		JingPo = 28,
		KeErKeZi = 29,
		Tu = 30,
		DaWoEr = 31,
		MuLao = 32,
		Qiang = 33,
		BuLang = 34,
		SaLa = 35,
		MaoNan = 36,
		GeLao = 37,
		XiBo = 38,
		AChang = 39,
		PuMi = 40,
		TaJiKe = 41,
		Nu = 42,
		WuZiBieKe = 43,
		ELuoSi = 44,
		EWenKe = 45,
		DeAng = 46,
		BaoAn = 47,
		YuGu = 48,
		Jing = 49,
		TaTaEr = 50,
		DuLong = 51,
		ELunChun = 52,
		HeZhe = 53,
		MenBa = 54,
		LuoBa = 55,
		JiNuo = 56,
		/// <summary>
		/// for those ethnic group not recognized
		/// </summary>
		Other = 57,
		/// <summary>
		/// foreigners with Chinese nationality
		/// </summary>
		Foreign = 58,
	}

	/// <summary>
	/// age interval
	/// </summary>
	public enum EAgeInterval
	{
		ZeroToFour = 0,
		FiveToNine = 1,
		TenToFourteen = 2,
		FifteenToNineteen = 3,
		TwentyToTwentyFour = 4,
		TwentyFiveToTwentyNine = 5,
		ThirtyToThirtyFour = 6,
		ThirtyFiveToThirtyNine = 7,
		FortyToFortyFour = 8,
		FortyFiveToFortyNine = 9,
		FiftyToFiftyFour = 10,
		FiftyFiveToFiftyNine = 11,
		SixtyToSixtyFour = 12,
		SixtyFiveToSixtyNine = 13,
		SeventyToSeventyFour = 14,
		SeventyFiveToSeventyNine = 15,
		EightyToEightyFour = 16,
		EightyFiveToEightyNine = 17,
		NinetyToNinetyFour = 18,
		NinetyFiveToNinetyNine = 19,
		HundredAndAbove = 20,
	}
}
