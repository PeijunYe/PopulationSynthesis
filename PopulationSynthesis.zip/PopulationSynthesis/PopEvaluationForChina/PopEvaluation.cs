﻿using System;
using System.Collections.Generic;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;

namespace PopEvaluationForChina
{
	public class PopEvaluation
	{
		private string statDir;//input Long Table data dir
		private string dbName;//synthetic population DB name
		private double sampleRatio;//the ratio that population from Long Table account for the total synthetic population (default value is 0.095)

		//marginal frequencies from Long Table:
		private Dictionary<EGender, int> genLT;
		private Dictionary<EAgeInterval, int> ageLT;
		private Dictionary<EProvince, int> resideProvLT;
		private Dictionary<ERaceType, int> raceLT;
		private Dictionary<EEducateLevel, int> eduLvLT;
		private Dictionary<EResidenceType, int> resideTypeLT;
		//partial joint distributions from Long Table:
		private Dictionary<GenResideTypeResideProv, int> genResideTypeResideProvLT;
		private Dictionary<GenResideTypeAge, int> genResideTypeAgeLT;
		private Dictionary<GenderRace, int> genRaceLT;
		private Dictionary<GenResideTypeEduLv, int> genResideTypeEduLvLT;

		//marginal frequencies sampled from synthetic population:
		private Dictionary<EGender, int> genPop;
		private Dictionary<EAgeInterval, int> agePop;
		private Dictionary<EProvince, int> resideProvPop;
		private Dictionary<ERaceType, int> racePop;
		private Dictionary<EEducateLevel, int> eduLvPop;
		private Dictionary<EResidenceType, int> resideTypePop;
		//partial joint distributions sampled from synthetic population:
		private Dictionary<GenResideTypeResideProv, int> genResideTypeResideProvPop;
		private Dictionary<GenResideTypeAge, int> genResideTypeAgePop;
		private Dictionary<GenderRace, int> genRacePop;
		private Dictionary<GenResideTypeEduLv, int> genResideTypeEduLvPop;

		public PopEvaluation( string statDir, string dbName, double sampleRatio )
		{
			genLT = new Dictionary<EGender, int>( );
			ageLT = new Dictionary<EAgeInterval, int>( );
			resideProvLT = new Dictionary<EProvince, int>( );
			raceLT = new Dictionary<ERaceType, int>( );
			eduLvLT = new Dictionary<EEducateLevel, int>( );
			resideTypeLT = new Dictionary<EResidenceType, int>( );
			this.statDir = statDir;
			this.dbName = dbName;
			this.sampleRatio = sampleRatio;
			genPop = new Dictionary<EGender, int>( );
			agePop = new Dictionary<EAgeInterval, int>( );
			resideProvPop = new Dictionary<EProvince, int>( );
			racePop = new Dictionary<ERaceType, int>( );
			eduLvPop = new Dictionary<EEducateLevel, int>( );
			resideTypePop = new Dictionary<EResidenceType, int>( );
			genResideTypeResideProvLT = new Dictionary<GenResideTypeResideProv, int>( );
			genResideTypeResideProvPop = new Dictionary<GenResideTypeResideProv, int>( );
			genResideTypeAgeLT = new Dictionary<GenResideTypeAge, int>( );
			genResideTypeAgePop = new Dictionary<GenResideTypeAge, int>( );
			genRaceLT = new Dictionary<GenderRace, int>( );
			genRacePop = new Dictionary<GenderRace, int>( );
			genResideTypeEduLvLT = new Dictionary<GenResideTypeEduLv, int>( );
			genResideTypeEduLvPop = new Dictionary<GenResideTypeEduLv, int>( );
		}

		public void Evaluating( )
		{
			ReadLTMarginal( );
			ReadGenResideTypeResideProv( );
			ReadGenResideTypeAge( );
			ReadGenderRace( );
			ReadGenResidetypeEduLv( );
			ReadSynPop( dbName );
			IndicatorCal( );
		}

		private void ReadLTMarginal( )
		{
			Excel.Application excelApp = new Excel.Application( );
			object objOpt = System.Reflection.Missing.Value;
			Excel.Workbook workBook = null;
			Excel.Sheets sheets;
			Excel.Worksheet worksheet;
			Excel.Range range;
			try
			{
				int iRowCount = 0;
				int iColCount = 0;
				string cellContent = null;
				#region Gender and Age Interval
				workBook = excelApp.Workbooks.Open( Path.Combine( statDir, "l0102.xls" ),
						objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				range = worksheet.Cells[ 2, 3 ] as Excel.Range;
				cellContent = range.Text as string;
				cellContent = cellContent.Trim( );
				if ( cellContent == "" )
					throw new ApplicationException( "Male number error!" );
				genLT.Add( EGender.Male, int.Parse( cellContent ) );
				range = worksheet.Cells[ 2, 4 ] as Excel.Range;
				cellContent = range.Text as string;
				cellContent = cellContent.Trim( );
				if ( cellContent == "" )
					throw new ApplicationException( "Female number error!" );
				genLT.Add( EGender.Female, int.Parse( cellContent ) );
				for ( int i = 1; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ 6 * i - 3, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					string ageNum = null;
					foreach ( char item in cellContent )
					{
						if ( item >= 48 && item <= 58 )
						{
							ageNum += item;
						} else
						{
							break;
						}
					}
					EAgeInterval age = AttributeCheck.CheckAgeInterval( ushort.Parse( ageNum ) );
					range = worksheet.Cells[ 6 * i - 3, 2 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					int individualNum = int.Parse( cellContent );
					ageLT.Add( age, individualNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region Residential Province
				workBook = excelApp.Workbooks.Open( Path.Combine( statDir, "l0101.xls" ),
						objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince prov = AttributeCheck.CheckProvince( cellContent );
					range = worksheet.Cells[ i, 5 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					int individualNum = int.Parse( cellContent );
					resideProvLT.Add( prov, individualNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region Ethnic Group (only evaluate the people >= 15 year old)
				workBook = excelApp.Workbooks.Open( Path.Combine( statDir, "l0204.xls" ),
						objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					ERaceType race = AttributeCheck.CheckRace( cellContent );
					range = worksheet.Cells[ i, 2 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					int indNum = int.Parse( cellContent );
					raceLT.Add( race, indNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region Educational Level (not contained "Not Educated" and "Liter. Class". Not contained the people < 6 year old.)
				workBook = excelApp.Workbooks.Open( Path.Combine( statDir, "l0301.xls" ),
						objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int j = 3; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 4 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EEducateLevel eduLevel = (EEducateLevel)j;
					int indNum = int.Parse( cellContent );
					eduLvLT.Add( eduLevel, indNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				#endregion
				#region Residence Type
				resideTypeLT.Add( EResidenceType.city, 27570985 );
				resideTypeLT.Add( EResidenceType.town, 15530377 );
				resideTypeLT.Add( EResidenceType.rural, 74966062 );
				#endregion
			} catch ( Exception e )
			{
				throw new ApplicationException( e.Message );
			} finally
			{
				if ( workBook != null )
				{
					workBook.Close( false, objOpt, objOpt );
					System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
					workBook = null;
				}
				excelApp.Workbooks.Close( );
				excelApp.Quit( );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( excelApp );
				excelApp = null;
				GC.Collect( );
				GC.WaitForPendingFinalizers( );
			}
		}

		/// <summary>
		/// read partial distribution Gender*Residence Type*Residential Province (l0101a-l0101c)
		/// </summary>
		private void ReadGenResideTypeResideProv( )
		{
			Excel.Application excelApp = new Excel.Application( );
			object objOpt = System.Reflection.Missing.Value;
			Excel.Workbook workBook = null;
			Excel.Sheets sheets;
			Excel.Worksheet worksheet;
			Excel.Range range;
			try
			{
				int iRowCount = 0;
				int iColCount = 0;
				string cellContent = null;
				workBook = excelApp.Workbooks.Open( Path.Combine( statDir, "l0101a.xls" ),
						objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince prov = AttributeCheck.CheckProvince( cellContent );
					range = worksheet.Cells[ i, 6 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int maleNum = int.Parse( cellContent );
					range = worksheet.Cells[ i, 7 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int femaleNum = int.Parse( cellContent );
					GenResideTypeResideProv maleCity = new GenResideTypeResideProv( EGender.Male, EResidenceType.city, prov );
					genResideTypeResideProvLT.Add( maleCity, maleNum );
					GenResideTypeResideProv femaleCity = new GenResideTypeResideProv( EGender.Female, EResidenceType.city, prov );
					genResideTypeResideProvLT.Add( femaleCity, femaleNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				workBook = excelApp.Workbooks.Open( Path.Combine( statDir, "l0101b.xls" ),
						objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince prov = AttributeCheck.CheckProvince( cellContent );
					range = worksheet.Cells[ i, 6 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int maleNum = int.Parse( cellContent );
					range = worksheet.Cells[ i, 7 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int femaleNum = int.Parse( cellContent );
					GenResideTypeResideProv maleTown = new GenResideTypeResideProv( EGender.Male, EResidenceType.town, prov );
					genResideTypeResideProvLT.Add( maleTown, maleNum );
					GenResideTypeResideProv femaleTown = new GenResideTypeResideProv( EGender.Female, EResidenceType.town, prov );
					genResideTypeResideProvLT.Add( femaleTown, femaleNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				workBook = excelApp.Workbooks.Open( Path.Combine( statDir, "l0101c.xls" ),
						objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EProvince prov = AttributeCheck.CheckProvince( cellContent );
					range = worksheet.Cells[ i, 6 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int maleNum = int.Parse( cellContent );
					range = worksheet.Cells[ i, 7 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int femaleNum = int.Parse( cellContent );
					GenResideTypeResideProv maleRural = new GenResideTypeResideProv( EGender.Male, EResidenceType.rural, prov );
					genResideTypeResideProvLT.Add( maleRural, maleNum );
					GenResideTypeResideProv femaleRural = new GenResideTypeResideProv( EGender.Female, EResidenceType.rural, prov );
					genResideTypeResideProvLT.Add( femaleRural, femaleNum );
				}
			} catch ( Exception e )
			{
				throw new ApplicationException( e.Message );
			} finally
			{
				if ( workBook != null )
				{
					workBook.Close( false, objOpt, objOpt );
					System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
					workBook = null;
				}
				excelApp.Workbooks.Close( );
				excelApp.Quit( );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( excelApp );
				excelApp = null;
				GC.Collect( );
				GC.WaitForPendingFinalizers( );
			}
		}

		/// <summary>
		/// read partial distribution Gender*Residence Type*Age Interval (l0102a-l0102c)
		/// </summary>
		private void ReadGenResideTypeAge( )
		{
			Excel.Application excelApp = new Excel.Application( );
			object objOpt = System.Reflection.Missing.Value;
			Excel.Workbook workBook = null;
			Excel.Sheets sheets;
			Excel.Worksheet worksheet;
			Excel.Range range;
			try
			{
				int iRowCount = 0;
				int iColCount = 0;
				string cellContent = null;
				workBook = excelApp.Workbooks.Open( Path.Combine( statDir, "l0102a.xls" ),
						objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 1; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ 6 * i - 3, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					string ageNum = null;
					foreach ( char item in cellContent )
					{
						if ( item >= 48 && item <= 58 )
						{
							ageNum += item;
						} else
						{
							break;
						}
					}
					EAgeInterval age = AttributeCheck.CheckAgeInterval( ushort.Parse( ageNum ) );
					range = worksheet.Cells[ 6 * i - 3, 3 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int maleNum = int.Parse( cellContent );
					range = worksheet.Cells[ 6 * i - 3, 4 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int femaleNum = int.Parse( cellContent );
					GenResideTypeAge maleCity = new GenResideTypeAge( EGender.Male, EResidenceType.city, age );
					genResideTypeAgeLT.Add( maleCity, maleNum );
					GenResideTypeAge femaleCity = new GenResideTypeAge( EGender.Female, EResidenceType.city, age );
					genResideTypeAgeLT.Add( femaleCity, femaleNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				workBook = excelApp.Workbooks.Open( Path.Combine( statDir, "l0102b.xls" ),
						objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 1; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ 6 * i - 3, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					string ageNum = null;
					foreach ( char item in cellContent )
					{
						if ( item >= 48 && item <= 58 )
						{
							ageNum += item;
						} else
						{
							break;
						}
					}
					EAgeInterval age = AttributeCheck.CheckAgeInterval( ushort.Parse( ageNum ) );
					range = worksheet.Cells[ 6 * i - 3, 3 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int maleNum = int.Parse( cellContent );
					range = worksheet.Cells[ 6 * i - 3, 4 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int femaleNum = int.Parse( cellContent );
					GenResideTypeAge maleTown = new GenResideTypeAge( EGender.Male, EResidenceType.town, age );
					genResideTypeAgeLT.Add( maleTown, maleNum );
					GenResideTypeAge femaleTown = new GenResideTypeAge( EGender.Female, EResidenceType.town, age );
					genResideTypeAgeLT.Add( femaleTown, femaleNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				workBook = excelApp.Workbooks.Open( Path.Combine( statDir, "l0102c.xls" ),
						objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 1; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ 6 * i - 3, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					string ageNum = null;
					foreach ( char item in cellContent )
					{
						if ( item >= 48 && item <= 58 )
						{
							ageNum += item;
						} else
						{
							break;
						}
					}
					EAgeInterval age = AttributeCheck.CheckAgeInterval( ushort.Parse( ageNum ) );
					range = worksheet.Cells[ 6 * i - 3, 3 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int maleNum = int.Parse( cellContent );
					range = worksheet.Cells[ 6 * i - 3, 4 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int femaleNum = int.Parse( cellContent );
					GenResideTypeAge maleRural = new GenResideTypeAge( EGender.Male, EResidenceType.rural, age );
					genResideTypeAgeLT.Add( maleRural, maleNum );
					GenResideTypeAge femaleRural = new GenResideTypeAge( EGender.Female, EResidenceType.rural, age );
					genResideTypeAgeLT.Add( femaleRural, femaleNum );
				}
			} catch ( Exception e )
			{
				throw new ApplicationException( e.Message );
			} finally
			{
				if ( workBook != null )
				{
					workBook.Close( false, objOpt, objOpt );
					System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
					workBook = null;
				}
				excelApp.Workbooks.Close( );
				excelApp.Quit( );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( excelApp );
				excelApp = null;
				GC.Collect( );
				GC.WaitForPendingFinalizers( );
			}
		}

		/// <summary>
		/// read partial distribution Gender*Ethnic Group (l0201,l0203)(for Ethnic Group, only people >= 15 year old calculated)
		/// </summary>
		private void ReadGenderRace( )
		{
			Dictionary<ERaceType, int> maleRaceLT = new Dictionary<ERaceType, int>( );
			Dictionary<ERaceType, int> femaleRaceLT = new Dictionary<ERaceType, int>( );
			Excel.Application excelApp = new Excel.Application( );
			object objOpt = System.Reflection.Missing.Value;
			Excel.Workbook workBook = null;
			Excel.Sheets sheets;
			Excel.Worksheet worksheet;
			Excel.Range range;
			try
			{
				int iRowCount = 0;
				int iColCount = 0;
				string cellContent = null;
				workBook = excelApp.Workbooks.Open( Path.Combine( statDir, "l0201.xls" ),
						objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					ERaceType race = AttributeCheck.CheckRace( cellContent );
					range = worksheet.Cells[ i, 3 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int maleNum = int.Parse( cellContent );
					range = worksheet.Cells[ i, 4 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int femaleNum = int.Parse( cellContent );
					if ( maleRaceLT.ContainsKey( race ) )
						maleRaceLT[ race ] += maleNum;
					else
						maleRaceLT.Add( race, maleNum );
					if ( femaleRaceLT.ContainsKey( race ) )
						femaleRaceLT[ race ] += femaleNum;
					else
						femaleRaceLT.Add( race, femaleNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				workBook = excelApp.Workbooks.Open( Path.Combine( statDir, "l0203.xls" ),
						objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int i = 3; i <= iRowCount; i++ )
				{
					range = worksheet.Cells[ i, 1 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					ERaceType race = AttributeCheck.CheckRace( cellContent );
					range = worksheet.Cells[ i, 3 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int maleNum = int.Parse( cellContent );
					range = worksheet.Cells[ i, 4 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int femaleNum = int.Parse( cellContent );
					maleRaceLT[ race ] += maleNum;
					femaleRaceLT[ race ] += femaleNum;
				}
			} catch ( Exception e )
			{
				throw new ApplicationException( e.Message );
			} finally
			{
				if ( workBook != null )
				{
					workBook.Close( false, objOpt, objOpt );
					System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
					workBook = null;
				}
				excelApp.Workbooks.Close( );
				excelApp.Quit( );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( excelApp );
				excelApp = null;
				GC.Collect( );
				GC.WaitForPendingFinalizers( );
			}
			foreach ( ERaceType race in maleRaceLT.Keys )
			{
				GenderRace maleRace = new GenderRace( EGender.Male, race );
				genRaceLT.Add( maleRace, maleRaceLT[ race ] );
			}
			foreach ( ERaceType race in femaleRaceLT.Keys )
			{
				GenderRace femaleRace = new GenderRace( EGender.Female, race );
				genRaceLT.Add( femaleRace, femaleRaceLT[ race ] );
			}
		}

		/// <summary>
		/// read partial distribution Gender*Residence Type*Educational Level (l0301a-l0301c)
		/// </summary>
		private void ReadGenResidetypeEduLv( )
		{
			Excel.Application excelApp = new Excel.Application( );
			object objOpt = System.Reflection.Missing.Value;
			Excel.Workbook workBook = null;
			Excel.Sheets sheets;
			Excel.Worksheet worksheet;
			Excel.Range range;
			try
			{
				int iRowCount = 0;
				int iColCount = 0;
				string cellContent = null;
				workBook = excelApp.Workbooks.Open( Path.Combine( statDir, "l0301a.xls" ),
						objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int j = 3; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 4 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EEducateLevel eduLevel = (EEducateLevel)j;
					range = worksheet.Cells[ 2, 3 * j - 3 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int maleNum = int.Parse( cellContent );
					range = worksheet.Cells[ 2, 3 * j - 2 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int femaleNum = int.Parse( cellContent );
					GenResideTypeEduLv maleCity = new GenResideTypeEduLv( EGender.Male, EResidenceType.city, eduLevel );
					genResideTypeEduLvLT.Add( maleCity, maleNum );
					GenResideTypeEduLv femaleCity = new GenResideTypeEduLv( EGender.Female, EResidenceType.city, eduLevel );
					genResideTypeEduLvLT.Add( femaleCity, femaleNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				workBook = excelApp.Workbooks.Open( Path.Combine( statDir, "l0301b.xls" ),
						objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int j = 3; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 4 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EEducateLevel eduLevel = (EEducateLevel)j;
					range = worksheet.Cells[ 2, 3 * j - 3 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int maleNum = int.Parse( cellContent );
					range = worksheet.Cells[ 2, 3 * j - 2 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int femaleNum = int.Parse( cellContent );
					GenResideTypeEduLv maleTown = new GenResideTypeEduLv( EGender.Male, EResidenceType.town, eduLevel );
					genResideTypeEduLvLT.Add( maleTown, maleNum );
					GenResideTypeEduLv femaleTown = new GenResideTypeEduLv( EGender.Female, EResidenceType.town, eduLevel );
					genResideTypeEduLvLT.Add( femaleTown, femaleNum );
				}
				workBook.Close( false, objOpt, objOpt );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
				workBook = null;
				workBook = excelApp.Workbooks.Open( Path.Combine( statDir, "l0301c.xls" ),
						objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt );
				sheets = workBook.Worksheets;
				worksheet = sheets.Item[ 1 ] as Excel.Worksheet;
				iRowCount = worksheet.UsedRange.Rows.Count;
				iColCount = worksheet.UsedRange.Columns.Count;
				for ( int j = 3; j <= iColCount; j++ )
				{
					range = worksheet.Cells[ 2, 3 * j - 4 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						break;
					EEducateLevel eduLevel = (EEducateLevel)j;
					range = worksheet.Cells[ 2, 3 * j - 3 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int maleNum = int.Parse( cellContent );
					range = worksheet.Cells[ 2, 3 * j - 2 ] as Excel.Range;
					cellContent = range.Text as string;
					cellContent = cellContent.Trim( );
					if ( cellContent == "" )
						cellContent = "0";
					int femaleNum = int.Parse( cellContent );
					GenResideTypeEduLv maleRural = new GenResideTypeEduLv( EGender.Male, EResidenceType.rural, eduLevel );
					genResideTypeEduLvLT.Add( maleRural, maleNum );
					GenResideTypeEduLv femaleRural = new GenResideTypeEduLv( EGender.Female, EResidenceType.rural, eduLevel );
					genResideTypeEduLvLT.Add( femaleRural, femaleNum );
				}
			} catch ( Exception e )
			{
				throw new ApplicationException( e.Message );
			} finally
			{
				if ( workBook != null )
				{
					workBook.Close( false, objOpt, objOpt );
					System.Runtime.InteropServices.Marshal.ReleaseComObject( workBook );
					workBook = null;
				}
				excelApp.Workbooks.Close( );
				excelApp.Quit( );
				System.Runtime.InteropServices.Marshal.ReleaseComObject( excelApp );
				excelApp = null;
				GC.Collect( );
				GC.WaitForPendingFinalizers( );
			}
		}

		/// <summary>
		/// sampling synthetic population database
		/// </summary>
		private void ReadSynPop( string oneDBName )
		{
			MyDatabase popDB = new MyDatabase( oneDBName );
			if ( !Directory.Exists( oneDBName ) )
			{
				Console.WriteLine( "Population database does not exist!" );
				return;
			}
			popDB.DBOpen( );
			DBIterator dbIter = popDB.GetIterator( );
			Random rand = new Random( );
			int lineNum = 0;
			for ( dbIter.SeekToFirst( ); dbIter.Valid( ); dbIter.Next( ) )
			{
				double ratio = rand.NextDouble( );
				if ( ratio > sampleRatio )
					continue;//stochastically sample the synthetic population
				#region calculate marginals
				string keyStr = dbIter.Key( ).ToString( );
				string valueStr = dbIter.Value( ).ToString( );
				string[ ] attributes = valueStr.Split( '-' );

				EGender gender = (EGender)(int.Parse( attributes[ 0 ] ));
				if ( genPop.ContainsKey( gender ) )
					genPop[ gender ]++;
				else
					genPop.Add( gender, 1 );
				ushort ageNum = ushort.Parse( attributes[ 3 ] );
				EAgeInterval age = AttributeCheck.CheckAgeInterval( ageNum );
				if ( agePop.ContainsKey( age ) )
					agePop[ age ]++;
				else
					agePop.Add( age, 1 );
				ERaceType race = (ERaceType)(int.Parse( attributes[ 4 ] ));
				//for Ethnic Group, the Long Table only contains people >= 15 year old
				if ( age != EAgeInterval.ZeroToFour && age != EAgeInterval.FiveToNine && age != EAgeInterval.TenToFourteen )
				{
					if ( racePop.ContainsKey( race ) )
						racePop[ race ]++;
					else
						racePop.Add( race, 1 );
				}
				EEducateLevel eduLv = (EEducateLevel)(int.Parse( attributes[ 7 ] ));
				//for Educational Level,  the Long Table does not contain "Not Educated", "Liter. Class" and the people < 6 year old
				if ( age != EAgeInterval.ZeroToFour && eduLv != EEducateLevel.infant
					&& eduLv != EEducateLevel.notEducated && eduLv != EEducateLevel.literClass )
				{
					if ( eduLvPop.ContainsKey( eduLv ) )
						eduLvPop[ eduLv ]++;
					else
						eduLvPop.Add( eduLv, 1 );
				}
				EProvince resideProv = (EProvince)(int.Parse( attributes[ 8 ] ));
				if ( resideProvPop.ContainsKey( resideProv ) )
					resideProvPop[ resideProv ]++;
				else
					resideProvPop.Add( resideProv, 1 );
				EResidenceType resideType = (EResidenceType)(int.Parse( attributes[ 9 ] ));
				if ( resideTypePop.ContainsKey( resideType ) )
					resideTypePop[ resideType ]++;
				else
					resideTypePop.Add( resideType, 1 );
				#endregion
				#region calculate partial distributions
				bool hasParDis = false;
				foreach ( GenResideTypeResideProv parKey in genResideTypeResideProvPop.Keys )
				{
					if ( parKey.Gender == gender && parKey.ResidenceType == resideType && parKey.ResideProvin == resideProv )
					{
						genResideTypeResideProvPop[ parKey ]++;
						hasParDis = true;
						break;
					}
				}
				if ( !hasParDis )
				{
					GenResideTypeResideProv parKey = new GenResideTypeResideProv( gender, resideType, resideProv );
					genResideTypeResideProvPop.Add( parKey, 1 );
				}
				hasParDis = false;
				foreach ( GenResideTypeAge parKey in genResideTypeAgePop.Keys )
				{
					if ( parKey.Gender == gender && parKey.ResidenceType == resideType && parKey.Age == age )
					{
						genResideTypeAgePop[ parKey ]++;
						hasParDis = true;
						break;
					}
				}
				if ( !hasParDis )
				{
					GenResideTypeAge parKey = new GenResideTypeAge( gender, resideType, age );
					genResideTypeAgePop.Add( parKey, 1 );
				}
				if ( age != EAgeInterval.ZeroToFour && age != EAgeInterval.FiveToNine && age != EAgeInterval.TenToFourteen )
				{
					hasParDis = false;
					foreach ( GenderRace parKey in genRacePop.Keys )
					{
						if ( parKey.Gender == gender && parKey.Race == race )
						{
							genRacePop[ parKey ]++;
							hasParDis = true;
							break;
						}
					}
					if ( !hasParDis )
					{
						GenderRace parKey = new GenderRace( gender, race );
						genRacePop.Add( parKey, 1 );
					}
				}
				if ( age != EAgeInterval.ZeroToFour && eduLv != EEducateLevel.infant
					&& eduLv != EEducateLevel.notEducated && eduLv != EEducateLevel.literClass )
				{
					hasParDis = false;
					foreach ( GenResideTypeEduLv parKey in genResideTypeEduLvPop.Keys )
					{
						if ( parKey.Gender == gender && parKey.ResidenceType == resideType && parKey.EduLevel == eduLv )
						{
							genResideTypeEduLvPop[ parKey ]++;
							hasParDis = true;
							break;
						}
					}
					if ( !hasParDis )
					{
						GenResideTypeEduLv parKey = new GenResideTypeEduLv( gender, resideType, eduLv );
						genResideTypeEduLvPop.Add( parKey, 1 );
					}
				}
				#endregion
				lineNum++;
				if ( lineNum % 1000000 == 0 )
					Console.WriteLine( string.Format( "{0:0,0}", lineNum ) + " records calculated!" );
			}
			dbIter.Dispose( );
			popDB.DBDispose( );
			Console.WriteLine( "Total calculated records: " + lineNum + " ----------" );
		}

		/// <summary>
		/// calculate the indicators
		/// </summary>
		private void IndicatorCal( )
		{
			//marginals
			StreamWriter genWriter = new StreamWriter( "gender.txt", false );
			foreach ( EGender key in genLT.Keys )
			{
				string line = "";
				if ( genPop.ContainsKey( key ) )
					line = key + "\t" + genLT[ key ] + "\t" + genPop[ key ];
				else
					line = key + "\t" + genLT[ key ] + "\t" + 0;
				genWriter.WriteLine( line );
			}
			genWriter.Close( );
			StreamWriter ageWriter = new StreamWriter( "age.txt", false );
			foreach ( EAgeInterval key in ageLT.Keys )
			{
				string line = "";
				if ( agePop.ContainsKey( key ) )
					line = key + "\t" + ageLT[ key ] + "\t" + agePop[ key ];
				else
					line = key + "\t" + ageLT[ key ] + "\t" + 0;
				ageWriter.WriteLine( line );
			}
			ageWriter.Close( );
			StreamWriter resideProvWriter = new StreamWriter( "resideProv.txt", false );
			foreach ( EProvince key in resideProvLT.Keys )
			{
				string line = "";
				if ( resideProvPop.ContainsKey( key ) )
					line = key + "\t" + resideProvLT[ key ] + "\t" + resideProvPop[ key ];
				else
					line = key + "\t" + resideProvLT[ key ] + "\t" + 0;
				resideProvWriter.WriteLine( line );
			}
			resideProvWriter.Close( );
			StreamWriter raceWriter = new StreamWriter( "race.txt", false );
			foreach ( ERaceType key in raceLT.Keys )
			{
				string line = "";
				if ( racePop.ContainsKey( key ) )
					line = key + "\t" + raceLT[ key ] + "\t" + racePop[ key ];
				else
					line = key + "\t" + raceLT[ key ] + "\t" + 0;
				raceWriter.WriteLine( line );
			}
			raceWriter.Close( );
			StreamWriter eduLvWriter = new StreamWriter( "eduLv.txt", false );
			foreach ( EEducateLevel key in eduLvLT.Keys )
			{
				string line = "";
				if ( eduLvPop.ContainsKey( key ) )
					line = key + "\t" + eduLvLT[ key ] + "\t" + eduLvPop[ key ];
				else
					line = key + "\t" + eduLvLT[ key ] + "\t" + 0;
				eduLvWriter.WriteLine( line );
			}
			eduLvWriter.Close( );
			StreamWriter resideTypeWriter = new StreamWriter( "resideType.txt", false );
			foreach ( EResidenceType key in resideTypeLT.Keys )
			{
				string line = "";
				if ( resideTypePop.ContainsKey( key ) )
					line = key + "\t" + resideTypeLT[ key ] + "\t" + resideTypePop[ key ];
				else
					line = key + "\t" + resideTypeLT[ key ] + "\t" + 0;
				resideTypeWriter.WriteLine( line );
			}
			resideTypeWriter.Close( );
			//partial distributions
			StreamWriter genResideTypeResideProvWriter = new StreamWriter( "GenderResideTypeResideProv.txt", false );
			foreach ( GenResideTypeResideProv key in genResideTypeResideProvLT.Keys )
			{
				string line = key.Gender + "*" + key.ResidenceType + "*" + key.ResideProvin;
				if ( genResideTypeResideProvPop.ContainsKey( key ) )
					line += "\t" + genResideTypeResideProvLT[ key ] + "\t" + genResideTypeResideProvPop[ key ];
				else
					line += "\t" + genResideTypeResideProvLT[ key ] + "\t" + 0;
				genResideTypeResideProvWriter.WriteLine( line );
			}
			genResideTypeResideProvWriter.Close( );
			StreamWriter genResideTypeAgeWriter = new StreamWriter( "GenderResideTypeAge.txt", false );
			foreach ( GenResideTypeAge key in genResideTypeAgeLT.Keys )
			{
				string line = key.Gender + "*" + key.ResidenceType + "*" + key.Age;
				if ( genResideTypeAgePop.ContainsKey( key ) )
					line += "\t" + genResideTypeAgeLT[ key ] + "\t" + genResideTypeAgePop[ key ];
				else
					line += "\t" + genResideTypeAgeLT[ key ] + "\t" + 0;
				genResideTypeAgeWriter.WriteLine( line );
			}
			genResideTypeAgeWriter.Close( );
			StreamWriter genderRaceWriter = new StreamWriter( "GenderRace.txt", false );
			foreach ( GenderRace key in genRaceLT.Keys )
			{
				string line = key.Gender + "*" + key.Race;
				if ( genRacePop.ContainsKey( key ) )
					line += "\t" + genRaceLT[ key ] + "\t" + genRacePop[ key ];
				else
					line += "\t" + genRaceLT[ key ] + "\t" + 0;
				genderRaceWriter.WriteLine( line );
			}
			genderRaceWriter.Close( );
			StreamWriter genResideTypeEduLvWriter = new StreamWriter( "GenderResideTypeEduLv.txt", false );
			foreach ( GenResideTypeEduLv key in genResideTypeEduLvLT.Keys )
			{
				string line = key.Gender + "*" + key.ResidenceType + "*" + key.EduLevel;
				if ( genResideTypeEduLvPop.ContainsKey( key ) )
					line += "\t" + genResideTypeEduLvLT[ key ] + "\t" + genResideTypeEduLvPop[ key ];
				else
					line += "\t" + genResideTypeEduLvLT[ key ] + "\t" + 0;
				genResideTypeEduLvWriter.WriteLine( line );
			}
			genResideTypeEduLvWriter.Close( );
		}
	}
}
